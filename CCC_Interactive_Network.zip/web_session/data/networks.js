var networks = {"CCC_edges.csv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "NULab_ Project Entities - edges (1).csv",
    "name" : "CCC_edges.csv",
    "SUID" : 1556,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "926",
        "shared_name" : "RM-142",
        "name" : "RM-142",
        "SUID" : 926,
        "Recipe_Name" : "Peanut Brittle",
        "selected" : false
      },
      "position" : {
        "x" : 449.1556360378104,
        "y" : -98.05958506212397
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "920",
        "shared_name" : "WC-142",
        "name" : "WC-142",
        "SUID" : 920,
        "Recipe_Name" : "Sesame Peanut Brittle (Fah Sung Thong)",
        "selected" : false
      },
      "position" : {
        "x" : 480.13631841085726,
        "y" : -50.47175547228022
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "914",
        "shared_name" : "OC-142",
        "name" : "OC-142",
        "SUID" : 914,
        "Recipe_Name" : "Chinese Peanut Brittle (花生糖)",
        "selected" : false
      },
      "position" : {
        "x" : 449.60506841085726,
        "y" : 42.42802480115728
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "908",
        "shared_name" : "WL-142",
        "name" : "WL-142",
        "SUID" : 908,
        "Recipe_Name" : "Homemade Chinese Sesame Peanut Brittle",
        "selected" : false
      },
      "position" : {
        "x" : 497.91155644796663,
        "y" : 1.497604879282278
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "896",
        "shared_name" : "RM-141",
        "name" : "RM-141",
        "SUID" : 896,
        "Recipe_Name" : "Yam Cake",
        "selected" : false
      },
      "position" : {
        "x" : 251.2517244472342,
        "y" : 404.71217397107915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "890",
        "shared_name" : "WC-141",
        "name" : "WC-141",
        "SUID" : 890,
        "Recipe_Name" : "Steamed Yam/Taro Cake (Orh Kueh/Wu Tau Koh)",
        "selected" : false
      },
      "position" : {
        "x" : 279.74660512350374,
        "y" : 359.5834508265479
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "884",
        "shared_name" : "ML-141",
        "name" : "ML-141",
        "SUID" : 884,
        "Recipe_Name" : "Taro Cake",
        "selected" : false
      },
      "position" : {
        "x" : 155.30823918722444,
        "y" : 429.0613560999854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "878",
        "shared_name" : "WL-141",
        "name" : "WL-141",
        "SUID" : 878,
        "Recipe_Name" : "Taro Cake (Chinese Wu Tao Gou)",
        "selected" : false
      },
      "position" : {
        "x" : 207.8766138210135,
        "y" : 431.5523228968604
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "866",
        "shared_name" : "RM-138",
        "name" : "RM-138",
        "SUID" : 866,
        "Recipe_Name" : "Paper Wrapped Sponge Cake",
        "selected" : false
      },
      "position" : {
        "x" : -15.541263376252118,
        "y" : -437.38723703966303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "860",
        "shared_name" : "WC-138",
        "name" : "WC-138",
        "SUID" : 860,
        "Recipe_Name" : "Paper-Wrapped Sponge Cake (紙包蛋糕)",
        "selected" : false
      },
      "position" : {
        "x" : -153.36661127664274,
        "y" : -398.7230868016259
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "854",
        "shared_name" : "OC-138",
        "name" : "OC-138",
        "SUID" : 854,
        "Recipe_Name" : "Chinese Egg Cake (鸡蛋糕)",
        "selected" : false
      },
      "position" : {
        "x" : -71.46268061258024,
        "y" : -446.0146479283349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "848",
        "shared_name" : "WL-138",
        "name" : "WL-138",
        "SUID" : 848,
        "Recipe_Name" : "Chinese Egg Cake",
        "selected" : false
      },
      "position" : {
        "x" : -123.74646357156462,
        "y" : -445.7291941319482
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "836",
        "shared_name" : "RM-137",
        "name" : "RM-137",
        "SUID" : 836,
        "Recipe_Name" : "Almond Cookies",
        "selected" : false
      },
      "position" : {
        "x" : -252.55582026101774,
        "y" : -146.01606699571772
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "830",
        "shared_name" : "WC-137",
        "name" : "WC-137",
        "SUID" : 830,
        "Recipe_Name" : "Chinese Almond Cookies",
        "selected" : false
      },
      "position" : {
        "x" : -212.95730951883024,
        "y" : -185.54070994005366
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "824",
        "shared_name" : "OC-137",
        "name" : "OC-137",
        "SUID" : 824,
        "Recipe_Name" : "Chinese Almond Cookies",
        "selected" : false
      },
      "position" : {
        "x" : -223.05301264383024,
        "y" : -32.98023935899897
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "818",
        "shared_name" : "WL-137",
        "name" : "WL-137",
        "SUID" : 818,
        "Recipe_Name" : "Chinese Almond Cookies",
        "selected" : false
      },
      "position" : {
        "x" : -255.246066843049,
        "y" : -97.44908091173335
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "806",
        "shared_name" : "WC-136",
        "name" : "WC-136",
        "SUID" : 806,
        "Recipe_Name" : "Chinese Steamed Pork Buns (Bak Pao)",
        "selected" : false
      },
      "position" : {
        "x" : -213.57144526101774,
        "y" : -248.2280726109521
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "800",
        "shared_name" : "OC-136",
        "name" : "OC-136",
        "SUID" : 800,
        "Recipe_Name" : "Steamed Pork Buns with Chive (猪肉韭菜包子)",
        "selected" : false
      },
      "position" : {
        "x" : -172.75714472390837,
        "y" : -283.342917886831
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "794",
        "shared_name" : "WL-136",
        "name" : "WL-136",
        "SUID" : 794,
        "Recipe_Name" : "Steamed Pork Buns (Baozi)",
        "selected" : false
      },
      "position" : {
        "x" : -124.2107885227365,
        "y" : -292.25467630968257
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "782",
        "shared_name" : "RM-135",
        "name" : "RM-135",
        "SUID" : 782,
        "Recipe_Name" : "Chinese Fried Rice",
        "selected" : false
      },
      "position" : {
        "x" : -180.53741816140837,
        "y" : 274.8701939906104
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "776",
        "shared_name" : "WC-135",
        "name" : "WC-135",
        "SUID" : 776,
        "Recipe_Name" : "Golden Egg Fried Rice",
        "selected" : false
      },
      "position" : {
        "x" : -213.03091791726774,
        "y" : 223.0149693812354
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "shared_name" : "OC-135",
        "name" : "OC-135",
        "SUID" : 770,
        "Recipe_Name" : "Easy Egg Fried Rice (蛋炒饭)",
        "selected" : false
      },
      "position" : {
        "x" : -65.630832468049,
        "y" : 289.8461461390479
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "shared_name" : "ML-135",
        "name" : "ML-135",
        "SUID" : 764,
        "Recipe_Name" : "Fried Rice",
        "selected" : false
      },
      "position" : {
        "x" : -133.51868036843962,
        "y" : 301.5631871546729
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "758",
        "shared_name" : "WL-135",
        "name" : "WL-135",
        "SUID" : 758,
        "Recipe_Name" : "Egg Fried Rice",
        "selected" : false
      },
      "position" : {
        "x" : -33.81491449929899,
        "y" : 138.4834752406104
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "746",
        "shared_name" : "RM-133",
        "name" : "RM-133",
        "SUID" : 746,
        "Recipe_Name" : "Chinese Hot Pot",
        "selected" : false
      },
      "position" : {
        "x" : 140.19614812277132,
        "y" : -322.4257921849267
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "740",
        "shared_name" : "WC-133",
        "name" : "WC-133",
        "SUID" : 740,
        "Recipe_Name" : "Chinese Steamboat/Hot Pot At Home",
        "selected" : false
      },
      "position" : {
        "x" : 185.7191888942557,
        "y" : -147.16661020860835
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "shared_name" : "OC-133",
        "name" : "OC-133",
        "SUID" : 734,
        "Recipe_Name" : "Hot Pot Guide (火锅)",
        "selected" : false
      },
      "position" : {
        "x" : 12.408352102263507,
        "y" : -205.13426157579585
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "shared_name" : "ML-133",
        "name" : "ML-133",
        "SUID" : 728,
        "Recipe_Name" : "Hot Pot at Home",
        "selected" : false
      },
      "position" : {
        "x" : 225.79213353536898,
        "y" : -219.0175776158349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "722",
        "shared_name" : "WL-133",
        "name" : "WL-133",
        "SUID" : 722,
        "Recipe_Name" : "Sichuan Hot Pot",
        "selected" : false
      },
      "position" : {
        "x" : 60.70351811788851,
        "y" : -299.084861246206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "710",
        "shared_name" : "WC-115",
        "name" : "WC-115",
        "SUID" : 710,
        "Recipe_Name" : "Buddha’s Delight (Lo Han Jai)",
        "selected" : false
      },
      "position" : {
        "x" : -443.685031686799,
        "y" : -95.3651575718896
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "704",
        "shared_name" : "OC-115",
        "name" : "OC-115",
        "SUID" : 704,
        "Recipe_Name" : "Buddha’s Delight (Jai Chinese Vegetarian Stew)",
        "selected" : false
      },
      "position" : {
        "x" : -473.83218744851774,
        "y" : -0.23042246446772197
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "shared_name" : "ML-115",
        "name" : "ML-115",
        "SUID" : 698,
        "Recipe_Name" : "Buddha's Delight",
        "selected" : false
      },
      "position" : {
        "x" : -449.1253393039865,
        "y" : 42.64747670545415
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "shared_name" : "WL-115",
        "name" : "WL-115",
        "SUID" : 692,
        "Recipe_Name" : "Buddha’s Delight (Vegetarian Lo Han Jai)",
        "selected" : false
      },
      "position" : {
        "x" : -472.001437936799,
        "y" : -44.51255747423335
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "680",
        "shared_name" : "WC-112",
        "name" : "WC-112",
        "SUID" : 680,
        "Recipe_Name" : "Dou Sha Bao (Red Bean Paste Steamed Buns)",
        "selected" : false
      },
      "position" : {
        "x" : 102.5921899928885,
        "y" : 359.0742955531104
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "674",
        "shared_name" : "OC-112",
        "name" : "OC-112",
        "SUID" : 674,
        "Recipe_Name" : "Red Bean Bread (豆沙包)",
        "selected" : false
      },
      "position" : {
        "x" : 54.07732793234163,
        "y" : 378.28285268201665
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "668",
        "shared_name" : "WL-112",
        "name" : "WL-112",
        "SUID" : 668,
        "Recipe_Name" : "Steamed Red Bean Buns",
        "selected" : false
      },
      "position" : {
        "x" : 4.400325979216632,
        "y" : 373.63954213514165
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "shared_name" : "OC-110",
        "name" : "OC-110",
        "SUID" : 656,
        "Recipe_Name" : "Stuffed Tofu",
        "selected" : false
      },
      "position" : {
        "x" : -74.705051218049,
        "y" : 446.94972279920415
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "650",
        "shared_name" : "ML-110",
        "name" : "ML-110",
        "SUID" : 650,
        "Recipe_Name" : "Fried Stuffed Tofu",
        "selected" : false
      },
      "position" : {
        "x" : -121.71551874734587,
        "y" : 423.24513295545415
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "644",
        "shared_name" : "WL-110",
        "name" : "WL-110",
        "SUID" : 644,
        "Recipe_Name" : "Crispy Skin Stuffed Tofu",
        "selected" : false
      },
      "position" : {
        "x" : -21.175601755158368,
        "y" : 445.80201772107915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "632",
        "shared_name" : "RM-092",
        "name" : "RM-092",
        "SUID" : 632,
        "Recipe_Name" : "Shrimp Omelette",
        "selected" : false
      },
      "position" : {
        "x" : -271.40945795633024,
        "y" : 413.4899449671729
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "626",
        "shared_name" : "OC-092",
        "name" : "OC-092",
        "SUID" : 626,
        "Recipe_Name" : "Shrimp Egg Foo Young (鲜虾芙蓉蛋)",
        "selected" : false
      },
      "position" : {
        "x" : -333.41556147195524,
        "y" : 340.5828404749854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "620",
        "shared_name" : "ML-092",
        "name" : "ML-092",
        "SUID" : 620,
        "Recipe_Name" : "Cantonese Scrambled Eggs & Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : -312.37918451883024,
        "y" : 387.7836461390479
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "614",
        "shared_name" : "WL-092",
        "name" : "WL-092",
        "SUID" : 614,
        "Recipe_Name" : "Shrimp Egg Foo Young",
        "selected" : false
      },
      "position" : {
        "x" : -217.63138178445524,
        "y" : 414.42469838514165
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "shared_name" : "RM-089",
        "name" : "RM-089",
        "SUID" : 602,
        "Recipe_Name" : "Egg Foo Young",
        "selected" : false
      },
      "position" : {
        "x" : -415.467014108674,
        "y" : 145.32591298475103
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "shared_name" : "OC-089",
        "name" : "OC-089",
        "SUID" : 596,
        "Recipe_Name" : "Egg Foo Young",
        "selected" : false
      },
      "position" : {
        "x" : -345.56326655008024,
        "y" : 267.6090855921729
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "shared_name" : "ML-089",
        "name" : "ML-089",
        "SUID" : 590,
        "Recipe_Name" : "Egg Foo Young",
        "selected" : false
      },
      "position" : {
        "x" : -413.8235814914865,
        "y" : 198.29603627576665
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "shared_name" : "WL-089",
        "name" : "WL-089",
        "SUID" : 584,
        "Recipe_Name" : "Egg Foo Young",
        "selected" : false
      },
      "position" : {
        "x" : -388.96866205789274,
        "y" : 237.66554311170415
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "shared_name" : "RM-067",
        "name" : "RM-067",
        "SUID" : 572,
        "Recipe_Name" : "Salt and Pepper Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 292.9662544383841,
        "y" : -281.0085367833154
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "shared_name" : "OC-067",
        "name" : "OC-067",
        "SUID" : 566,
        "Recipe_Name" : "3-Ingredient Fried Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 257.19992848776155,
        "y" : -313.02978083238764
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "shared_name" : "ML-067",
        "name" : "ML-067",
        "SUID" : 560,
        "Recipe_Name" : "Salt & Pepper Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 213.19996282003694,
        "y" : -329.0873942051904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "554",
        "shared_name" : "WL-067",
        "name" : "WL-067",
        "SUID" : 554,
        "Recipe_Name" : "Fantail Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 300.52863880537325,
        "y" : -225.5819544468896
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "shared_name" : "WC-066",
        "name" : "WC-066",
        "SUID" : 542,
        "Recipe_Name" : "Chinese Steamed Garlic Prawns with Vermicelli Noodles",
        "selected" : false
      },
      "position" : {
        "x" : 224.96991368673616,
        "y" : 206.1514439906104
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "shared_name" : "ML-066",
        "name" : "ML-066",
        "SUID" : 536,
        "Recipe_Name" : "Steamed Garlic Shrimp on Vermicelli",
        "selected" : false
      },
      "position" : {
        "x" : 189.40342351339632,
        "y" : 243.06227162732915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "shared_name" : "WL-066",
        "name" : "WL-066",
        "SUID" : 530,
        "Recipe_Name" : "Steamed Shrimp with Glass Noodles",
        "selected" : false
      },
      "position" : {
        "x" : 130.51034184835726,
        "y" : 259.9661412562354
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "shared_name" : "RM-060",
        "name" : "RM-060",
        "SUID" : 518,
        "Recipe_Name" : "Steamed Fish",
        "selected" : false
      },
      "position" : {
        "x" : 225.52177068136507,
        "y" : 144.2853551234229
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "512",
        "shared_name" : "WC-060",
        "name" : "WC-060",
        "SUID" : 512,
        "Recipe_Name" : "Cantonese Steamed Fish",
        "selected" : false
      },
      "position" : {
        "x" : 351.1976396694022,
        "y" : 294.4702916468604
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "shared_name" : "OC-060",
        "name" : "OC-060",
        "SUID" : 506,
        "Recipe_Name" : "Steamed Fish",
        "selected" : false
      },
      "position" : {
        "x" : 397.92078801534944,
        "y" : 265.1610875452979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "shared_name" : "ML-060",
        "name" : "ML-060",
        "SUID" : 500,
        "Recipe_Name" : "Steamed Fish",
        "selected" : false
      },
      "position" : {
        "x" : 418.00387212179476,
        "y" : 217.36842397107915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "shared_name" : "WL-060",
        "name" : "WL-060",
        "SUID" : 494,
        "Recipe_Name" : "Cantonese Steamed Fish",
        "selected" : false
      },
      "position" : {
        "x" : 421.16679021261507,
        "y" : 163.17750600232915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "shared_name" : "RM-053",
        "name" : "RM-053",
        "SUID" : 482,
        "Recipe_Name" : "Black Pepper Beef",
        "selected" : false
      },
      "position" : {
        "x" : 337.45953771017366,
        "y" : -179.2280726109521
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "shared_name" : "OC-053",
        "name" : "OC-053",
        "SUID" : 476,
        "Recipe_Name" : "Shredded Beef and Pepper Stir Fry (青椒肉丝)",
        "selected" : false
      },
      "position" : {
        "x" : 205.35454961202913,
        "y" : -23.990462747670847
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "shared_name" : "ML-053",
        "name" : "ML-053",
        "SUID" : 470,
        "Recipe_Name" : "Black Pepper Beef Stir Fry",
        "selected" : false
      },
      "position" : {
        "x" : 364.21993657491976,
        "y" : -138.8125452672021
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "shared_name" : "WL-053",
        "name" : "WL-053",
        "SUID" : 464,
        "Recipe_Name" : "Beef and Pepper Stir-fry",
        "selected" : false
      },
      "position" : {
        "x" : 366.35895558737093,
        "y" : -88.05543467149897
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "shared_name" : "WC-051",
        "name" : "WC-051",
        "SUID" : 452,
        "Recipe_Name" : "Fried Stewed Country Spareribs/Zha Li Rou",
        "selected" : false
      },
      "position" : {
        "x" : 76.36594792745882,
        "y" : 202.4136510218604
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "shared_name" : "OC-051",
        "name" : "OC-051",
        "SUID" : 446,
        "Recipe_Name" : "Air Fryer Garlic Ribs (蒜香排骨)",
        "selected" : false
      },
      "position" : {
        "x" : -0.2613256321114932,
        "y" : 201.45362904920415
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "shared_name" : "WL-051",
        "name" : "WL-051",
        "SUID" : 440,
        "Recipe_Name" : "Fried Ribs with Fermented Red Bean Curd",
        "selected" : false
      },
      "position" : {
        "x" : -49.48440912820524,
        "y" : 65.84867909803228
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "shared_name" : "WC-025",
        "name" : "WC-025",
        "SUID" : 428,
        "Recipe_Name" : "Peking Duck",
        "selected" : false
      },
      "position" : {
        "x" : -150.12829950906462,
        "y" : 166.71608022107915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "shared_name" : "OC-025",
        "name" : "OC-025",
        "SUID" : 422,
        "Recipe_Name" : "Chinese Roast Duck (烤鸭)",
        "selected" : false
      },
      "position" : {
        "x" : -221.4715307102365,
        "y" : 89.0799107874854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "shared_name" : "WL-025",
        "name" : "WL-025",
        "SUID" : 416,
        "Recipe_Name" : "Roast Duck",
        "selected" : false
      },
      "position" : {
        "x" : -200.28763178445524,
        "y" : 131.8701939906104
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "shared_name" : "RM-024",
        "name" : "RM-024",
        "SUID" : 404,
        "Recipe_Name" : "Chinese Roast Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 315.9227621211844,
        "y" : 91.93980458631353
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "shared_name" : "WC-024",
        "name" : "WC-024",
        "SUID" : 398,
        "Recipe_Name" : "Soy Sauce Brined Five-Spice Oven-Roasted Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 284.6575662746268,
        "y" : 134.76554921521978
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "shared_name" : "OC-024",
        "name" : "OC-024",
        "SUID" : 392,
        "Recipe_Name" : "Cantonese Roast Chicken (广式烧鸡)",
        "selected" : false
      },
      "position" : {
        "x" : 286.0987856044608,
        "y" : -16.081222025014597
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "shared_name" : "ML-024",
        "name" : "ML-024",
        "SUID" : 386,
        "Recipe_Name" : "Whole Roasted Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 315.7812540187674,
        "y" : 41.6382603968604
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "shared_name" : "RM-023",
        "name" : "RM-023",
        "SUID" : 374,
        "Recipe_Name" : "Chinese Steamed Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 228.21683904074007,
        "y" : -483.2836908970849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "shared_name" : "WC-023",
        "name" : "WC-023",
        "SUID" : 368,
        "Recipe_Name" : "Steamed Chicken with Ginger and Scallion",
        "selected" : false
      },
      "position" : {
        "x" : 289.9679920329886,
        "y" : -403.07395884142085
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "shared_name" : "OC-023",
        "name" : "OC-023",
        "SUID" : 362,
        "Recipe_Name" : "Chinese Steamed Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 120.44421025656038,
        "y" : -475.8627848301904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "shared_name" : "ML-023",
        "name" : "ML-023",
        "SUID" : 356,
        "Recipe_Name" : "Steamed Chicken with Mushroom and Chinese Sausage",
        "selected" : false
      },
      "position" : {
        "x" : 176.55309697531038,
        "y" : -492.7306666050927
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "shared_name" : "WL-023",
        "name" : "WL-023",
        "SUID" : 350,
        "Recipe_Name" : "Steamed Chicken with Mushrooms & Dried Lily Flowers",
        "selected" : false
      },
      "position" : {
        "x" : 271.2979433193045,
        "y" : -453.0292429600732
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "shared_name" : "OC-020",
        "name" : "OC-020",
        "SUID" : 338,
        "Recipe_Name" : "Salt Baked Chicken (简易盐焗鸡)",
        "selected" : false
      },
      "position" : {
        "x" : 156.8678247585135,
        "y" : -258.65962931261225
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "shared_name" : "ML-020",
        "name" : "ML-020",
        "SUID" : 332,
        "Recipe_Name" : "Salt Baked Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 33.60641118429476,
        "y" : -246.65830942735835
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "shared_name" : "WL-020",
        "name" : "WL-020",
        "SUID" : 326,
        "Recipe_Name" : "Salt Baked Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 136.99424382589632,
        "y" : -63.86335703478022
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "shared_name" : "RM-014",
        "name" : "RM-014",
        "SUID" : 314,
        "Recipe_Name" : "Chestnut Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 40.89513799093538,
        "y" : -54.13264414415522
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "shared_name" : "OC-014",
        "name" : "OC-014",
        "SUID" : 308,
        "Recipe_Name" : "Braised Chestnut Chicken (板栗炖鸡)",
        "selected" : false
      },
      "position" : {
        "x" : -81.63699701883024,
        "y" : -211.0173792515771
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "shared_name" : "WL-014",
        "name" : "WL-014",
        "SUID" : 302,
        "Recipe_Name" : "Braised Chicken with Chestnuts – 栗子焖鸡",
        "selected" : false
      },
      "position" : {
        "x" : -104.84292963601774,
        "y" : -139.61074778185053
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "shared_name" : "RM-011",
        "name" : "RM-011",
        "SUID" : 290,
        "Recipe_Name" : "Chicken Chow Mein",
        "selected" : false
      },
      "position" : {
        "x" : -292.82425287820524,
        "y" : -49.60932871446772
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "shared_name" : "OC-011",
        "name" : "OC-011",
        "SUID" : 284,
        "Recipe_Name" : "Chicken Chow Mein (鸡肉炒面)",
        "selected" : false
      },
      "position" : {
        "x" : -321.976779733674,
        "y" : 49.62962392225103
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "shared_name" : "ML-011",
        "name" : "ML-011",
        "SUID" : 278,
        "Recipe_Name" : "Chow Mein",
        "selected" : false
      },
      "position" : {
        "x" : -295.791721139924,
        "y" : 96.86839345350103
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "shared_name" : "WL-011",
        "name" : "WL-011",
        "SUID" : 272,
        "Recipe_Name" : "Chicken Chow Mein",
        "selected" : false
      },
      "position" : {
        "x" : -320.5999486789865,
        "y" : -0.950881448842722
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "shared_name" : "RM-010",
        "name" : "RM-010",
        "SUID" : 260,
        "Recipe_Name" : "Chow Mein",
        "selected" : false
      },
      "position" : {
        "x" : -400.43777826883024,
        "y" : -212.3334955845849
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "shared_name" : "WC-010",
        "name" : "WC-010",
        "SUID" : 254,
        "Recipe_Name" : "Cantonese Supreme Soy Sauce Pan-Fried Noodles",
        "selected" : false
      },
      "position" : {
        "x" : -291.9944799289865,
        "y" : -348.3740639363305
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "shared_name" : "OC-010",
        "name" : "OC-010",
        "SUID" : 248,
        "Recipe_Name" : "Vegetarian Chow Mein (素菜炒面)",
        "selected" : false
      },
      "position" : {
        "x" : -379.404025827424,
        "y" : -316.6133608494775
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "shared_name" : "ML-010",
        "name" : "ML-010",
        "SUID" : 242,
        "Recipe_Name" : "Cantonese Chow Mein",
        "selected" : false
      },
      "position" : {
        "x" : -406.4544408664865,
        "y" : -268.25083872423335
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "shared_name" : "WL-010",
        "name" : "WL-010",
        "SUID" : 236,
        "Recipe_Name" : "Cantonese Soy Sauce Pan-Fried Noodles",
        "selected" : false
      },
      "position" : {
        "x" : -341.8008764133615,
        "y" : -341.33309694872065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "902",
        "shared_name" : "CH-142",
        "name" : "CH-142",
        "SUID" : 902,
        "Recipe_Name" : "Peanut Candy",
        "selected" : false
      },
      "position" : {
        "x" : 362.06858083151155,
        "y" : -21.137740579702097
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "872",
        "shared_name" : "CH-141",
        "name" : "CH-141",
        "SUID" : 872,
        "Recipe_Name" : "Gray Potato Pudding",
        "selected" : false
      },
      "position" : {
        "x" : 180.03016301534944,
        "y" : 327.0970006312354
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "842",
        "shared_name" : "CH-138",
        "name" : "CH-138",
        "SUID" : 842,
        "Recipe_Name" : "Chinese Sponge Cake",
        "selected" : false
      },
      "position" : {
        "x" : -65.09256342508024,
        "y" : -332.344684091665
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "812",
        "shared_name" : "CH-137",
        "name" : "CH-137",
        "SUID" : 812,
        "Recipe_Name" : "Almond Cake",
        "selected" : false
      },
      "position" : {
        "x" : -149.48804072000212,
        "y" : -101.71128794298335
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "788",
        "shared_name" : "CH-136",
        "name" : "CH-136",
        "SUID" : 788,
        "Recipe_Name" : "Chinese Meat Buscuit",
        "selected" : false
      },
      "position" : {
        "x" : -127.88565424539274,
        "y" : -189.95852610216303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "shared_name" : "CH-135",
        "name" : "CH-135",
        "SUID" : 752,
        "Recipe_Name" : "Fried Rice",
        "selected" : false
      },
      "position" : {
        "x" : -110.900119577424,
        "y" : 197.4114537562354
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "shared_name" : "CH-133",
        "name" : "CH-133",
        "SUID" : 716,
        "Recipe_Name" : "Stove Party",
        "selected" : false
      },
      "position" : {
        "x" : 118.18554326437288,
        "y" : -224.80906626329585
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "686",
        "shared_name" : "CH-115",
        "name" : "CH-115",
        "SUID" : 686,
        "Recipe_Name" : "Food of the Immortal God of Lawn Horn",
        "selected" : false
      },
      "position" : {
        "x" : -367.945773874299,
        "y" : -23.701003519155222
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "662",
        "shared_name" : "CH-112",
        "name" : "CH-112",
        "SUID" : 662,
        "Recipe_Name" : "Bean Buscuit",
        "selected" : false
      },
      "position" : {
        "x" : 39.74325200460726,
        "y" : 270.7209019984229
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "shared_name" : "CH-110",
        "name" : "CH-110",
        "SUID" : 638,
        "Recipe_Name" : "Stuffed Triangle Bean Cake",
        "selected" : false
      },
      "position" : {
        "x" : -53.94534662820524,
        "y" : 343.2321324671729
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "608",
        "shared_name" : "CH-092",
        "name" : "CH-092",
        "SUID" : 608,
        "Recipe_Name" : "Shrimp Omelet",
        "selected" : false
      },
      "position" : {
        "x" : -232.8519018039865,
        "y" : 312.4251256312354
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "shared_name" : "CH-089",
        "name" : "CH-089",
        "SUID" : 578,
        "Recipe_Name" : "Plain Omelet",
        "selected" : false
      },
      "position" : {
        "x" : -312.12527826883024,
        "y" : 168.65431264295415
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "shared_name" : "CH-067",
        "name" : "CH-067",
        "SUID" : 548,
        "Recipe_Name" : "Fried Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 194.68197270773226,
        "y" : -226.85238596544428
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "shared_name" : "CH-066",
        "name" : "CH-066",
        "SUID" : 524,
        "Recipe_Name" : "Steamed Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 135.7642328395682,
        "y" : 154.92128041639165
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "shared_name" : "CH-060",
        "name" : "CH-060",
        "SUID" : 488,
        "Recipe_Name" : "Steamed Pike",
        "selected" : false
      },
      "position" : {
        "x" : 315.9677765025931,
        "y" : 189.11134389295415
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "shared_name" : "CH-053",
        "name" : "CH-053",
        "SUID" : 458,
        "Recipe_Name" : "Green Pepper Beef",
        "selected" : false
      },
      "position" : {
        "x" : 264.10314961813265,
        "y" : -103.78095957384272
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "shared_name" : "CH-051",
        "name" : "CH-051",
        "SUID" : 434,
        "Recipe_Name" : "Fried Pigs' Ribs",
        "selected" : false
      },
      "position" : {
        "x" : 43.73153325460726,
        "y" : 107.2548375452979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "shared_name" : "CH-025",
        "name" : "CH-025",
        "SUID" : 410,
        "Recipe_Name" : "Roast Duck",
        "selected" : false
      },
      "position" : {
        "x" : -122.34708002664274,
        "y" : 67.92338612928228
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "shared_name" : "CH-024",
        "name" : "CH-024",
        "SUID" : 380,
        "Recipe_Name" : "Roast Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 214.37121220968538,
        "y" : 55.62431386365728
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "shared_name" : "CH-023",
        "name" : "CH-023",
        "SUID" : 344,
        "Recipe_Name" : "Steamed Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 179.81685277365023,
        "y" : -387.7926649724023
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "shared_name" : "CH-020",
        "name" : "CH-020",
        "SUID" : 320,
        "Recipe_Name" : "Salt Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 94.37984868429476,
        "y" : -154.51571604356928
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "shared_name" : "CH-014",
        "name" : "CH-014",
        "SUID" : 296,
        "Recipe_Name" : "Chestnut Chicken",
        "selected" : false
      },
      "position" : {
        "x" : -7.416995798127118,
        "y" : -138.27625986681147
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "shared_name" : "CH-011",
        "name" : "CH-011",
        "SUID" : 266,
        "Recipe_Name" : "Chicken Fried Noodles",
        "selected" : false
      },
      "position" : {
        "x" : -221.457004343049,
        "y" : 24.271042379282278
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "shared_name" : "CH-010",
        "name" : "CH-010",
        "SUID" : 185,
        "Recipe_Name" : "Fried Noodles",
        "selected" : false
      },
      "position" : {
        "x" : -302.7129857883615,
        "y" : -244.26634928331538
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "shared_name" : "The Chinese Cook Book",
        "name" : "The Chinese Cook Book",
        "SUID" : 183,
        "Recipe_Name" : "The Chinese Cook Book",
        "selected" : false
      },
      "position" : {
        "x" : 4.088436330779132,
        "y" : 2.598953756235403
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "4782",
        "source" : "926",
        "target" : "902",
        "Description" : "Substituted oil for butter",
        "shared_interaction" : "Update",
        "shared_name" : "RM-142 (Update) CH-142",
        "name" : "RM-142 (Update) CH-142",
        "interaction" : "Update",
        "SUID" : 4782,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4779",
        "source" : "926",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-142 (Insert) CH-142",
        "name" : "RM-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4779,
        "Ingredient_Affected" : "Baking_Soda",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4776",
        "source" : "926",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-142 (Insert) CH-142",
        "name" : "RM-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4776,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4773",
        "source" : "926",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-142 (Insert) CH-142",
        "name" : "RM-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4773,
        "Ingredient_Affected" : "Corn_Syrup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4769",
        "source" : "920",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-142 (Insert) CH-142",
        "name" : "WC-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4769,
        "Ingredient_Affected" : "Sesame_Seed",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4766",
        "source" : "920",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-142 (Insert) CH-142",
        "name" : "WC-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4766,
        "Ingredient_Affected" : "Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4763",
        "source" : "920",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-142 (Insert) CH-142",
        "name" : "WC-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4763,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4759",
        "source" : "914",
        "target" : "902",
        "Description" : "Substituted oil for butter",
        "shared_interaction" : "Update",
        "shared_name" : "OC-142 (Update) CH-142",
        "name" : "OC-142 (Update) CH-142",
        "interaction" : "Update",
        "SUID" : 4759,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4756",
        "source" : "914",
        "target" : "902",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-142 (Delete) CH-142",
        "name" : "OC-142 (Delete) CH-142",
        "interaction" : "Delete",
        "SUID" : 4756,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4753",
        "source" : "914",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-142 (Insert) CH-142",
        "name" : "OC-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4753,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4750",
        "source" : "914",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-142 (Insert) CH-142",
        "name" : "OC-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4750,
        "Ingredient_Affected" : "Honey",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4747",
        "source" : "914",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-142 (Insert) CH-142",
        "name" : "OC-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4747,
        "Ingredient_Affected" : "Sesame_Seed",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4744",
        "source" : "914",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-142 (Insert) CH-142",
        "name" : "OC-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4744,
        "Ingredient_Affected" : "Quinoa",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4740",
        "source" : "908",
        "target" : "902",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-142 (Delete) CH-142",
        "name" : "WL-142 (Delete) CH-142",
        "interaction" : "Delete",
        "SUID" : 4740,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4737",
        "source" : "908",
        "target" : "902",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-142 (Insert) CH-142",
        "name" : "WL-142 (Insert) CH-142",
        "interaction" : "Insert",
        "SUID" : 4737,
        "Ingredient_Affected" : "Sesame_Seed",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4733",
        "source" : "896",
        "target" : "872",
        "Description" : "Substituted shrimp for dried shrimp",
        "shared_interaction" : "Update",
        "shared_name" : "RM-141 (Update) CH-141",
        "name" : "RM-141 (Update) CH-141",
        "interaction" : "Update",
        "SUID" : 4733,
        "Ingredient_Affected" : "Shrimp",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4730",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-141 (Delete) CH-141",
        "name" : "RM-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4730,
        "Ingredient_Affected" : "Chinese_Gim_Flower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4727",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-141 (Delete) CH-141",
        "name" : "RM-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4727,
        "Ingredient_Affected" : "Chinese_Frankfurter",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4724",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-141 (Delete) CH-141",
        "name" : "RM-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4724,
        "Ingredient_Affected" : "Chinese_Olive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4721",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-141 (Delete) CH-141",
        "name" : "RM-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4721,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4718",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-141 (Insert) CH-141",
        "name" : "RM-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4718,
        "Ingredient_Affected" : "Red_Chili",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4715",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-141 (Insert) CH-141",
        "name" : "RM-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4715,
        "Ingredient_Affected" : "Shallot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4712",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-141 (Insert) CH-141",
        "name" : "RM-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4712,
        "Ingredient_Affected" : "Five_Spice_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4709",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-141 (Insert) CH-141",
        "name" : "RM-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4709,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4706",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-141 (Insert) CH-141",
        "name" : "RM-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4706,
        "Ingredient_Affected" : "Wheat_Starch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4703",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-141 (Insert) CH-141",
        "name" : "RM-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4703,
        "Ingredient_Affected" : "Rice_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4700",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-141 (Insert) CH-141",
        "name" : "RM-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4700,
        "Ingredient_Affected" : "Shallot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4697",
        "source" : "896",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-141 (Insert) CH-141",
        "name" : "RM-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4697,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4693",
        "source" : "890",
        "target" : "872",
        "Description" : "Substituted shrimp for dried shrimp",
        "shared_interaction" : "Update",
        "shared_name" : "WC-141 (Update) CH-141",
        "name" : "WC-141 (Update) CH-141",
        "interaction" : "Update",
        "SUID" : 4693,
        "Ingredient_Affected" : "Shrimp",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4690",
        "source" : "890",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-141 (Delete) CH-141",
        "name" : "WC-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4690,
        "Ingredient_Affected" : "Chinese_Gim_Flower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4687",
        "source" : "890",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-141 (Delete) CH-141",
        "name" : "WC-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4687,
        "Ingredient_Affected" : "Chinese_Olive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4684",
        "source" : "890",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-141 (Delete) CH-141",
        "name" : "WC-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4684,
        "Ingredient_Affected" : "Chinese_Frankfurter",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4681",
        "source" : "890",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-141 (Delete) CH-141",
        "name" : "WC-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4681,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4678",
        "source" : "890",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-141 (Insert) CH-141",
        "name" : "WC-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4678,
        "Ingredient_Affected" : "Red_Chili",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4675",
        "source" : "890",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-141 (Insert) CH-141",
        "name" : "WC-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4675,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4672",
        "source" : "890",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-141 (Insert) CH-141",
        "name" : "WC-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4672,
        "Ingredient_Affected" : "Shallot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4669",
        "source" : "890",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-141 (Insert) CH-141",
        "name" : "WC-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4669,
        "Ingredient_Affected" : "Cooking_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4666",
        "source" : "890",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-141 (Insert) CH-141",
        "name" : "WC-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4666,
        "Ingredient_Affected" : "Five_Spice_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4663",
        "source" : "890",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-141 (Insert) CH-141",
        "name" : "WC-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4663,
        "Ingredient_Affected" : "Rice_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4659",
        "source" : "884",
        "target" : "872",
        "Description" : "Substituted shrimp for dried shrimp",
        "shared_interaction" : "Update",
        "shared_name" : "ML-141 (Update) CH-141",
        "name" : "ML-141 (Update) CH-141",
        "interaction" : "Update",
        "SUID" : 4659,
        "Ingredient_Affected" : "Shrimp",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4656",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-141 (Delete) CH-141",
        "name" : "ML-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4656,
        "Ingredient_Affected" : "Chinese_Gim_Flower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4653",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-141 (Delete) CH-141",
        "name" : "ML-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4653,
        "Ingredient_Affected" : "Chinese_Olive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4650",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-141 (Delete) CH-141",
        "name" : "ML-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4650,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4647",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-141 (Insert) CH-141",
        "name" : "ML-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4647,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4644",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-141 (Insert) CH-141",
        "name" : "ML-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4644,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4641",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-141 (Insert) CH-141",
        "name" : "ML-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4641,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4638",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-141 (Insert) CH-141",
        "name" : "ML-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4638,
        "Ingredient_Affected" : "Chicken_Bouillon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4635",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-141 (Insert) CH-141",
        "name" : "ML-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4635,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4632",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-141 (Insert) CH-141",
        "name" : "ML-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4632,
        "Ingredient_Affected" : "Vegetable_oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4629",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-141 (Insert) CH-141",
        "name" : "ML-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4629,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4626",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-141 (Insert) CH-141",
        "name" : "ML-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4626,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4623",
        "source" : "884",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-141 (Insert) CH-141",
        "name" : "ML-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4623,
        "Ingredient_Affected" : "Rice_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4619",
        "source" : "878",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-141 (Delete) CH-141",
        "name" : "WL-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4619,
        "Ingredient_Affected" : "Chinese_Gim_Flower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4616",
        "source" : "878",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-141 (Delete) CH-141",
        "name" : "WL-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4616,
        "Ingredient_Affected" : "Chinese_Olive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4613",
        "source" : "878",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-141 (Delete) CH-141",
        "name" : "WL-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4613,
        "Ingredient_Affected" : "Shrimp",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4610",
        "source" : "878",
        "target" : "872",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-141 (Delete) CH-141",
        "name" : "WL-141 (Delete) CH-141",
        "interaction" : "Delete",
        "SUID" : 4610,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4607",
        "source" : "878",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-141 (Insert) CH-141",
        "name" : "WL-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4607,
        "Ingredient_Affected" : "Glutinous_Rice_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4604",
        "source" : "878",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-141 (Insert) CH-141",
        "name" : "WL-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4604,
        "Ingredient_Affected" : "Rice_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4601",
        "source" : "878",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-141 (Insert) CH-141",
        "name" : "WL-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4601,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4598",
        "source" : "878",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-141 (Insert) CH-141",
        "name" : "WL-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4598,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4595",
        "source" : "878",
        "target" : "872",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-141 (Insert) CH-141",
        "name" : "WL-141 (Insert) CH-141",
        "interaction" : "Insert",
        "SUID" : 4595,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4591",
        "source" : "866",
        "target" : "842",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-138 (Delete) CH-138",
        "name" : "RM-138 (Delete) CH-138",
        "interaction" : "Delete",
        "SUID" : 4591,
        "Ingredient_Affected" : "Lemon_Juice",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4588",
        "source" : "866",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-138 (Insert) CH-138",
        "name" : "RM-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4588,
        "Ingredient_Affected" : "Unsalted_Butter",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4585",
        "source" : "866",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-138 (Insert) CH-138",
        "name" : "RM-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4585,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4581",
        "source" : "860",
        "target" : "842",
        "Description" : "Substituted lemon juice for vinegar",
        "shared_interaction" : "Update",
        "shared_name" : "WC-138 (Update) CH-138",
        "name" : "WC-138 (Update) CH-138",
        "interaction" : "Update",
        "SUID" : 4581,
        "Ingredient_Affected" : "Lemon_Juice",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4578",
        "source" : "860",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-138 (Insert) CH-138",
        "name" : "WC-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4578,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4575",
        "source" : "860",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-138 (Insert) CH-138",
        "name" : "WC-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4575,
        "Ingredient_Affected" : "Vanilla",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4572",
        "source" : "860",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-138 (Insert) CH-138",
        "name" : "WC-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4572,
        "Ingredient_Affected" : "Neutral_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4569",
        "source" : "860",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-138 (Insert) CH-138",
        "name" : "WC-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4569,
        "Ingredient_Affected" : "Milk",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4565",
        "source" : "854",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-138 (Insert) CH-138",
        "name" : "OC-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4565,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4562",
        "source" : "854",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-138 (Insert) CH-138",
        "name" : "OC-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4562,
        "Ingredient_Affected" : "Vanilla",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4559",
        "source" : "854",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-138 (Insert) CH-138",
        "name" : "OC-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4559,
        "Ingredient_Affected" : "Neutral_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4556",
        "source" : "854",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-138 (Insert) CH-138",
        "name" : "OC-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4556,
        "Ingredient_Affected" : "Milk",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4552",
        "source" : "848",
        "target" : "842",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-138 (Delete) CH-138",
        "name" : "WL-138 (Delete) CH-138",
        "interaction" : "Delete",
        "SUID" : 4552,
        "Ingredient_Affected" : "Lemon_Juice",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4549",
        "source" : "848",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-138 (Insert) CH-138",
        "name" : "WL-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4549,
        "Ingredient_Affected" : "Honey",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4546",
        "source" : "848",
        "target" : "842",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-138 (Insert) CH-138",
        "name" : "WL-138 (Insert) CH-138",
        "interaction" : "Insert",
        "SUID" : 4546,
        "Ingredient_Affected" : "Neutral_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4542",
        "source" : "836",
        "target" : "812",
        "Description" : "Substituted lard for shortening",
        "shared_interaction" : "Update",
        "shared_name" : "RM-137 (Update) CH-137",
        "name" : "RM-137 (Update) CH-137",
        "interaction" : "Update",
        "SUID" : 4542,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4539",
        "source" : "836",
        "target" : "812",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-137 (Delete) CH-137",
        "name" : "RM-137 (Delete) CH-137",
        "interaction" : "Delete",
        "SUID" : 4539,
        "Ingredient_Affected" : "Alkaline_Solution",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4536",
        "source" : "836",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-137 (Insert) CH-137",
        "name" : "RM-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4536,
        "Ingredient_Affected" : "Almond_Extract",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4533",
        "source" : "836",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-137 (Insert) CH-137",
        "name" : "RM-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4533,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4530",
        "source" : "836",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-137 (Insert) CH-137",
        "name" : "RM-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4530,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4526",
        "source" : "830",
        "target" : "812",
        "Description" : "Substituted lard for cooking oil",
        "shared_interaction" : "Update",
        "shared_name" : "WC-137 (Update) CH-137",
        "name" : "WC-137 (Update) CH-137",
        "interaction" : "Update",
        "SUID" : 4526,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4523",
        "source" : "830",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-137 (Insert) CH-137",
        "name" : "WC-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4523,
        "Ingredient_Affected" : "Baking_Soda",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4520",
        "source" : "830",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-137 (Insert) CH-137",
        "name" : "WC-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4520,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4517",
        "source" : "830",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-137 (Insert) CH-137",
        "name" : "WC-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4517,
        "Ingredient_Affected" : "Almond_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4513",
        "source" : "824",
        "target" : "812",
        "Description" : "Substituted lard for unsalted butter",
        "shared_interaction" : "Update",
        "shared_name" : "OC-137 (Update) CH-137",
        "name" : "OC-137 (Update) CH-137",
        "interaction" : "Update",
        "SUID" : 4513,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4510",
        "source" : "824",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-137 (Insert) CH-137",
        "name" : "OC-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4510,
        "Ingredient_Affected" : "Almond_Extract",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4507",
        "source" : "824",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-137 (Insert) CH-137",
        "name" : "OC-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4507,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4504",
        "source" : "824",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-137 (Insert) CH-137",
        "name" : "OC-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4504,
        "Ingredient_Affected" : "Almond_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4500",
        "source" : "818",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-137 (Insert) CH-137",
        "name" : "WL-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4500,
        "Ingredient_Affected" : "Salted_Butter",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4497",
        "source" : "818",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-137 (Insert) CH-137",
        "name" : "WL-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4497,
        "Ingredient_Affected" : "Almond_Extract",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4494",
        "source" : "818",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-137 (Insert) CH-137",
        "name" : "WL-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4494,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4491",
        "source" : "818",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-137 (Insert) CH-137",
        "name" : "WL-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4491,
        "Ingredient_Affected" : "Baking_Soda",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4488",
        "source" : "818",
        "target" : "812",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-137 (Insert) CH-137",
        "name" : "WL-137 (Insert) CH-137",
        "interaction" : "Insert",
        "SUID" : 4488,
        "Ingredient_Affected" : "Almond_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4484",
        "source" : "806",
        "target" : "788",
        "Description" : "Substituted lard for cooking oil",
        "shared_interaction" : "Update",
        "shared_name" : "WC-136 (Update) CH-136",
        "name" : "WC-136 (Update) CH-136",
        "interaction" : "Update",
        "SUID" : 4484,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4481",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-136 (Delete) CH-136",
        "name" : "WC-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4481,
        "Ingredient_Affected" : "Red_Cheese",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4478",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-136 (Delete) CH-136",
        "name" : "WC-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4478,
        "Ingredient_Affected" : "Chinese_Frankfurter",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4475",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-136 (Delete) CH-136",
        "name" : "WC-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4475,
        "Ingredient_Affected" : "Potato",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4472",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-136 (Insert) CH-136",
        "name" : "WC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4472,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4469",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-136 (Insert) CH-136",
        "name" : "WC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4469,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4466",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-136 (Insert) CH-136",
        "name" : "WC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4466,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4463",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-136 (Insert) CH-136",
        "name" : "WC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4463,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4460",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-136 (Insert) CH-136",
        "name" : "WC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4460,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4457",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-136 (Insert) CH-136",
        "name" : "WC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4457,
        "Ingredient_Affected" : "Milk",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4454",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-136 (Insert) CH-136",
        "name" : "WC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4454,
        "Ingredient_Affected" : "Baking_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4451",
        "source" : "806",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-136 (Insert) CH-136",
        "name" : "WC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4451,
        "Ingredient_Affected" : "Wheat_Starch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4447",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-136 (Delete) CH-136",
        "name" : "OC-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4447,
        "Ingredient_Affected" : "Red_Cheese",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4444",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-136 (Delete) CH-136",
        "name" : "OC-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4444,
        "Ingredient_Affected" : "Chinese_Frankfurter",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4441",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-136 (Delete) CH-136",
        "name" : "OC-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4441,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4438",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-136 (Delete) CH-136",
        "name" : "OC-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4438,
        "Ingredient_Affected" : "Potato",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4435",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-136 (Insert) CH-136",
        "name" : "OC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4435,
        "Ingredient_Affected" : "Chinese_Chive",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4432",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-136 (Insert) CH-136",
        "name" : "OC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4432,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4429",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-136 (Insert) CH-136",
        "name" : "OC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4429,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4426",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-136 (Insert) CH-136",
        "name" : "OC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4426,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4423",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-136 (Insert) CH-136",
        "name" : "OC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4423,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4420",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-136 (Insert) CH-136",
        "name" : "OC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4420,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4417",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-136 (Insert) CH-136",
        "name" : "OC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4417,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4414",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-136 (Insert) CH-136",
        "name" : "OC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4414,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4411",
        "source" : "800",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-136 (Insert) CH-136",
        "name" : "OC-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4411,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4407",
        "source" : "794",
        "target" : "788",
        "Description" : "Substituted lard for vegetable oil",
        "shared_interaction" : "Update",
        "shared_name" : "WL-136 (Update) CH-136",
        "name" : "WL-136 (Update) CH-136",
        "interaction" : "Update",
        "SUID" : 4407,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4404",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-136 (Delete) CH-136",
        "name" : "WL-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4404,
        "Ingredient_Affected" : "Red_Cheese",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4401",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-136 (Delete) CH-136",
        "name" : "WL-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4401,
        "Ingredient_Affected" : "Chinese_Frankfurter",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4398",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-136 (Delete) CH-136",
        "name" : "WL-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4398,
        "Ingredient_Affected" : "Potato",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4395",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-136 (Delete) CH-136",
        "name" : "WL-136 (Delete) CH-136",
        "interaction" : "Delete",
        "SUID" : 4395,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4392",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4392,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4389",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4389,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4386",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4386,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4383",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4383,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4380",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4380,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4377",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4377,
        "Ingredient_Affected" : "Group_Bean_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4374",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4374,
        "Ingredient_Affected" : "Sweet_Bean_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4371",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4371,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4368",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4368,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4365",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4365,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4362",
        "source" : "794",
        "target" : "788",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-136 (Insert) CH-136",
        "name" : "WL-136 (Insert) CH-136",
        "interaction" : "Insert",
        "SUID" : 4362,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4358",
        "source" : "782",
        "target" : "752",
        "Description" : "Substituted chicken for Chinese sausage",
        "shared_interaction" : "Update",
        "shared_name" : "RM-135 (Update) CH-135",
        "name" : "RM-135 (Update) CH-135",
        "interaction" : "Update",
        "SUID" : 4358,
        "Ingredient_Affected" : "Chicken",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4355",
        "source" : "782",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-135 (Delete) CH-135",
        "name" : "RM-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4355,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4352",
        "source" : "782",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-135 (Delete) CH-135",
        "name" : "RM-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4352,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4349",
        "source" : "782",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-135 (Insert) CH-135",
        "name" : "RM-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4349,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4346",
        "source" : "782",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-135 (Insert) CH-135",
        "name" : "RM-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4346,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4343",
        "source" : "782",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-135 (Insert) CH-135",
        "name" : "RM-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4343,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4340",
        "source" : "782",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-135 (Insert) CH-135",
        "name" : "RM-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4340,
        "Ingredient_Affected" : "Fish_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4337",
        "source" : "782",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-135 (Insert) CH-135",
        "name" : "RM-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4337,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4333",
        "source" : "776",
        "target" : "752",
        "Description" : "Substituted oil for butter",
        "shared_interaction" : "Update",
        "shared_name" : "WC-135 (Update) CH-135",
        "name" : "WC-135 (Update) CH-135",
        "interaction" : "Update",
        "SUID" : 4333,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4330",
        "source" : "776",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-135 (Delete) CH-135",
        "name" : "WC-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4330,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4327",
        "source" : "776",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-135 (Delete) CH-135",
        "name" : "WC-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4327,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4324",
        "source" : "776",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-135 (Delete) CH-135",
        "name" : "WC-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4324,
        "Ingredient_Affected" : "Chicken",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4321",
        "source" : "776",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-135 (Insert) CH-135",
        "name" : "WC-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4321,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4318",
        "source" : "776",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-135 (Insert) CH-135",
        "name" : "WC-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4318,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4315",
        "source" : "776",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-135 (Insert) CH-135",
        "name" : "WC-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4315,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4311",
        "source" : "770",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-135 (Delete) CH-135",
        "name" : "OC-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4311,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4308",
        "source" : "770",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-135 (Delete) CH-135",
        "name" : "OC-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4308,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4305",
        "source" : "770",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-135 (Delete) CH-135",
        "name" : "OC-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4305,
        "Ingredient_Affected" : "Chicken",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4302",
        "source" : "770",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-135 (Insert) CH-135",
        "name" : "OC-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4302,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4298",
        "source" : "764",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-135 (Delete) CH-135",
        "name" : "ML-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4298,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4295",
        "source" : "764",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-135 (Delete) CH-135",
        "name" : "ML-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4295,
        "Ingredient_Affected" : "Chicken",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4292",
        "source" : "764",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-135 (Insert) CH-135",
        "name" : "ML-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4292,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4289",
        "source" : "764",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-135 (Insert) CH-135",
        "name" : "ML-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4289,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4286",
        "source" : "764",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-135 (Insert) CH-135",
        "name" : "ML-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4286,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4283",
        "source" : "764",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-135 (Insert) CH-135",
        "name" : "ML-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4283,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4279",
        "source" : "758",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-135 (Delete) CH-135",
        "name" : "WL-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4279,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4276",
        "source" : "758",
        "target" : "752",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-135 (Delete) CH-135",
        "name" : "WL-135 (Delete) CH-135",
        "interaction" : "Delete",
        "SUID" : 4276,
        "Ingredient_Affected" : "Chicken",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4273",
        "source" : "758",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-135 (Insert) CH-135",
        "name" : "WL-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4273,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4270",
        "source" : "758",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-135 (Insert) CH-135",
        "name" : "WL-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4270,
        "Ingredient_Affected" : "Black_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4267",
        "source" : "758",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-135 (Insert) CH-135",
        "name" : "WL-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4267,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4264",
        "source" : "758",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-135 (Insert) CH-135",
        "name" : "WL-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4264,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4261",
        "source" : "758",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-135 (Insert) CH-135",
        "name" : "WL-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4261,
        "Ingredient_Affected" : "Turmeric",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4258",
        "source" : "758",
        "target" : "752",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-135 (Insert) CH-135",
        "name" : "WL-135 (Insert) CH-135",
        "interaction" : "Insert",
        "SUID" : 4258,
        "Ingredient_Affected" : "Paprika",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4254",
        "source" : "746",
        "target" : "716",
        "Description" : "Substituted pike for salmon",
        "shared_interaction" : "Update",
        "shared_name" : "RM-133 (Update) CH-133",
        "name" : "RM-133 (Update) CH-133",
        "interaction" : "Update",
        "SUID" : 4254,
        "Ingredient_Affected" : "Pike",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4251",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-133 (Delete) CH-133",
        "name" : "RM-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 4251,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4248",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-133 (Delete) CH-133",
        "name" : "RM-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 4248,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4245",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-133 (Delete) CH-133",
        "name" : "RM-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 4245,
        "Ingredient_Affected" : "Flat_Fish",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4242",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-133 (Delete) CH-133",
        "name" : "RM-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 4242,
        "Ingredient_Affected" : "Beef",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4239",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-133 (Insert) CH-133",
        "name" : "RM-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4239,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4236",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-133 (Insert) CH-133",
        "name" : "RM-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4236,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4233",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-133 (Insert) CH-133",
        "name" : "RM-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4233,
        "Ingredient_Affected" : "Bok_Choy",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4230",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-133 (Insert) CH-133",
        "name" : "RM-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4230,
        "Ingredient_Affected" : "Scallop",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4227",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-133 (Insert) CH-133",
        "name" : "RM-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4227,
        "Ingredient_Affected" : "White_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4224",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-133 (Insert) CH-133",
        "name" : "RM-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4224,
        "Ingredient_Affected" : "Shiitake_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4221",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-133 (Insert) CH-133",
        "name" : "RM-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4221,
        "Ingredient_Affected" : "Tofu",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4218",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-133 (Insert) CH-133",
        "name" : "RM-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4218,
        "Ingredient_Affected" : "Fish_Ball",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4215",
        "source" : "746",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-133 (Insert) CH-133",
        "name" : "RM-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4215,
        "Ingredient_Affected" : "Napa_Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4211",
        "source" : "740",
        "target" : "716",
        "Description" : "Substituted egg for quail egg",
        "shared_interaction" : "Update",
        "shared_name" : "WC-133 (Update) CH-133",
        "name" : "WC-133 (Update) CH-133",
        "interaction" : "Update",
        "SUID" : 4211,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4208",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-133 (Delete) CH-133",
        "name" : "WC-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 4208,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4205",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-133 (Delete) CH-133",
        "name" : "WC-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 4205,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4202",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-133 (Delete) CH-133",
        "name" : "WC-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 4202,
        "Ingredient_Affected" : "Chicken",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4199",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4199,
        "Ingredient_Affected" : "Sesame_Paste",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4196",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4196,
        "Ingredient_Affected" : "Sambal_Oelek",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4193",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4193,
        "Ingredient_Affected" : "Birds_Eye_Chili",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4190",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4190,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4187",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4187,
        "Ingredient_Affected" : "Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4184",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4184,
        "Ingredient_Affected" : "Chrysanthemum_Leaf",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4181",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4181,
        "Ingredient_Affected" : "Napa_Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4178",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4178,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4175",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4175,
        "Ingredient_Affected" : "Tofu",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4172",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4172,
        "Ingredient_Affected" : "Fish_Ball",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4169",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4169,
        "Ingredient_Affected" : "Beef_Ball",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4166",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4166,
        "Ingredient_Affected" : "Fish_Cake",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4163",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4163,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4160",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4160,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4157",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4157,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4154",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4154,
        "Ingredient_Affected" : "Chicken_Bouillon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4151",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4151,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4148",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4148,
        "Ingredient_Affected" : "Red_Date",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4145",
        "source" : "740",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-133 (Insert) CH-133",
        "name" : "WC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4145,
        "Ingredient_Affected" : "Daikon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4141",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-133 (Delete) CH-133",
        "name" : "OC-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 4141,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4138",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-133 (Delete) CH-133",
        "name" : "OC-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 4138,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4135",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4135,
        "Ingredient_Affected" : "Cilantro",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4132",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4132,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4129",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4129,
        "Ingredient_Affected" : "Shacha_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4126",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4126,
        "Ingredient_Affected" : "Sesame_Paste",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4123",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4123,
        "Ingredient_Affected" : "Chili_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4120",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4120,
        "Ingredient_Affected" : "Sesame_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4117",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4117,
        "Ingredient_Affected" : "Dumpling",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4114",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4114,
        "Ingredient_Affected" : "Rice_Cake",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4111",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4111,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4108",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4108,
        "Ingredient_Affected" : "Noodle",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4105",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4105,
        "Ingredient_Affected" : "Corn",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4102",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4102,
        "Ingredient_Affected" : "Squash",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4099",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4099,
        "Ingredient_Affected" : "Daikon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4096",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4096,
        "Ingredient_Affected" : "Sweet_Potato",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4093",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4093,
        "Ingredient_Affected" : "Potato",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4090",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4090,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4087",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4087,
        "Ingredient_Affected" : "Lotus_Root",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4084",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4084,
        "Ingredient_Affected" : "Celtuce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4081",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4081,
        "Ingredient_Affected" : "Winter_Melon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4078",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4078,
        "Ingredient_Affected" : "Chinese_Cauliflower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4075",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4075,
        "Ingredient_Affected" : "Chrysanthemum_Leaf",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4072",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4072,
        "Ingredient_Affected" : "Watercress",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4069",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4069,
        "Ingredient_Affected" : "Snow_Pea_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4066",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4066,
        "Ingredient_Affected" : "Spinach",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4063",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4063,
        "Ingredient_Affected" : "Yu_Choy",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4060",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4060,
        "Ingredient_Affected" : "Chinese_Broccoli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4057",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4057,
        "Ingredient_Affected" : "Bok_Choy",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4054",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4054,
        "Ingredient_Affected" : "Napa_Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4051",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4051,
        "Ingredient_Affected" : "Oyster_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4048",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4048,
        "Ingredient_Affected" : "Wood_Ear_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4045",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4045,
        "Ingredient_Affected" : "Shiitake_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4042",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4042,
        "Ingredient_Affected" : "King_Oyster_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4039",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4039,
        "Ingredient_Affected" : "ShimejI_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4036",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4036,
        "Ingredient_Affected" : "Enoki_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4033",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4033,
        "Ingredient_Affected" : "Fried_Tofu_Puff",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4030",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4030,
        "Ingredient_Affected" : "Tofu_Stick",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4027",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4027,
        "Ingredient_Affected" : "Tofu_Knot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4024",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4024,
        "Ingredient_Affected" : "Yuba_Sheet",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4021",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4021,
        "Ingredient_Affected" : "Tofu",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4018",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4018,
        "Ingredient_Affected" : "Fish_Tofu",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4015",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4015,
        "Ingredient_Affected" : "Fish_Cake",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4012",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4012,
        "Ingredient_Affected" : "Shrimp_Cake",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4009",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4009,
        "Ingredient_Affected" : "Scallop",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4006",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4006,
        "Ingredient_Affected" : "Squid",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4003",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4003,
        "Ingredient_Affected" : "Beef_Ball",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4000",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 4000,
        "Ingredient_Affected" : "Fish_Ball",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3997",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3997,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3994",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3994,
        "Ingredient_Affected" : "Lamb",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3991",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3991,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3988",
        "source" : "734",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-133 (Insert) CH-133",
        "name" : "OC-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3988,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3984",
        "source" : "728",
        "target" : "716",
        "Description" : "Substituted oil for olive oil",
        "shared_interaction" : "Update",
        "shared_name" : "ML-133 (Update) CH-133",
        "name" : "ML-133 (Update) CH-133",
        "interaction" : "Update",
        "SUID" : 3984,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3981",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-133 (Delete) CH-133",
        "name" : "ML-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 3981,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3978",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3978,
        "Ingredient_Affected" : "Dried_Mandarin_Peel",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3975",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3975,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3972",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3972,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3969",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3969,
        "Ingredient_Affected" : "Cilantro",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3966",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3966,
        "Ingredient_Affected" : "Chili_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3963",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3963,
        "Ingredient_Affected" : "Chicken_Bouillon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3960",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3960,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3957",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3957,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3954",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3954,
        "Ingredient_Affected" : "Shacha_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3951",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3951,
        "Ingredient_Affected" : "Baking_Soda",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3948",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3948,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3945",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3945,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3942",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3942,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3939",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3939,
        "Ingredient_Affected" : "Daikon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3936",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3936,
        "Ingredient_Affected" : "King_Oyster_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3933",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3933,
        "Ingredient_Affected" : "Seafood_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3930",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3930,
        "Ingredient_Affected" : "Chinese_Broccoli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3927",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3927,
        "Ingredient_Affected" : "Spinach",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3924",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3924,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3921",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3921,
        "Ingredient_Affected" : "Tofu",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3918",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3918,
        "Ingredient_Affected" : "Squid",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3915",
        "source" : "728",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-133 (Insert) CH-133",
        "name" : "ML-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3915,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3911",
        "source" : "722",
        "target" : "716",
        "Description" : "Substituted primary soup for spicy hot pot soup base",
        "shared_interaction" : "Update",
        "shared_name" : "WL-133 (Update) CH-133",
        "name" : "WL-133 (Update) CH-133",
        "interaction" : "Update",
        "SUID" : 3911,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3908",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-133 (Delete) CH-133",
        "name" : "WL-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 3908,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3905",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-133 (Delete) CH-133",
        "name" : "WL-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 3905,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3902",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-133 (Delete) CH-133",
        "name" : "WL-133 (Delete) CH-133",
        "interaction" : "Delete",
        "SUID" : 3902,
        "Ingredient_Affected" : "Shrimp",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3899",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3899,
        "Ingredient_Affected" : "Napa_Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3896",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3896,
        "Ingredient_Affected" : "Lettuce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3893",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3893,
        "Ingredient_Affected" : "Bok_Choy",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3890",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3890,
        "Ingredient_Affected" : "Rice_Cake",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3887",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3887,
        "Ingredient_Affected" : "Dumpling",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3884",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3884,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3881",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3881,
        "Ingredient_Affected" : "Wood_Ear_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3878",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3878,
        "Ingredient_Affected" : "Shiitake_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3875",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3875,
        "Ingredient_Affected" : "Straw_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3872",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3872,
        "Ingredient_Affected" : "Fried_Tofu_Puff",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3869",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3869,
        "Ingredient_Affected" : "Tofu",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3866",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3866,
        "Ingredient_Affected" : "Tofu_Sheet",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3863",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3863,
        "Ingredient_Affected" : "Fish_Ball",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3860",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3860,
        "Ingredient_Affected" : "Lamb",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3857",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3857,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3854",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3854,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3851",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3851,
        "Ingredient_Affected" : "Cilantro",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3848",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3848,
        "Ingredient_Affected" : "Peanut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3845",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3845,
        "Ingredient_Affected" : "Sesame_Seed",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3842",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3842,
        "Ingredient_Affected" : "Sesame_Paste",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3839",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3839,
        "Ingredient_Affected" : "Chinese_Black_Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3836",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3836,
        "Ingredient_Affected" : "Chili_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3833",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3833,
        "Ingredient_Affected" : "Shacha_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3830",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3830,
        "Ingredient_Affected" : "Dried_Red_Chili",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3827",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3827,
        "Ingredient_Affected" : "Sichuan_Peppercorn",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3824",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3824,
        "Ingredient_Affected" : "Clove",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3821",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3821,
        "Ingredient_Affected" : "Star_Anise",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3818",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3818,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3815",
        "source" : "722",
        "target" : "716",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-133 (Insert) CH-133",
        "name" : "WL-133 (Insert) CH-133",
        "interaction" : "Insert",
        "SUID" : 3815,
        "Ingredient_Affected" : "Bay_Leaf",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3811",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-115 (Delete) CH-115",
        "name" : "WC-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3811,
        "Ingredient_Affected" : "Fungus",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3808",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-115 (Delete) CH-115",
        "name" : "WC-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3808,
        "Ingredient_Affected" : "White_Nut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3805",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3805,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3802",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3802,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3799",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3799,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3796",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3796,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3793",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3793,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3790",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3790,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3787",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3787,
        "Ingredient_Affected" : "Bok_Choy",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3784",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3784,
        "Ingredient_Affected" : "Napa_Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3781",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3781,
        "Ingredient_Affected" : "Dried_Shiitake_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3778",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3778,
        "Ingredient_Affected" : "Dried_Lily_Flower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3775",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3775,
        "Ingredient_Affected" : "Vegetable_Stock",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3772",
        "source" : "710",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-115 (Insert) CH-115",
        "name" : "WC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3772,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3768",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-115 (Delete) CH-115",
        "name" : "OC-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3768,
        "Ingredient_Affected" : "Bean_Stick",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3765",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-115 (Delete) CH-115",
        "name" : "OC-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3765,
        "Ingredient_Affected" : "Fungus",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3762",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-115 (Delete) CH-115",
        "name" : "OC-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3762,
        "Ingredient_Affected" : "White_Nut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3759",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-115 (Delete) CH-115",
        "name" : "OC-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3759,
        "Ingredient_Affected" : "Tofu",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3756",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3756,
        "Ingredient_Affected" : "Napa_Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3753",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3753,
        "Ingredient_Affected" : "Bok_Choy",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3750",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3750,
        "Ingredient_Affected" : "Fried_Tofu_Puff",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3747",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3747,
        "Ingredient_Affected" : "Carrot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3744",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3744,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3741",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3741,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3738",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3738,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3735",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3735,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3732",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3732,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3729",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3729,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3726",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3726,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3723",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3723,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3720",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3720,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3717",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3717,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3714",
        "source" : "704",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-115 (Insert) CH-115",
        "name" : "OC-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3714,
        "Ingredient_Affected" : "Dried_Lily_Flower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3710",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-115 (Delete) CH-115",
        "name" : "ML-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3710,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3707",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-115 (Delete) CH-115",
        "name" : "ML-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3707,
        "Ingredient_Affected" : "Bean_Stick",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3704",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-115 (Delete) CH-115",
        "name" : "ML-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3704,
        "Ingredient_Affected" : "White_Nut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3701",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-115 (Delete) CH-115",
        "name" : "ML-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3701,
        "Ingredient_Affected" : "Tofu",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3698",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3698,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3695",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3695,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3692",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3692,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3689",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3689,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3686",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3686,
        "Ingredient_Affected" : "Red_Fermented_Bean_Curd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3683",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3683,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3680",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3680,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3677",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3677,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3674",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3674,
        "Ingredient_Affected" : "Cooking_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3671",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3671,
        "Ingredient_Affected" : "Tamari_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3668",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3668,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3665",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3665,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3662",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3662,
        "Ingredient_Affected" : "Sugar_Snap_Pea",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3659",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3659,
        "Ingredient_Affected" : "Corn",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3656",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3656,
        "Ingredient_Affected" : "Carrot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3653",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3653,
        "Ingredient_Affected" : "Napa_Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3650",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3650,
        "Ingredient_Affected" : "Celery",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3647",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3647,
        "Ingredient_Affected" : "King_Oyster_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3644",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3644,
        "Ingredient_Affected" : "Seafood_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3641",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3641,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3638",
        "source" : "698",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-115 (Insert) CH-115",
        "name" : "ML-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3638,
        "Ingredient_Affected" : "Bamboo_Fungus",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3634",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-115 (Delete) CH-115",
        "name" : "WL-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3634,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3631",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-115 (Delete) CH-115",
        "name" : "WL-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3631,
        "Ingredient_Affected" : "Fungus",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3628",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-115 (Delete) CH-115",
        "name" : "WL-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3628,
        "Ingredient_Affected" : "White_Nut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3625",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-115 (Delete) CH-115",
        "name" : "WL-115 (Delete) CH-115",
        "interaction" : "Delete",
        "SUID" : 3625,
        "Ingredient_Affected" : "Tofu",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3622",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3622,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3619",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3619,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3616",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3616,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3613",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3613,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3610",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3610,
        "Ingredient_Affected" : "Fried_Tofu_Puff",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3607",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3607,
        "Ingredient_Affected" : "Napa_Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3604",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3604,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3601",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3601,
        "Ingredient_Affected" : "Dried_Lily_Flower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3598",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3598,
        "Ingredient_Affected" : "Shiitake_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3595",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3595,
        "Ingredient_Affected" : "Leek",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3592",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3592,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3589",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3589,
        "Ingredient_Affected" : "Red_Fermented_Bean_Curd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3586",
        "source" : "692",
        "target" : "686",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-115 (Insert) CH-115",
        "name" : "WL-115 (Insert) CH-115",
        "interaction" : "Insert",
        "SUID" : 3586,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3582",
        "source" : "680",
        "target" : "662",
        "Description" : "Substituted lard for oil",
        "shared_interaction" : "Update",
        "shared_name" : "WC-112 (Update) CH-112",
        "name" : "WC-112 (Update) CH-112",
        "interaction" : "Update",
        "SUID" : 3582,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3579",
        "source" : "680",
        "target" : "662",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-112 (Delete) CH-112",
        "name" : "WC-112 (Delete) CH-112",
        "interaction" : "Delete",
        "SUID" : 3579,
        "Ingredient_Affected" : "Baking_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3576",
        "source" : "680",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-112 (Insert) CH-112",
        "name" : "WC-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3576,
        "Ingredient_Affected" : "Milk",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3573",
        "source" : "680",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-112 (Insert) CH-112",
        "name" : "WC-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3573,
        "Ingredient_Affected" : "Instant_Yeast",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3570",
        "source" : "680",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-112 (Insert) CH-112",
        "name" : "WC-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3570,
        "Ingredient_Affected" : "Wheat_Starch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3566",
        "source" : "674",
        "target" : "662",
        "Description" : "Substituted lard for butter",
        "shared_interaction" : "Update",
        "shared_name" : "OC-112 (Update) CH-112",
        "name" : "OC-112 (Update) CH-112",
        "interaction" : "Update",
        "SUID" : 3566,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3563",
        "source" : "674",
        "target" : "662",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-112 (Delete) CH-112",
        "name" : "OC-112 (Delete) CH-112",
        "interaction" : "Delete",
        "SUID" : 3563,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3560",
        "source" : "674",
        "target" : "662",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-112 (Delete) CH-112",
        "name" : "OC-112 (Delete) CH-112",
        "interaction" : "Delete",
        "SUID" : 3560,
        "Ingredient_Affected" : "Baking_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3557",
        "source" : "674",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-112 (Insert) CH-112",
        "name" : "OC-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3557,
        "Ingredient_Affected" : "Heavy_Cream",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3554",
        "source" : "674",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-112 (Insert) CH-112",
        "name" : "OC-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3554,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3551",
        "source" : "674",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-112 (Insert) CH-112",
        "name" : "OC-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3551,
        "Ingredient_Affected" : "Sweentened_Condensed_Milk",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3548",
        "source" : "674",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-112 (Insert) CH-112",
        "name" : "OC-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3548,
        "Ingredient_Affected" : "Active_Dry_Yeast",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3545",
        "source" : "674",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-112 (Insert) CH-112",
        "name" : "OC-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3545,
        "Ingredient_Affected" : "Whole_Milk",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3541",
        "source" : "668",
        "target" : "662",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-112 (Delete) CH-112",
        "name" : "WL-112 (Delete) CH-112",
        "interaction" : "Delete",
        "SUID" : 3541,
        "Ingredient_Affected" : "Baking_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3538",
        "source" : "668",
        "target" : "662",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-112 (Delete) CH-112",
        "name" : "WL-112 (Delete) CH-112",
        "interaction" : "Delete",
        "SUID" : 3538,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3535",
        "source" : "668",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-112 (Insert) CH-112",
        "name" : "WL-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3535,
        "Ingredient_Affected" : "Milk",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3532",
        "source" : "668",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-112 (Insert) CH-112",
        "name" : "WL-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3532,
        "Ingredient_Affected" : "Powdered_Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3529",
        "source" : "668",
        "target" : "662",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-112 (Insert) CH-112",
        "name" : "WL-112 (Insert) CH-112",
        "interaction" : "Insert",
        "SUID" : 3529,
        "Ingredient_Affected" : "Active_Dry_Yeast",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3525",
        "source" : "656",
        "target" : "638",
        "Description" : "Substituted pike for pork",
        "shared_interaction" : "Update",
        "shared_name" : "OC-110 (Update) CH-110",
        "name" : "OC-110 (Update) CH-110",
        "interaction" : "Update",
        "SUID" : 3525,
        "Ingredient_Affected" : "Pike",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3522",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-110 (Delete) CH-110",
        "name" : "OC-110 (Delete) CH-110",
        "interaction" : "Delete",
        "SUID" : 3522,
        "Ingredient_Affected" : "Salted_Almond",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3519",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-110 (Delete) CH-110",
        "name" : "OC-110 (Delete) CH-110",
        "interaction" : "Delete",
        "SUID" : 3519,
        "Ingredient_Affected" : "Chinese_Ham",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3516",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3516,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3513",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3513,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3510",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3510,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3507",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3507,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3504",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3504,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3501",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3501,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3498",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3498,
        "Ingredient_Affected" : "Chicken_Stock",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3495",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3495,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3492",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3492,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3489",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3489,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3486",
        "source" : "656",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-110 (Insert) CH-110",
        "name" : "OC-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3486,
        "Ingredient_Affected" : "Dried_Shiitake_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3482",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-110 (Delete) CH-110",
        "name" : "ML-110 (Delete) CH-110",
        "interaction" : "Delete",
        "SUID" : 3482,
        "Ingredient_Affected" : "Salted_Almond",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3479",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-110 (Delete) CH-110",
        "name" : "ML-110 (Delete) CH-110",
        "interaction" : "Delete",
        "SUID" : 3479,
        "Ingredient_Affected" : "Chinese_Ham",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3476",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-110 (Insert) CH-110",
        "name" : "ML-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3476,
        "Ingredient_Affected" : "Rice_Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3473",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-110 (Insert) CH-110",
        "name" : "ML-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3473,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3470",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-110 (Insert) CH-110",
        "name" : "ML-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3470,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3467",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-110 (Insert) CH-110",
        "name" : "ML-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3467,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3464",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-110 (Insert) CH-110",
        "name" : "ML-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3464,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3461",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-110 (Insert) CH-110",
        "name" : "ML-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3461,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3458",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-110 (Insert) CH-110",
        "name" : "ML-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3458,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3455",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-110 (Insert) CH-110",
        "name" : "ML-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3455,
        "Ingredient_Affected" : "Shrimp",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3452",
        "source" : "650",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-110 (Insert) CH-110",
        "name" : "ML-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3452,
        "Ingredient_Affected" : "Cilantro",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3448",
        "source" : "644",
        "target" : "638",
        "Description" : "Substituted pike for shrimp",
        "shared_interaction" : "Update",
        "shared_name" : "WL-110 (Update) CH-110",
        "name" : "WL-110 (Update) CH-110",
        "interaction" : "Update",
        "SUID" : 3448,
        "Ingredient_Affected" : "Pike",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3445",
        "source" : "644",
        "target" : "638",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-110 (Delete) CH-110",
        "name" : "WL-110 (Delete) CH-110",
        "interaction" : "Delete",
        "SUID" : 3445,
        "Ingredient_Affected" : "Salted_Almond",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3442",
        "source" : "644",
        "target" : "638",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-110 (Delete) CH-110",
        "name" : "WL-110 (Delete) CH-110",
        "interaction" : "Delete",
        "SUID" : 3442,
        "Ingredient_Affected" : "Chinese_Ham",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3439",
        "source" : "644",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-110 (Insert) CH-110",
        "name" : "WL-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3439,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3436",
        "source" : "644",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-110 (Insert) CH-110",
        "name" : "WL-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3436,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3433",
        "source" : "644",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-110 (Insert) CH-110",
        "name" : "WL-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3433,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3430",
        "source" : "644",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-110 (Insert) CH-110",
        "name" : "WL-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3430,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3427",
        "source" : "644",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-110 (Insert) CH-110",
        "name" : "WL-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3427,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3424",
        "source" : "644",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-110 (Insert) CH-110",
        "name" : "WL-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3424,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3421",
        "source" : "644",
        "target" : "638",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-110 (Insert) CH-110",
        "name" : "WL-110 (Insert) CH-110",
        "interaction" : "Insert",
        "SUID" : 3421,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3417",
        "source" : "632",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-092 (Delete) CH-092",
        "name" : "RM-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3417,
        "Ingredient_Affected" : "Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3414",
        "source" : "632",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-092 (Delete) CH-092",
        "name" : "RM-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3414,
        "Ingredient_Affected" : "Water_Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3411",
        "source" : "632",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-092 (Delete) CH-092",
        "name" : "RM-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3411,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3408",
        "source" : "632",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-092 (Insert) CH-092",
        "name" : "RM-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3408,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3405",
        "source" : "632",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-092 (Insert) CH-092",
        "name" : "RM-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3405,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3402",
        "source" : "632",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-092 (Insert) CH-092",
        "name" : "RM-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3402,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3399",
        "source" : "632",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-092 (Insert) CH-092",
        "name" : "RM-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3399,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3396",
        "source" : "632",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-092 (Insert) CH-092",
        "name" : "RM-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3396,
        "Ingredient_Affected" : "Fish_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3393",
        "source" : "632",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-092 (Insert) CH-092",
        "name" : "RM-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3393,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3389",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-092 (Delete) CH-092",
        "name" : "OC-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3389,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3386",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-092 (Delete) CH-092",
        "name" : "OC-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3386,
        "Ingredient_Affected" : "Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3383",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-092 (Delete) CH-092",
        "name" : "OC-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3383,
        "Ingredient_Affected" : "Water_Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3380",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-092 (Delete) CH-092",
        "name" : "OC-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3380,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3377",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-092 (Delete) CH-092",
        "name" : "OC-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3377,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3374",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-092 (Insert) CH-092",
        "name" : "OC-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3374,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3371",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-092 (Insert) CH-092",
        "name" : "OC-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3371,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3368",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-092 (Insert) CH-092",
        "name" : "OC-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3368,
        "Ingredient_Affected" : "Jalapeño_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3365",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-092 (Insert) CH-092",
        "name" : "OC-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3365,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3362",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-092 (Insert) CH-092",
        "name" : "OC-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3362,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3359",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-092 (Insert) CH-092",
        "name" : "OC-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3359,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3356",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-092 (Insert) CH-092",
        "name" : "OC-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3356,
        "Ingredient_Affected" : "Rice_Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3353",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-092 (Insert) CH-092",
        "name" : "OC-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3353,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3350",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-092 (Insert) CH-092",
        "name" : "OC-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3350,
        "Ingredient_Affected" : "Ketchup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3347",
        "source" : "626",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-092 (Insert) CH-092",
        "name" : "OC-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3347,
        "Ingredient_Affected" : "Chicken_Stock",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3343",
        "source" : "620",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-092 (Delete) CH-092",
        "name" : "ML-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3343,
        "Ingredient_Affected" : "Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3340",
        "source" : "620",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-092 (Delete) CH-092",
        "name" : "ML-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3340,
        "Ingredient_Affected" : "Water_Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3337",
        "source" : "620",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-092 (Delete) CH-092",
        "name" : "ML-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3337,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3334",
        "source" : "620",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-092 (Delete) CH-092",
        "name" : "ML-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3334,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3331",
        "source" : "620",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-092 (Insert) CH-092",
        "name" : "ML-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3331,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3328",
        "source" : "620",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-092 (Insert) CH-092",
        "name" : "ML-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3328,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3325",
        "source" : "620",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-092 (Insert) CH-092",
        "name" : "ML-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3325,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3322",
        "source" : "620",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-092 (Insert) CH-092",
        "name" : "ML-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3322,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3318",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-092 (Delete) CH-092",
        "name" : "WL-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3318,
        "Ingredient_Affected" : "Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3315",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-092 (Delete) CH-092",
        "name" : "WL-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3315,
        "Ingredient_Affected" : "Water_Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3312",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-092 (Delete) CH-092",
        "name" : "WL-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3312,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3309",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-092 (Delete) CH-092",
        "name" : "WL-092 (Delete) CH-092",
        "interaction" : "Delete",
        "SUID" : 3309,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3306",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3306,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3303",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3303,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3300",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3300,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3297",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3297,
        "Ingredient_Affected" : "Chicken_Stock",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3294",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3294,
        "Ingredient_Affected" : "Shallot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3291",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3291,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3288",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3288,
        "Ingredient_Affected" : "Paprika",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3285",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3285,
        "Ingredient_Affected" : "Turmeric",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3282",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3282,
        "Ingredient_Affected" : "All_Purpose_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3279",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3279,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3276",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3276,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3273",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3273,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3270",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3270,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3267",
        "source" : "614",
        "target" : "608",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-092 (Insert) CH-092",
        "name" : "WL-092 (Insert) CH-092",
        "interaction" : "Insert",
        "SUID" : 3267,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3263",
        "source" : "602",
        "target" : "578",
        "Description" : "Substituted Chinese ham for pork and shrimp",
        "shared_interaction" : "Update",
        "shared_name" : "RM-089 (Update) CH-089",
        "name" : "RM-089 (Update) CH-089",
        "interaction" : "Update",
        "SUID" : 3263,
        "Ingredient_Affected" : "Chinese_Ham",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3260",
        "source" : "602",
        "target" : "578",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-089 (Delete) CH-089",
        "name" : "RM-089 (Delete) CH-089",
        "interaction" : "Delete",
        "SUID" : 3260,
        "Ingredient_Affected" : "Parsley",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3257",
        "source" : "602",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-089 (Insert) CH-089",
        "name" : "RM-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3257,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3254",
        "source" : "602",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-089 (Insert) CH-089",
        "name" : "RM-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3254,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3251",
        "source" : "602",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-089 (Insert) CH-089",
        "name" : "RM-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3251,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3248",
        "source" : "602",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-089 (Insert) CH-089",
        "name" : "RM-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3248,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3245",
        "source" : "602",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-089 (Insert) CH-089",
        "name" : "RM-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3245,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3242",
        "source" : "602",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-089 (Insert) CH-089",
        "name" : "RM-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3242,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3239",
        "source" : "602",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-089 (Insert) CH-089",
        "name" : "RM-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3239,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3236",
        "source" : "602",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-089 (Insert) CH-089",
        "name" : "RM-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3236,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3232",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-089 (Delete) CH-089",
        "name" : "OC-089 (Delete) CH-089",
        "interaction" : "Delete",
        "SUID" : 3232,
        "Ingredient_Affected" : "Chinese_Ham",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3229",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-089 (Delete) CH-089",
        "name" : "OC-089 (Delete) CH-089",
        "interaction" : "Delete",
        "SUID" : 3229,
        "Ingredient_Affected" : "Parsley",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3226",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-089 (Insert) CH-089",
        "name" : "OC-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3226,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3223",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-089 (Insert) CH-089",
        "name" : "OC-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3223,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3220",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-089 (Insert) CH-089",
        "name" : "OC-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3220,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3217",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-089 (Insert) CH-089",
        "name" : "OC-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3217,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3214",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-089 (Insert) CH-089",
        "name" : "OC-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3214,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3211",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-089 (Insert) CH-089",
        "name" : "OC-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3211,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3208",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-089 (Insert) CH-089",
        "name" : "OC-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3208,
        "Ingredient_Affected" : "Chicken_Stock",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3205",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-089 (Insert) CH-089",
        "name" : "OC-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3205,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3202",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-089 (Insert) CH-089",
        "name" : "OC-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3202,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3199",
        "source" : "596",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-089 (Insert) CH-089",
        "name" : "OC-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3199,
        "Ingredient_Affected" : "Bell_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3195",
        "source" : "590",
        "target" : "578",
        "Description" : "Substituted Chinese ham for shrimp",
        "shared_interaction" : "Update",
        "shared_name" : "ML-089 (Update) CH-089",
        "name" : "ML-089 (Update) CH-089",
        "interaction" : "Update",
        "SUID" : 3195,
        "Ingredient_Affected" : "Chinese_Ham",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3192",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-089 (Delete) CH-089",
        "name" : "ML-089 (Delete) CH-089",
        "interaction" : "Delete",
        "SUID" : 3192,
        "Ingredient_Affected" : "Parsley",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3189",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3189,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3186",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3186,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3183",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3183,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3180",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3180,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3177",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3177,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3174",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3174,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3171",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3171,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3168",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3168,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3165",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3165,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3162",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3162,
        "Ingredient_Affected" : "Red_Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3159",
        "source" : "590",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-089 (Insert) CH-089",
        "name" : "ML-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3159,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3155",
        "source" : "584",
        "target" : "578",
        "Description" : "Substituted Chinese ham for any protein",
        "shared_interaction" : "Update",
        "shared_name" : "WL-089 (Update) CH-089",
        "name" : "WL-089 (Update) CH-089",
        "interaction" : "Update",
        "SUID" : 3155,
        "Ingredient_Affected" : "Chinese_Ham",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3152",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-089 (Delete) CH-089",
        "name" : "WL-089 (Delete) CH-089",
        "interaction" : "Delete",
        "SUID" : 3152,
        "Ingredient_Affected" : "Parsley",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3149",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-089 (Delete) CH-089",
        "name" : "WL-089 (Delete) CH-089",
        "interaction" : "Delete",
        "SUID" : 3149,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3146",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3146,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3143",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3143,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3140",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3140,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3137",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3137,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3134",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3134,
        "Ingredient_Affected" : "Chicken_Stock",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3131",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3131,
        "Ingredient_Affected" : "Shallot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3128",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3128,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3125",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3125,
        "Ingredient_Affected" : "Paprika",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3122",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3122,
        "Ingredient_Affected" : "Turmeric",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3119",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3119,
        "Ingredient_Affected" : "All_Purpose_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3116",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3116,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3113",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3113,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3110",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3110,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3107",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3107,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3104",
        "source" : "584",
        "target" : "578",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-089 (Insert) CH-089",
        "name" : "WL-089 (Insert) CH-089",
        "interaction" : "Insert",
        "SUID" : 3104,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3100",
        "source" : "572",
        "target" : "548",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-067 (Delete) CH-067",
        "name" : "RM-067 (Delete) CH-067",
        "interaction" : "Delete",
        "SUID" : 3100,
        "Ingredient_Affected" : "Green_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3097",
        "source" : "572",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-067 (Insert) CH-067",
        "name" : "RM-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3097,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3094",
        "source" : "572",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-067 (Insert) CH-067",
        "name" : "RM-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3094,
        "Ingredient_Affected" : "Baking_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3091",
        "source" : "572",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-067 (Insert) CH-067",
        "name" : "RM-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3091,
        "Ingredient_Affected" : "All_Purpose_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3088",
        "source" : "572",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-067 (Insert) CH-067",
        "name" : "RM-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3088,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3085",
        "source" : "572",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-067 (Insert) CH-067",
        "name" : "RM-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3085,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3082",
        "source" : "572",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-067 (Insert) CH-067",
        "name" : "RM-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3082,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3078",
        "source" : "566",
        "target" : "548",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-067 (Delete) CH-067",
        "name" : "OC-067 (Delete) CH-067",
        "interaction" : "Delete",
        "SUID" : 3078,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3075",
        "source" : "566",
        "target" : "548",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-067 (Delete) CH-067",
        "name" : "OC-067 (Delete) CH-067",
        "interaction" : "Delete",
        "SUID" : 3075,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3072",
        "source" : "566",
        "target" : "548",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-067 (Delete) CH-067",
        "name" : "OC-067 (Delete) CH-067",
        "interaction" : "Delete",
        "SUID" : 3072,
        "Ingredient_Affected" : "Green_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3069",
        "source" : "566",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-067 (Insert) CH-067",
        "name" : "OC-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3069,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3066",
        "source" : "566",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-067 (Insert) CH-067",
        "name" : "OC-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3066,
        "Ingredient_Affected" : "All_Purpose_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3063",
        "source" : "566",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-067 (Insert) CH-067",
        "name" : "OC-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3063,
        "Ingredient_Affected" : "Black_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3060",
        "source" : "566",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-067 (Insert) CH-067",
        "name" : "OC-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3060,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3057",
        "source" : "566",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-067 (Insert) CH-067",
        "name" : "OC-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3057,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3053",
        "source" : "560",
        "target" : "548",
        "Description" : "Substituted green pepper for red bell pepper",
        "shared_interaction" : "Update",
        "shared_name" : "ML-067 (Update) CH-067",
        "name" : "ML-067 (Update) CH-067",
        "interaction" : "Update",
        "SUID" : 3053,
        "Ingredient_Affected" : "Green_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3050",
        "source" : "560",
        "target" : "548",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-067 (Delete) CH-067",
        "name" : "ML-067 (Delete) CH-067",
        "interaction" : "Delete",
        "SUID" : 3050,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3047",
        "source" : "560",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-067 (Insert) CH-067",
        "name" : "ML-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3047,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3044",
        "source" : "560",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-067 (Insert) CH-067",
        "name" : "ML-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3044,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3041",
        "source" : "560",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-067 (Insert) CH-067",
        "name" : "ML-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3041,
        "Ingredient_Affected" : "Garlic_Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3038",
        "source" : "560",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-067 (Insert) CH-067",
        "name" : "ML-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3038,
        "Ingredient_Affected" : "Thai_Chili_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3035",
        "source" : "560",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-067 (Insert) CH-067",
        "name" : "ML-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3035,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3032",
        "source" : "560",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-067 (Insert) CH-067",
        "name" : "ML-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3032,
        "Ingredient_Affected" : "Red_Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3029",
        "source" : "560",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-067 (Insert) CH-067",
        "name" : "ML-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3029,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3025",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-067 (Delete) CH-067",
        "name" : "WL-067 (Delete) CH-067",
        "interaction" : "Delete",
        "SUID" : 3025,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3022",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-067 (Delete) CH-067",
        "name" : "WL-067 (Delete) CH-067",
        "interaction" : "Delete",
        "SUID" : 3022,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3019",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-067 (Delete) CH-067",
        "name" : "WL-067 (Delete) CH-067",
        "interaction" : "Delete",
        "SUID" : 3019,
        "Ingredient_Affected" : "Green_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3016",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-067 (Insert) CH-067",
        "name" : "WL-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3016,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3013",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-067 (Insert) CH-067",
        "name" : "WL-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3013,
        "Ingredient_Affected" : "Garlic_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3010",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-067 (Insert) CH-067",
        "name" : "WL-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3010,
        "Ingredient_Affected" : "Onion_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3007",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-067 (Insert) CH-067",
        "name" : "WL-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3007,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3004",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-067 (Insert) CH-067",
        "name" : "WL-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3004,
        "Ingredient_Affected" : "Baking_Soda",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3001",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-067 (Insert) CH-067",
        "name" : "WL-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 3001,
        "Ingredient_Affected" : "Baking_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2998",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-067 (Insert) CH-067",
        "name" : "WL-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 2998,
        "Ingredient_Affected" : "All_Purpose_Flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2995",
        "source" : "554",
        "target" : "548",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-067 (Insert) CH-067",
        "name" : "WL-067 (Insert) CH-067",
        "interaction" : "Insert",
        "SUID" : 2995,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2991",
        "source" : "542",
        "target" : "524",
        "Description" : "Substituted primary soup for water",
        "shared_interaction" : "Update",
        "shared_name" : "WC-066 (Update) CH-066",
        "name" : "WC-066 (Update) CH-066",
        "interaction" : "Update",
        "SUID" : 2991,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2988",
        "source" : "542",
        "target" : "524",
        "Description" : "Substituted ginger root juice for ginger",
        "shared_interaction" : "Update",
        "shared_name" : "WC-066 (Update) CH-066",
        "name" : "WC-066 (Update) CH-066",
        "interaction" : "Update",
        "SUID" : 2988,
        "Ingredient_Affected" : "Ginger_Root_Juice",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2985",
        "source" : "542",
        "target" : "524",
        "Description" : "Substituted prawn for shrimp",
        "shared_interaction" : "Update",
        "shared_name" : "WC-066 (Update) CH-066",
        "name" : "WC-066 (Update) CH-066",
        "interaction" : "Update",
        "SUID" : 2985,
        "Ingredient_Affected" : "Prawn",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2982",
        "source" : "542",
        "target" : "524",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-066 (Delete) CH-066",
        "name" : "WC-066 (Delete) CH-066",
        "interaction" : "Delete",
        "SUID" : 2982,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2979",
        "source" : "542",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-066 (Insert) CH-066",
        "name" : "WC-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2979,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2976",
        "source" : "542",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-066 (Insert) CH-066",
        "name" : "WC-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2976,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2973",
        "source" : "542",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-066 (Insert) CH-066",
        "name" : "WC-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2973,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2970",
        "source" : "542",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-066 (Insert) CH-066",
        "name" : "WC-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2970,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2967",
        "source" : "542",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-066 (Insert) CH-066",
        "name" : "WC-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2967,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2964",
        "source" : "542",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-066 (Insert) CH-066",
        "name" : "WC-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2964,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2961",
        "source" : "542",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-066 (Insert) CH-066",
        "name" : "WC-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2961,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2957",
        "source" : "536",
        "target" : "524",
        "Description" : "Substituted primary soup for water",
        "shared_interaction" : "Update",
        "shared_name" : "ML-066 (Update) CH-066",
        "name" : "ML-066 (Update) CH-066",
        "interaction" : "Update",
        "SUID" : 2957,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2954",
        "source" : "536",
        "target" : "524",
        "Description" : "Substituted ginger root juice for ginger",
        "shared_interaction" : "Update",
        "shared_name" : "ML-066 (Update) CH-066",
        "name" : "ML-066 (Update) CH-066",
        "interaction" : "Update",
        "SUID" : 2954,
        "Ingredient_Affected" : "Ginger_Root_Juice",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2951",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-066 (Delete) CH-066",
        "name" : "ML-066 (Delete) CH-066",
        "interaction" : "Delete",
        "SUID" : 2951,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2948",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-066 (Delete) CH-066",
        "name" : "ML-066 (Delete) CH-066",
        "interaction" : "Delete",
        "SUID" : 2948,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2945",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-066 (Insert) CH-066",
        "name" : "ML-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2945,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2942",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-066 (Insert) CH-066",
        "name" : "ML-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2942,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2939",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-066 (Insert) CH-066",
        "name" : "ML-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2939,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2936",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-066 (Insert) CH-066",
        "name" : "ML-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2936,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2933",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-066 (Insert) CH-066",
        "name" : "ML-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2933,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2930",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-066 (Insert) CH-066",
        "name" : "ML-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2930,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2927",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-066 (Insert) CH-066",
        "name" : "ML-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2927,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2924",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-066 (Insert) CH-066",
        "name" : "ML-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2924,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2921",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-066 (Insert) CH-066",
        "name" : "ML-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2921,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2918",
        "source" : "536",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-066 (Insert) CH-066",
        "name" : "ML-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2918,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2914",
        "source" : "530",
        "target" : "524",
        "Description" : "Substituted primary soup for water",
        "shared_interaction" : "Update",
        "shared_name" : "WL-066 (Update) CH-066",
        "name" : "WL-066 (Update) CH-066",
        "interaction" : "Update",
        "SUID" : 2914,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2911",
        "source" : "530",
        "target" : "524",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-066 (Delete) CH-066",
        "name" : "WL-066 (Delete) CH-066",
        "interaction" : "Delete",
        "SUID" : 2911,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2908",
        "source" : "530",
        "target" : "524",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-066 (Delete) CH-066",
        "name" : "WL-066 (Delete) CH-066",
        "interaction" : "Delete",
        "SUID" : 2908,
        "Ingredient_Affected" : "Ginger_Root_Juice",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2905",
        "source" : "530",
        "target" : "524",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-066 (Delete) CH-066",
        "name" : "WL-066 (Delete) CH-066",
        "interaction" : "Delete",
        "SUID" : 2905,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2902",
        "source" : "530",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-066 (Insert) CH-066",
        "name" : "WL-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2902,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2899",
        "source" : "530",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-066 (Insert) CH-066",
        "name" : "WL-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2899,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2896",
        "source" : "530",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-066 (Insert) CH-066",
        "name" : "WL-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2896,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2893",
        "source" : "530",
        "target" : "524",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-066 (Insert) CH-066",
        "name" : "WL-066 (Insert) CH-066",
        "interaction" : "Insert",
        "SUID" : 2893,
        "Ingredient_Affected" : "Vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2889",
        "source" : "518",
        "target" : "488",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-060 (Delete) CH-060",
        "name" : "RM-060 (Delete) CH-060",
        "interaction" : "Delete",
        "SUID" : 2889,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2886",
        "source" : "518",
        "target" : "488",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-060 (Delete) CH-060",
        "name" : "RM-060 (Delete) CH-060",
        "interaction" : "Delete",
        "SUID" : 2886,
        "Ingredient_Affected" : "Chinese_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2883",
        "source" : "518",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-060 (Insert) CH-060",
        "name" : "RM-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2883,
        "Ingredient_Affected" : "Rock_Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2880",
        "source" : "518",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-060 (Insert) CH-060",
        "name" : "RM-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2880,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2877",
        "source" : "518",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-060 (Insert) CH-060",
        "name" : "RM-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2877,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2874",
        "source" : "518",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-060 (Insert) CH-060",
        "name" : "RM-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2874,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2871",
        "source" : "518",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-060 (Insert) CH-060",
        "name" : "RM-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2871,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2867",
        "source" : "512",
        "target" : "488",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-060 (Delete) CH-060",
        "name" : "WC-060 (Delete) CH-060",
        "interaction" : "Delete",
        "SUID" : 2867,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2864",
        "source" : "512",
        "target" : "488",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-060 (Delete) CH-060",
        "name" : "WC-060 (Delete) CH-060",
        "interaction" : "Delete",
        "SUID" : 2864,
        "Ingredient_Affected" : "Chinese_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2861",
        "source" : "512",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-060 (Insert) CH-060",
        "name" : "WC-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2861,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2858",
        "source" : "512",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-060 (Insert) CH-060",
        "name" : "WC-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2858,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2855",
        "source" : "512",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-060 (Insert) CH-060",
        "name" : "WC-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2855,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2851",
        "source" : "506",
        "target" : "488",
        "Description" : "Substituted pike for any white fish",
        "shared_interaction" : "Update",
        "shared_name" : "OC-060 (Update) CH-060",
        "name" : "OC-060 (Update) CH-060",
        "interaction" : "Update",
        "SUID" : 2851,
        "Ingredient_Affected" : "Pike",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2848",
        "source" : "506",
        "target" : "488",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-060 (Delete) CH-060",
        "name" : "OC-060 (Delete) CH-060",
        "interaction" : "Delete",
        "SUID" : 2848,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2845",
        "source" : "506",
        "target" : "488",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-060 (Delete) CH-060",
        "name" : "OC-060 (Delete) CH-060",
        "interaction" : "Delete",
        "SUID" : 2845,
        "Ingredient_Affected" : "Chinese_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2842",
        "source" : "506",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-060 (Insert) CH-060",
        "name" : "OC-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2842,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2839",
        "source" : "506",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-060 (Insert) CH-060",
        "name" : "OC-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2839,
        "Ingredient_Affected" : "Dried_Chili_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2836",
        "source" : "506",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-060 (Insert) CH-060",
        "name" : "OC-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2836,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2832",
        "source" : "500",
        "target" : "488",
        "Description" : "Substituted pike for tilapia",
        "shared_interaction" : "Update",
        "shared_name" : "ML-060 (Update) CH-060",
        "name" : "ML-060 (Update) CH-060",
        "interaction" : "Update",
        "SUID" : 2832,
        "Ingredient_Affected" : "Pike",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2829",
        "source" : "500",
        "target" : "488",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-060 (Delete) CH-060",
        "name" : "ML-060 (Delete) CH-060",
        "interaction" : "Delete",
        "SUID" : 2829,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2826",
        "source" : "500",
        "target" : "488",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-060 (Delete) CH-060",
        "name" : "ML-060 (Delete) CH-060",
        "interaction" : "Delete",
        "SUID" : 2826,
        "Ingredient_Affected" : "Chinese_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2823",
        "source" : "500",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-060 (Insert) CH-060",
        "name" : "ML-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2823,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2820",
        "source" : "500",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-060 (Insert) CH-060",
        "name" : "ML-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2820,
        "Ingredient_Affected" : "Olive_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2817",
        "source" : "500",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-060 (Insert) CH-060",
        "name" : "ML-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2817,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2814",
        "source" : "500",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-060 (Insert) CH-060",
        "name" : "ML-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2814,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2811",
        "source" : "500",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-060 (Insert) CH-060",
        "name" : "ML-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2811,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2808",
        "source" : "500",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-060 (Insert) CH-060",
        "name" : "ML-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2808,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2805",
        "source" : "500",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-060 (Insert) CH-060",
        "name" : "ML-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2805,
        "Ingredient_Affected" : "Ground_Bean_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2802",
        "source" : "500",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-060 (Insert) CH-060",
        "name" : "ML-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2802,
        "Ingredient_Affected" : "Cilantro",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2798",
        "source" : "494",
        "target" : "488",
        "Description" : "Substituted pike for any white fish",
        "shared_interaction" : "Update",
        "shared_name" : "WL-060 (Update) CH-060",
        "name" : "WL-060 (Update) CH-060",
        "interaction" : "Update",
        "SUID" : 2798,
        "Ingredient_Affected" : "Pike",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2795",
        "source" : "494",
        "target" : "488",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-060 (Delete) CH-060",
        "name" : "WL-060 (Delete) CH-060",
        "interaction" : "Delete",
        "SUID" : 2795,
        "Ingredient_Affected" : "Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2792",
        "source" : "494",
        "target" : "488",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-060 (Delete) CH-060",
        "name" : "WL-060 (Delete) CH-060",
        "interaction" : "Delete",
        "SUID" : 2792,
        "Ingredient_Affected" : "Chinese_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2789",
        "source" : "494",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-060 (Insert) CH-060",
        "name" : "WL-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2789,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2786",
        "source" : "494",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-060 (Insert) CH-060",
        "name" : "WL-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2786,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2783",
        "source" : "494",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-060 (Insert) CH-060",
        "name" : "WL-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2783,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2780",
        "source" : "494",
        "target" : "488",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-060 (Insert) CH-060",
        "name" : "WL-060 (Insert) CH-060",
        "interaction" : "Insert",
        "SUID" : 2780,
        "Ingredient_Affected" : "Cilantro",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2776",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-053 (Delete) CH-053",
        "name" : "RM-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2776,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2773",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-053 (Delete) CH-053",
        "name" : "RM-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2773,
        "Ingredient_Affected" : "Celery",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2770",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-053 (Insert) CH-053",
        "name" : "RM-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2770,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2767",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-053 (Insert) CH-053",
        "name" : "RM-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2767,
        "Ingredient_Affected" : "Worcestershire_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2764",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-053 (Insert) CH-053",
        "name" : "RM-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2764,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2761",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-053 (Insert) CH-053",
        "name" : "RM-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2761,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2758",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-053 (Insert) CH-053",
        "name" : "RM-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2758,
        "Ingredient_Affected" : "Maggi_Seasoning_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2755",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-053 (Insert) CH-053",
        "name" : "RM-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2755,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2752",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-053 (Insert) CH-053",
        "name" : "RM-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2752,
        "Ingredient_Affected" : "Black_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2749",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-053 (Insert) CH-053",
        "name" : "RM-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2749,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2746",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-053 (Insert) CH-053",
        "name" : "RM-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2746,
        "Ingredient_Affected" : "Red_Bell_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2743",
        "source" : "482",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-053 (Insert) CH-053",
        "name" : "RM-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2743,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2739",
        "source" : "476",
        "target" : "458",
        "Description" : "Substituted green pepper for cubanelle pepper",
        "shared_interaction" : "Update",
        "shared_name" : "OC-053 (Update) CH-053",
        "name" : "OC-053 (Update) CH-053",
        "interaction" : "Update",
        "SUID" : 2739,
        "Ingredient_Affected" : "Green_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2736",
        "source" : "476",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-053 (Delete) CH-053",
        "name" : "OC-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2736,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2733",
        "source" : "476",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-053 (Delete) CH-053",
        "name" : "OC-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2733,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2730",
        "source" : "476",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-053 (Delete) CH-053",
        "name" : "OC-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2730,
        "Ingredient_Affected" : "Celery",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2727",
        "source" : "476",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-053 (Insert) CH-053",
        "name" : "OC-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2727,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2724",
        "source" : "476",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-053 (Insert) CH-053",
        "name" : "OC-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2724,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2721",
        "source" : "476",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-053 (Insert) CH-053",
        "name" : "OC-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2721,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2718",
        "source" : "476",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-053 (Insert) CH-053",
        "name" : "OC-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2718,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2715",
        "source" : "476",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-053 (Insert) CH-053",
        "name" : "OC-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2715,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2712",
        "source" : "476",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-053 (Insert) CH-053",
        "name" : "OC-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2712,
        "Ingredient_Affected" : "Doubanjiang",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2708",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-053 (Delete) CH-053",
        "name" : "ML-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2708,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2705",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-053 (Delete) CH-053",
        "name" : "ML-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2705,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2702",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-053 (Delete) CH-053",
        "name" : "ML-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2702,
        "Ingredient_Affected" : "Celery",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2699",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-053 (Insert) CH-053",
        "name" : "ML-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2699,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2696",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-053 (Insert) CH-053",
        "name" : "ML-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2696,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2693",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-053 (Insert) CH-053",
        "name" : "ML-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2693,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2690",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-053 (Insert) CH-053",
        "name" : "ML-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2690,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2687",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-053 (Insert) CH-053",
        "name" : "ML-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2687,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2684",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-053 (Insert) CH-053",
        "name" : "ML-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2684,
        "Ingredient_Affected" : "Black_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2681",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-053 (Insert) CH-053",
        "name" : "ML-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2681,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2678",
        "source" : "470",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-053 (Insert) CH-053",
        "name" : "ML-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2678,
        "Ingredient_Affected" : "Red_Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2674",
        "source" : "464",
        "target" : "458",
        "Description" : "Substituted green pepper for hot green pepper and hot red pepper",
        "shared_interaction" : "Update",
        "shared_name" : "WL-053 (Update) CH-053",
        "name" : "WL-053 (Update) CH-053",
        "interaction" : "Update",
        "SUID" : 2674,
        "Ingredient_Affected" : "Green_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2671",
        "source" : "464",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-053 (Delete) CH-053",
        "name" : "WL-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2671,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2668",
        "source" : "464",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-053 (Delete) CH-053",
        "name" : "WL-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2668,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2665",
        "source" : "464",
        "target" : "458",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-053 (Delete) CH-053",
        "name" : "WL-053 (Delete) CH-053",
        "interaction" : "Delete",
        "SUID" : 2665,
        "Ingredient_Affected" : "Celery",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2662",
        "source" : "464",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-053 (Insert) CH-053",
        "name" : "WL-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2662,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2659",
        "source" : "464",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-053 (Insert) CH-053",
        "name" : "WL-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2659,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2656",
        "source" : "464",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-053 (Insert) CH-053",
        "name" : "WL-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2656,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2653",
        "source" : "464",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-053 (Insert) CH-053",
        "name" : "WL-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2653,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2650",
        "source" : "464",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-053 (Insert) CH-053",
        "name" : "WL-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2650,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2647",
        "source" : "464",
        "target" : "458",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-053 (Insert) CH-053",
        "name" : "WL-053 (Insert) CH-053",
        "interaction" : "Insert",
        "SUID" : 2647,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2643",
        "source" : "452",
        "target" : "434",
        "Description" : "Substituted vinegar for black rice vinegar",
        "shared_interaction" : "Update",
        "shared_name" : "WC-051 (Update) CH-051",
        "name" : "WC-051 (Update) CH-051",
        "interaction" : "Update",
        "SUID" : 2643,
        "Ingredient_Affected" : "Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2640",
        "source" : "452",
        "target" : "434",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-051 (Delete) CH-051",
        "name" : "WC-051 (Delete) CH-051",
        "interaction" : "Delete",
        "SUID" : 2640,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2637",
        "source" : "452",
        "target" : "434",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-051 (Delete) CH-051",
        "name" : "WC-051 (Delete) CH-051",
        "interaction" : "Delete",
        "SUID" : 2637,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2634",
        "source" : "452",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-051 (Insert) CH-051",
        "name" : "WC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2634,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2631",
        "source" : "452",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-051 (Insert) CH-051",
        "name" : "WC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2631,
        "Ingredient_Affected" : "Sichuan_Peppercorn",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2628",
        "source" : "452",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-051 (Insert) CH-051",
        "name" : "WC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2628,
        "Ingredient_Affected" : "Honey",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2625",
        "source" : "452",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-051 (Insert) CH-051",
        "name" : "WC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2625,
        "Ingredient_Affected" : "Birds_Eye_Chili",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2622",
        "source" : "452",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-051 (Insert) CH-051",
        "name" : "WC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2622,
        "Ingredient_Affected" : "Chicken_Stock",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2618",
        "source" : "446",
        "target" : "434",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-051 (Delete) CH-051",
        "name" : "OC-051 (Delete) CH-051",
        "interaction" : "Delete",
        "SUID" : 2618,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2615",
        "source" : "446",
        "target" : "434",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-051 (Delete) CH-051",
        "name" : "OC-051 (Delete) CH-051",
        "interaction" : "Delete",
        "SUID" : 2615,
        "Ingredient_Affected" : "Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2612",
        "source" : "446",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-051 (Insert) CH-051",
        "name" : "OC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2612,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2609",
        "source" : "446",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-051 (Insert) CH-051",
        "name" : "OC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2609,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2606",
        "source" : "446",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-051 (Insert) CH-051",
        "name" : "OC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2606,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2603",
        "source" : "446",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-051 (Insert) CH-051",
        "name" : "OC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2603,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2600",
        "source" : "446",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-051 (Insert) CH-051",
        "name" : "OC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2600,
        "Ingredient_Affected" : "Garlic_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2597",
        "source" : "446",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-051 (Insert) CH-051",
        "name" : "OC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2597,
        "Ingredient_Affected" : "Black_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2594",
        "source" : "446",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-051 (Insert) CH-051",
        "name" : "OC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2594,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2591",
        "source" : "446",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-051 (Insert) CH-051",
        "name" : "OC-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2591,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2587",
        "source" : "440",
        "target" : "434",
        "Description" : "Substituted sugar for maple syrup",
        "shared_interaction" : "Update",
        "shared_name" : "WL-051 (Update) CH-051",
        "name" : "WL-051 (Update) CH-051",
        "interaction" : "Update",
        "SUID" : 2587,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2584",
        "source" : "440",
        "target" : "434",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-051 (Delete) CH-051",
        "name" : "WL-051 (Delete) CH-051",
        "interaction" : "Delete",
        "SUID" : 2584,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2581",
        "source" : "440",
        "target" : "434",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-051 (Delete) CH-051",
        "name" : "WL-051 (Delete) CH-051",
        "interaction" : "Delete",
        "SUID" : 2581,
        "Ingredient_Affected" : "Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2578",
        "source" : "440",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-051 (Insert) CH-051",
        "name" : "WL-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2578,
        "Ingredient_Affected" : "Baking_Soda",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2575",
        "source" : "440",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-051 (Insert) CH-051",
        "name" : "WL-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2575,
        "Ingredient_Affected" : "Onion_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2572",
        "source" : "440",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-051 (Insert) CH-051",
        "name" : "WL-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2572,
        "Ingredient_Affected" : "Garlic_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2569",
        "source" : "440",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-051 (Insert) CH-051",
        "name" : "WL-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2569,
        "Ingredient_Affected" : "Five_Spice_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2566",
        "source" : "440",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-051 (Insert) CH-051",
        "name" : "WL-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2566,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2563",
        "source" : "440",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-051 (Insert) CH-051",
        "name" : "WL-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2563,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2560",
        "source" : "440",
        "target" : "434",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-051 (Insert) CH-051",
        "name" : "WL-051 (Insert) CH-051",
        "interaction" : "Insert",
        "SUID" : 2560,
        "Ingredient_Affected" : "Red_Fermented_Bean_Curd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2556",
        "source" : "428",
        "target" : "410",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-025 (Delete) CH-025",
        "name" : "WC-025 (Delete) CH-025",
        "interaction" : "Delete",
        "SUID" : 2556,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2553",
        "source" : "428",
        "target" : "410",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-025 (Delete) CH-025",
        "name" : "WC-025 (Delete) CH-025",
        "interaction" : "Delete",
        "SUID" : 2553,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2550",
        "source" : "428",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-025 (Insert) CH-025",
        "name" : "WC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2550,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2547",
        "source" : "428",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-025 (Insert) CH-025",
        "name" : "WC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2547,
        "Ingredient_Affected" : "Apple",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2544",
        "source" : "428",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-025 (Insert) CH-025",
        "name" : "WC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2544,
        "Ingredient_Affected" : "Honey",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2541",
        "source" : "428",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-025 (Insert) CH-025",
        "name" : "WC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2541,
        "Ingredient_Affected" : "Rice_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2538",
        "source" : "428",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-025 (Insert) CH-025",
        "name" : "WC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2538,
        "Ingredient_Affected" : "Apple_Cider_Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2535",
        "source" : "428",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-025 (Insert) CH-025",
        "name" : "WC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2535,
        "Ingredient_Affected" : "Maltose",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2531",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-025 (Delete) CH-025",
        "name" : "OC-025 (Delete) CH-025",
        "interaction" : "Delete",
        "SUID" : 2531,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2528",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-025 (Delete) CH-025",
        "name" : "OC-025 (Delete) CH-025",
        "interaction" : "Delete",
        "SUID" : 2528,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2525",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2525,
        "Ingredient_Affected" : "Red_Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2522",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2522,
        "Ingredient_Affected" : "Honey",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2519",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2519,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2516",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2516,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2513",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2513,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2510",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2510,
        "Ingredient_Affected" : "Star_Anise",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2507",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2507,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2504",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2504,
        "Ingredient_Affected" : "Hoisin_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2501",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2501,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2498",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2498,
        "Ingredient_Affected" : "Red_Fermented_Bean_Curd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2495",
        "source" : "422",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-025 (Insert) CH-025",
        "name" : "OC-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2495,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2491",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-025 (Delete) CH-025",
        "name" : "WL-025 (Delete) CH-025",
        "interaction" : "Delete",
        "SUID" : 2491,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2488",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-025 (Delete) CH-025",
        "name" : "WL-025 (Delete) CH-025",
        "interaction" : "Delete",
        "SUID" : 2488,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2485",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2485,
        "Ingredient_Affected" : "Maltose",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2482",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2482,
        "Ingredient_Affected" : "Red_Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2479",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2479,
        "Ingredient_Affected" : "Dried_Mandarin_Peel",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2476",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2476,
        "Ingredient_Affected" : "Cinammon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2473",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2473,
        "Ingredient_Affected" : "Star_Anise",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2470",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2470,
        "Ingredient_Affected" : "Bay_Leaf",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2467",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2467,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2464",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2464,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2461",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2461,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2458",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2458,
        "Ingredient_Affected" : "Neutral_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2455",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2455,
        "Ingredient_Affected" : "Red_Fermented_Bean_Curd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2452",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2452,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2449",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2449,
        "Ingredient_Affected" : "Hoisin_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2446",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2446,
        "Ingredient_Affected" : "Ground_Bean_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2443",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2443,
        "Ingredient_Affected" : "Chee_Hou_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2440",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2440,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2437",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2437,
        "Ingredient_Affected" : "Sand_Ginger_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2434",
        "source" : "416",
        "target" : "410",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-025 (Insert) CH-025",
        "name" : "WL-025 (Insert) CH-025",
        "interaction" : "Insert",
        "SUID" : 2434,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2430",
        "source" : "404",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-024 (Insert) CH-024",
        "name" : "RM-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2430,
        "Ingredient_Affected" : "Honey",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2427",
        "source" : "404",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-024 (Insert) CH-024",
        "name" : "RM-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2427,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2424",
        "source" : "404",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-024 (Insert) CH-024",
        "name" : "RM-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2424,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2421",
        "source" : "404",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-024 (Insert) CH-024",
        "name" : "RM-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2421,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2418",
        "source" : "404",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-024 (Insert) CH-024",
        "name" : "RM-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2418,
        "Ingredient_Affected" : "Honey",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2415",
        "source" : "404",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-024 (Insert) CH-024",
        "name" : "RM-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2415,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2412",
        "source" : "404",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-024 (Insert) CH-024",
        "name" : "RM-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2412,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2408",
        "source" : "398",
        "target" : "380",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-024 (Delete) CH-024",
        "name" : "WC-024 (Delete) CH-024",
        "interaction" : "Delete",
        "SUID" : 2408,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2405",
        "source" : "398",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-024 (Insert) CH-024",
        "name" : "WC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2405,
        "Ingredient_Affected" : "Cooking_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2402",
        "source" : "398",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-024 (Insert) CH-024",
        "name" : "WC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2402,
        "Ingredient_Affected" : "Star_Anise",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2399",
        "source" : "398",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-024 (Insert) CH-024",
        "name" : "WC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2399,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2396",
        "source" : "398",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-024 (Insert) CH-024",
        "name" : "WC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2396,
        "Ingredient_Affected" : "Brown_Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2393",
        "source" : "398",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-024 (Insert) CH-024",
        "name" : "WC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2393,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2389",
        "source" : "392",
        "target" : "380",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-024 (Delete) CH-024",
        "name" : "OC-024 (Delete) CH-024",
        "interaction" : "Delete",
        "SUID" : 2389,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2386",
        "source" : "392",
        "target" : "380",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-024 (Delete) CH-024",
        "name" : "OC-024 (Delete) CH-024",
        "interaction" : "Delete",
        "SUID" : 2386,
        "Ingredient_Affected" : "Spicery_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2383",
        "source" : "392",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-024 (Insert) CH-024",
        "name" : "OC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2383,
        "Ingredient_Affected" : "Black_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2380",
        "source" : "392",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-024 (Insert) CH-024",
        "name" : "OC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2380,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2377",
        "source" : "392",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-024 (Insert) CH-024",
        "name" : "OC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2377,
        "Ingredient_Affected" : "Japanese_Sake",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2374",
        "source" : "392",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-024 (Insert) CH-024",
        "name" : "OC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2374,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2371",
        "source" : "392",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-024 (Insert) CH-024",
        "name" : "OC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2371,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2368",
        "source" : "392",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-024 (Insert) CH-024",
        "name" : "OC-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2368,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2364",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-024 (Delete) CH-024",
        "name" : "ML-024 (Delete) CH-024",
        "interaction" : "Delete",
        "SUID" : 2364,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2361",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-024 (Delete) CH-024",
        "name" : "ML-024 (Delete) CH-024",
        "interaction" : "Delete",
        "SUID" : 2361,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2358",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2358,
        "Ingredient_Affected" : "Maltose",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2355",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2355,
        "Ingredient_Affected" : "Red_Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2352",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2352,
        "Ingredient_Affected" : "Red_Wine_Vinegar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2349",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2349,
        "Ingredient_Affected" : "Cooking_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2346",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2346,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2343",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2343,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2340",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2340,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2337",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2337,
        "Ingredient_Affected" : "Hoisin_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2334",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2334,
        "Ingredient_Affected" : "White_Fermented_Bean_Curd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2331",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2331,
        "Ingredient_Affected" : "Red_Fermented_Bean_Curd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2328",
        "source" : "386",
        "target" : "380",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-024 (Insert) CH-024",
        "name" : "ML-024 (Insert) CH-024",
        "interaction" : "Insert",
        "SUID" : 2328,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2324",
        "source" : "374",
        "target" : "344",
        "Description" : "Substituted sauce for oyster sauce",
        "shared_interaction" : "Update",
        "shared_name" : "RM-023 (Update) CH-023",
        "name" : "RM-023 (Update) CH-023",
        "interaction" : "Update",
        "SUID" : 2324,
        "Ingredient_Affected" : "Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2321",
        "source" : "374",
        "target" : "344",
        "Description" : "Substituted mushroom for dried shiitake mushroom",
        "shared_interaction" : "Update",
        "shared_name" : "RM-023 (Update) CH-023",
        "name" : "RM-023 (Update) CH-023",
        "interaction" : "Update",
        "SUID" : 2321,
        "Ingredient_Affected" : "Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2318",
        "source" : "374",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-023 (Delete) CH-023",
        "name" : "RM-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2318,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2315",
        "source" : "374",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-023 (Delete) CH-023",
        "name" : "RM-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2315,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2312",
        "source" : "374",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-023 (Delete) CH-023",
        "name" : "RM-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2312,
        "Ingredient_Affected" : "Red_Date",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2309",
        "source" : "374",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-023 (Insert) CH-023",
        "name" : "RM-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2309,
        "Ingredient_Affected" : "Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2306",
        "source" : "374",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-023 (Insert) CH-023",
        "name" : "RM-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2306,
        "Ingredient_Affected" : "Goji_Berry",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2303",
        "source" : "374",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-023 (Insert) CH-023",
        "name" : "RM-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2303,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2300",
        "source" : "374",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-023 (Insert) CH-023",
        "name" : "RM-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2300,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2297",
        "source" : "374",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-023 (Insert) CH-023",
        "name" : "RM-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2297,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2293",
        "source" : "368",
        "target" : "344",
        "Description" : "Substituted sauce for soy sauce",
        "shared_interaction" : "Update",
        "shared_name" : "WC-023 (Update) CH-023",
        "name" : "WC-023 (Update) CH-023",
        "interaction" : "Update",
        "SUID" : 2293,
        "Ingredient_Affected" : "Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2290",
        "source" : "368",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-023 (Delete) CH-023",
        "name" : "WC-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2290,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2287",
        "source" : "368",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-023 (Delete) CH-023",
        "name" : "WC-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2287,
        "Ingredient_Affected" : "Red_Date",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2284",
        "source" : "368",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-023 (Delete) CH-023",
        "name" : "WC-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2284,
        "Ingredient_Affected" : "Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2281",
        "source" : "368",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-023 (Insert) CH-023",
        "name" : "WC-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2281,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2278",
        "source" : "368",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-023 (Insert) CH-023",
        "name" : "WC-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2278,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2274",
        "source" : "362",
        "target" : "344",
        "Description" : "Substituted sauce for oyster sauce",
        "shared_interaction" : "Update",
        "shared_name" : "OC-023 (Update) CH-023",
        "name" : "OC-023 (Update) CH-023",
        "interaction" : "Update",
        "SUID" : 2274,
        "Ingredient_Affected" : "Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2271",
        "source" : "362",
        "target" : "344",
        "Description" : "Substituted mushroom for dried shiitake mushroom",
        "shared_interaction" : "Update",
        "shared_name" : "OC-023 (Update) CH-023",
        "name" : "OC-023 (Update) CH-023",
        "interaction" : "Update",
        "SUID" : 2271,
        "Ingredient_Affected" : "Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2268",
        "source" : "362",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-023 (Delete) CH-023",
        "name" : "OC-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2268,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2265",
        "source" : "362",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-023 (Delete) CH-023",
        "name" : "OC-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2265,
        "Ingredient_Affected" : "Red_Date",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2262",
        "source" : "362",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-023 (Insert) CH-023",
        "name" : "OC-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2262,
        "Ingredient_Affected" : "Goji_Berry",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2259",
        "source" : "362",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-023 (Insert) CH-023",
        "name" : "OC-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2259,
        "Ingredient_Affected" : "Dried_Lily_Flower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2256",
        "source" : "362",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-023 (Insert) CH-023",
        "name" : "OC-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2256,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2253",
        "source" : "362",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-023 (Insert) CH-023",
        "name" : "OC-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2253,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2249",
        "source" : "356",
        "target" : "344",
        "Description" : "Substituted sauce for oyster sauce",
        "shared_interaction" : "Update",
        "shared_name" : "ML-023 (Update) CH-023",
        "name" : "ML-023 (Update) CH-023",
        "interaction" : "Update",
        "SUID" : 2249,
        "Ingredient_Affected" : "Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2246",
        "source" : "356",
        "target" : "344",
        "Description" : "Substituted mushroom for dried shiitake mushroom",
        "shared_interaction" : "Update",
        "shared_name" : "ML-023 (Update) CH-023",
        "name" : "ML-023 (Update) CH-023",
        "interaction" : "Update",
        "SUID" : 2246,
        "Ingredient_Affected" : "Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2243",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-023 (Delete) CH-023",
        "name" : "ML-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2243,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2240",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-023 (Delete) CH-023",
        "name" : "ML-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2240,
        "Ingredient_Affected" : "Red_Date",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2237",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-023 (Insert) CH-023",
        "name" : "ML-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2237,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2234",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-023 (Insert) CH-023",
        "name" : "ML-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2234,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2231",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-023 (Insert) CH-023",
        "name" : "ML-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2231,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2228",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-023 (Insert) CH-023",
        "name" : "ML-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2228,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2225",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-023 (Insert) CH-023",
        "name" : "ML-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2225,
        "Ingredient_Affected" : "Shallot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2222",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-023 (Insert) CH-023",
        "name" : "ML-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2222,
        "Ingredient_Affected" : "Cooking_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2219",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-023 (Insert) CH-023",
        "name" : "ML-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2219,
        "Ingredient_Affected" : "Chinese_Sausage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2216",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-023 (Insert) CH-023",
        "name" : "ML-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2216,
        "Ingredient_Affected" : "Goji_Berry",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2213",
        "source" : "356",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-023 (Insert) CH-023",
        "name" : "ML-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2213,
        "Ingredient_Affected" : "Wood_Ear_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2209",
        "source" : "350",
        "target" : "344",
        "Description" : "Substituted sauce for oyster sauce",
        "shared_interaction" : "Update",
        "shared_name" : "WL-023 (Update) CH-023",
        "name" : "WL-023 (Update) CH-023",
        "interaction" : "Update",
        "SUID" : 2209,
        "Ingredient_Affected" : "Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2206",
        "source" : "350",
        "target" : "344",
        "Description" : "Substituted mushroom for dried wood ear mushroom and dried shiitake mushroom",
        "shared_interaction" : "Update",
        "shared_name" : "WL-023 (Update) CH-023",
        "name" : "WL-023 (Update) CH-023",
        "interaction" : "Update",
        "SUID" : 2206,
        "Ingredient_Affected" : "Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2203",
        "source" : "350",
        "target" : "344",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-023 (Delete) CH-023",
        "name" : "WL-023 (Delete) CH-023",
        "interaction" : "Delete",
        "SUID" : 2203,
        "Ingredient_Affected" : "Red_Date",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2200",
        "source" : "350",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-023 (Insert) CH-023",
        "name" : "WL-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2200,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2197",
        "source" : "350",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-023 (Insert) CH-023",
        "name" : "WL-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2197,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2194",
        "source" : "350",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-023 (Insert) CH-023",
        "name" : "WL-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2194,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2191",
        "source" : "350",
        "target" : "344",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-023 (Insert) CH-023",
        "name" : "WL-023 (Insert) CH-023",
        "interaction" : "Insert",
        "SUID" : 2191,
        "Ingredient_Affected" : "Dried_Lily_Flower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2187",
        "source" : "338",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-020 (Insert) CH-020",
        "name" : "OC-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2187,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2184",
        "source" : "338",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-020 (Insert) CH-020",
        "name" : "OC-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2184,
        "Ingredient_Affected" : "Sand_Ginger_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2181",
        "source" : "338",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-020 (Insert) CH-020",
        "name" : "OC-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2181,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2177",
        "source" : "332",
        "target" : "320",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-020 (Delete) CH-020",
        "name" : "ML-020 (Delete) CH-020",
        "interaction" : "Delete",
        "SUID" : 2177,
        "Ingredient_Affected" : "Spicery_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2174",
        "source" : "332",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-020 (Insert) CH-020",
        "name" : "ML-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2174,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2171",
        "source" : "332",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-020 (Insert) CH-020",
        "name" : "ML-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2171,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2168",
        "source" : "332",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-020 (Insert) CH-020",
        "name" : "ML-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2168,
        "Ingredient_Affected" : "Sand_Ginger_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2164",
        "source" : "326",
        "target" : "320",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-020 (Delete) CH-020",
        "name" : "WL-020 (Delete) CH-020",
        "interaction" : "Delete",
        "SUID" : 2164,
        "Ingredient_Affected" : "Spicery_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2161",
        "source" : "326",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-020 (Insert) CH-020",
        "name" : "WL-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2161,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2158",
        "source" : "326",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-020 (Insert) CH-020",
        "name" : "WL-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2158,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2155",
        "source" : "326",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-020 (Insert) CH-020",
        "name" : "WL-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2155,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2152",
        "source" : "326",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-020 (Insert) CH-020",
        "name" : "WL-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2152,
        "Ingredient_Affected" : "Sand_Ginger_Powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2149",
        "source" : "326",
        "target" : "320",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-020 (Insert) CH-020",
        "name" : "WL-020 (Insert) CH-020",
        "interaction" : "Insert",
        "SUID" : 2149,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2145",
        "source" : "314",
        "target" : "296",
        "Description" : "Substituted mushroom for dried shiitake mushroom",
        "shared_interaction" : "Update",
        "shared_name" : "RM-014 (Update) CH-014",
        "name" : "RM-014 (Update) CH-014",
        "interaction" : "Update",
        "SUID" : 2145,
        "Ingredient_Affected" : "Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2142",
        "source" : "314",
        "target" : "296",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-014 (Delete) CH-014",
        "name" : "RM-014 (Delete) CH-014",
        "interaction" : "Delete",
        "SUID" : 2142,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2139",
        "source" : "314",
        "target" : "296",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-014 (Delete) CH-014",
        "name" : "RM-014 (Delete) CH-014",
        "interaction" : "Delete",
        "SUID" : 2139,
        "Ingredient_Affected" : "Water_Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2136",
        "source" : "314",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-014 (Insert) CH-014",
        "name" : "RM-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2136,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2133",
        "source" : "314",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-014 (Insert) CH-014",
        "name" : "RM-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2133,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2130",
        "source" : "314",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-014 (Insert) CH-014",
        "name" : "RM-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2130,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2127",
        "source" : "314",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-014 (Insert) CH-014",
        "name" : "RM-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2127,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2124",
        "source" : "314",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-014 (Insert) CH-014",
        "name" : "RM-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2124,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2121",
        "source" : "314",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-014 (Insert) CH-014",
        "name" : "RM-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2121,
        "Ingredient_Affected" : "Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2118",
        "source" : "314",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-014 (Insert) CH-014",
        "name" : "RM-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2118,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2114",
        "source" : "308",
        "target" : "296",
        "Description" : "Substituted mushroom for dried shiitake mushroom",
        "shared_interaction" : "Update",
        "shared_name" : "OC-014 (Update) CH-014",
        "name" : "OC-014 (Update) CH-014",
        "interaction" : "Update",
        "SUID" : 2114,
        "Ingredient_Affected" : "Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2111",
        "source" : "308",
        "target" : "296",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-014 (Delete) CH-014",
        "name" : "OC-014 (Delete) CH-014",
        "interaction" : "Delete",
        "SUID" : 2111,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2108",
        "source" : "308",
        "target" : "296",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-014 (Delete) CH-014",
        "name" : "OC-014 (Delete) CH-014",
        "interaction" : "Delete",
        "SUID" : 2108,
        "Ingredient_Affected" : "Water_Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2105",
        "source" : "308",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-014 (Insert) CH-014",
        "name" : "OC-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2105,
        "Ingredient_Affected" : "Cinammon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2102",
        "source" : "308",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-014 (Insert) CH-014",
        "name" : "OC-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2102,
        "Ingredient_Affected" : "Star_Anise",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2099",
        "source" : "308",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-014 (Insert) CH-014",
        "name" : "OC-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2099,
        "Ingredient_Affected" : "Rock_Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2096",
        "source" : "308",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-014 (Insert) CH-014",
        "name" : "OC-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2096,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2093",
        "source" : "308",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-014 (Insert) CH-014",
        "name" : "OC-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2093,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2090",
        "source" : "308",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-014 (Insert) CH-014",
        "name" : "OC-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2090,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2087",
        "source" : "308",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-014 (Insert) CH-014",
        "name" : "OC-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2087,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2084",
        "source" : "308",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-014 (Insert) CH-014",
        "name" : "OC-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2084,
        "Ingredient_Affected" : "Peanut_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2080",
        "source" : "302",
        "target" : "296",
        "Description" : "Substituted mushroom for dried shiitake mushroom",
        "shared_interaction" : "Update",
        "shared_name" : "WL-014 (Update) CH-014",
        "name" : "WL-014 (Update) CH-014",
        "interaction" : "Update",
        "SUID" : 2080,
        "Ingredient_Affected" : "Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2077",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-014 (Delete) CH-014",
        "name" : "WL-014 (Delete) CH-014",
        "interaction" : "Delete",
        "SUID" : 2077,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2074",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-014 (Delete) CH-014",
        "name" : "WL-014 (Delete) CH-014",
        "interaction" : "Delete",
        "SUID" : 2074,
        "Ingredient_Affected" : "Water_Chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2071",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2071,
        "Ingredient_Affected" : "Water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2068",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2068,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2065",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2065,
        "Ingredient_Affected" : "Dark_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2062",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2062,
        "Ingredient_Affected" : "Star_Anise",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2059",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2059,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2056",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2056,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2053",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2053,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2050",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2050,
        "Ingredient_Affected" : "Neutral_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2047",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2047,
        "Ingredient_Affected" : "Light_Soy_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2044",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2044,
        "Ingredient_Affected" : "White_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2041",
        "source" : "302",
        "target" : "296",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-014 (Insert) CH-014",
        "name" : "WL-014 (Insert) CH-014",
        "interaction" : "Insert",
        "SUID" : 2041,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2037",
        "source" : "290",
        "target" : "266",
        "Description" : "Substituted lard for oil",
        "shared_interaction" : "Update",
        "shared_name" : "RM-011 (Update) CH-011",
        "name" : "RM-011 (Update) CH-011",
        "interaction" : "Update",
        "SUID" : 2037,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2034",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-011 (Delete) CH-011",
        "name" : "RM-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 2034,
        "Ingredient_Affected" : "Chinese_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2031",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-011 (Delete) CH-011",
        "name" : "RM-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 2031,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2028",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-011 (Delete) CH-011",
        "name" : "RM-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 2028,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2025",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-011 (Insert) CH-011",
        "name" : "RM-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 2025,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2022",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-011 (Insert) CH-011",
        "name" : "RM-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 2022,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2019",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-011 (Insert) CH-011",
        "name" : "RM-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 2019,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2016",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-011 (Insert) CH-011",
        "name" : "RM-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 2016,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2013",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-011 (Insert) CH-011",
        "name" : "RM-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 2013,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2010",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-011 (Insert) CH-011",
        "name" : "RM-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 2010,
        "Ingredient_Affected" : "Carrot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2007",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-011 (Insert) CH-011",
        "name" : "RM-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 2007,
        "Ingredient_Affected" : "Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2004",
        "source" : "290",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-011 (Insert) CH-011",
        "name" : "RM-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 2004,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2000",
        "source" : "284",
        "target" : "266",
        "Description" : "Substituted lard for peanut oil",
        "shared_interaction" : "Update",
        "shared_name" : "OC-011 (Update) CH-011",
        "name" : "OC-011 (Update) CH-011",
        "interaction" : "Update",
        "SUID" : 2000,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1997",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-011 (Delete) CH-011",
        "name" : "OC-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 1997,
        "Ingredient_Affected" : "Chinese_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1994",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-011 (Delete) CH-011",
        "name" : "OC-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 1994,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1991",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-011 (Delete) CH-011",
        "name" : "OC-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 1991,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1988",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-011 (Insert) CH-011",
        "name" : "OC-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1988,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1985",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-011 (Insert) CH-011",
        "name" : "OC-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1985,
        "Ingredient_Affected" : "Hot_Pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1982",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-011 (Insert) CH-011",
        "name" : "OC-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1982,
        "Ingredient_Affected" : "Carrot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1979",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-011 (Insert) CH-011",
        "name" : "OC-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1979,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1976",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-011 (Insert) CH-011",
        "name" : "OC-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1976,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1973",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-011 (Insert) CH-011",
        "name" : "OC-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1973,
        "Ingredient_Affected" : "Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1970",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-011 (Insert) CH-011",
        "name" : "OC-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1970,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1967",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-011 (Insert) CH-011",
        "name" : "OC-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1967,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1964",
        "source" : "284",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-011 (Insert) CH-011",
        "name" : "OC-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1964,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1960",
        "source" : "278",
        "target" : "266",
        "Description" : "Substituted lard for corn oil",
        "shared_interaction" : "Update",
        "shared_name" : "ML-011 (Update) CH-011",
        "name" : "ML-011 (Update) CH-011",
        "interaction" : "Update",
        "SUID" : 1960,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1957",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-011 (Delete) CH-011",
        "name" : "ML-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 1957,
        "Ingredient_Affected" : "Salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1954",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-011 (Delete) CH-011",
        "name" : "ML-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 1954,
        "Ingredient_Affected" : "Chinese_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1951",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-011 (Delete) CH-011",
        "name" : "ML-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 1951,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1948",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-011 (Insert) CH-011",
        "name" : "ML-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1948,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1945",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-011 (Insert) CH-011",
        "name" : "ML-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1945,
        "Ingredient_Affected" : "Chicken_Bouillon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1942",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-011 (Insert) CH-011",
        "name" : "ML-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1942,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1939",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-011 (Insert) CH-011",
        "name" : "ML-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1939,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1936",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-011 (Insert) CH-011",
        "name" : "ML-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1936,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1933",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-011 (Insert) CH-011",
        "name" : "ML-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1933,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1930",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-011 (Insert) CH-011",
        "name" : "ML-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1930,
        "Ingredient_Affected" : "Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1927",
        "source" : "278",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-011 (Insert) CH-011",
        "name" : "ML-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1927,
        "Ingredient_Affected" : "Carrot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1923",
        "source" : "272",
        "target" : "266",
        "Description" : "Substituted lard for neutral oil",
        "shared_interaction" : "Update",
        "shared_name" : "WL-011 (Update) CH-011",
        "name" : "WL-011 (Update) CH-011",
        "interaction" : "Update",
        "SUID" : 1923,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1920",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-011 (Delete) CH-011",
        "name" : "WL-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 1920,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1917",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-011 (Delete) CH-011",
        "name" : "WL-011 (Delete) CH-011",
        "interaction" : "Delete",
        "SUID" : 1917,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1914",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1914,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1911",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1911,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1908",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1908,
        "Ingredient_Affected" : "Snap_Pea",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1905",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1905,
        "Ingredient_Affected" : "Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1902",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1902,
        "Ingredient_Affected" : "Carrot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1899",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1899,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1896",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1896,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1893",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1893,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1890",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1890,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1887",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1887,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1884",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1884,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1881",
        "source" : "272",
        "target" : "266",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-011 (Insert) CH-011",
        "name" : "WL-011 (Insert) CH-011",
        "interaction" : "Insert",
        "SUID" : 1881,
        "Ingredient_Affected" : "Chicken",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1877",
        "source" : "260",
        "target" : "185",
        "Description" : "Substituted lard for cooking oil",
        "shared_interaction" : "Update",
        "shared_name" : "RM-010 (Update) CH-010",
        "name" : "RM-010 (Update) CH-010",
        "interaction" : "Update",
        "SUID" : 1877,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1874",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-010 (Delete) CH-010",
        "name" : "RM-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1874,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1871",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-010 (Delete) CH-010",
        "name" : "RM-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1871,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1868",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-010 (Delete) CH-010",
        "name" : "RM-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1868,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1865",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-010 (Delete) CH-010",
        "name" : "RM-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1865,
        "Ingredient_Affected" : "Roast_Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1862",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-010 (Delete) CH-010",
        "name" : "RM-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1862,
        "Ingredient_Affected" : "Raw_Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1859",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "RM-010 (Delete) CH-010",
        "name" : "RM-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1859,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1856",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-010 (Insert) CH-010",
        "name" : "RM-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1856,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1853",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-010 (Insert) CH-010",
        "name" : "RM-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1853,
        "Ingredient_Affected" : "Carrot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1850",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-010 (Insert) CH-010",
        "name" : "RM-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1850,
        "Ingredient_Affected" : "Cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1847",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-010 (Insert) CH-010",
        "name" : "RM-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1847,
        "Ingredient_Affected" : "Shrimp",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1844",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-010 (Insert) CH-010",
        "name" : "RM-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1844,
        "Ingredient_Affected" : "Chicken",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1841",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-010 (Insert) CH-010",
        "name" : "RM-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1841,
        "Ingredient_Affected" : "Garlic",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1838",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-010 (Insert) CH-010",
        "name" : "RM-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1838,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1835",
        "source" : "260",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "RM-010 (Insert) CH-010",
        "name" : "RM-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1835,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1831",
        "source" : "254",
        "target" : "185",
        "Description" : "Substituted lard for cooking oil",
        "shared_interaction" : "Update",
        "shared_name" : "WC-010 (Update) CH-010",
        "name" : "WC-010 (Update) CH-010",
        "interaction" : "Update",
        "SUID" : 1831,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1828",
        "source" : "254",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-010 (Delete) CH-010",
        "name" : "WC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1828,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1825",
        "source" : "254",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-010 (Delete) CH-010",
        "name" : "WC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1825,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1822",
        "source" : "254",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-010 (Delete) CH-010",
        "name" : "WC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1822,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1819",
        "source" : "254",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-010 (Delete) CH-010",
        "name" : "WC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1819,
        "Ingredient_Affected" : "Roast_Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1816",
        "source" : "254",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WC-010 (Delete) CH-010",
        "name" : "WC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1816,
        "Ingredient_Affected" : "Raw_Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1813",
        "source" : "254",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-010 (Insert) CH-010",
        "name" : "WC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1813,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1810",
        "source" : "254",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-010 (Insert) CH-010",
        "name" : "WC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1810,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1807",
        "source" : "254",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-010 (Insert) CH-010",
        "name" : "WC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1807,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1804",
        "source" : "254",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "WC-010 (Insert) CH-010",
        "name" : "WC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1804,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1800",
        "source" : "248",
        "target" : "185",
        "Description" : "Substituted lard for peanut oil",
        "shared_interaction" : "Update",
        "shared_name" : "OC-010 (Update) CH-010",
        "name" : "OC-010 (Update) CH-010",
        "interaction" : "Update",
        "SUID" : 1800,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1797",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-010 (Delete) CH-010",
        "name" : "OC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1797,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1794",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-010 (Delete) CH-010",
        "name" : "OC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1794,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1791",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-010 (Delete) CH-010",
        "name" : "OC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1791,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1788",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-010 (Delete) CH-010",
        "name" : "OC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1788,
        "Ingredient_Affected" : "Roast_Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1785",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-010 (Delete) CH-010",
        "name" : "OC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1785,
        "Ingredient_Affected" : "Raw_Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1782",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "OC-010 (Delete) CH-010",
        "name" : "OC-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1782,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1779",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-010 (Insert) CH-010",
        "name" : "OC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1779,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1776",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-010 (Insert) CH-010",
        "name" : "OC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1776,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1773",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-010 (Insert) CH-010",
        "name" : "OC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1773,
        "Ingredient_Affected" : "Bamboo_Shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1770",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-010 (Insert) CH-010",
        "name" : "OC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1770,
        "Ingredient_Affected" : "Bok_Choy",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1767",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-010 (Insert) CH-010",
        "name" : "OC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1767,
        "Ingredient_Affected" : "White_Mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1764",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-010 (Insert) CH-010",
        "name" : "OC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1764,
        "Ingredient_Affected" : "Carrot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1761",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-010 (Insert) CH-010",
        "name" : "OC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1761,
        "Ingredient_Affected" : "Ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1758",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-010 (Insert) CH-010",
        "name" : "OC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1758,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1755",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-010 (Insert) CH-010",
        "name" : "OC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1755,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1752",
        "source" : "248",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "OC-010 (Insert) CH-010",
        "name" : "OC-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1752,
        "Ingredient_Affected" : "Vegetable_Stock",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1748",
        "source" : "242",
        "target" : "185",
        "Description" : "Substituted lard for corn oil",
        "shared_interaction" : "Update",
        "shared_name" : "ML-010 (Update) CH-010",
        "name" : "ML-010 (Update) CH-010",
        "interaction" : "Update",
        "SUID" : 1748,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1745",
        "source" : "242",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-010 (Delete) CH-010",
        "name" : "ML-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1745,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1742",
        "source" : "242",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-010 (Delete) CH-010",
        "name" : "ML-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1742,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1739",
        "source" : "242",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-010 (Delete) CH-010",
        "name" : "ML-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1739,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1736",
        "source" : "242",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-010 (Delete) CH-010",
        "name" : "ML-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1736,
        "Ingredient_Affected" : "Roast_Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1733",
        "source" : "242",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "ML-010 (Delete) CH-010",
        "name" : "ML-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1733,
        "Ingredient_Affected" : "Raw_Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1730",
        "source" : "242",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-010 (Insert) CH-010",
        "name" : "ML-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1730,
        "Ingredient_Affected" : "Sesame Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1727",
        "source" : "242",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-010 (Insert) CH-010",
        "name" : "ML-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1727,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1724",
        "source" : "242",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-010 (Insert) CH-010",
        "name" : "ML-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1724,
        "Ingredient_Affected" : "Oyster_Sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1721",
        "source" : "242",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-010 (Insert) CH-010",
        "name" : "ML-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1721,
        "Ingredient_Affected" : "Bean_Sprout",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1718",
        "source" : "242",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "ML-010 (Insert) CH-010",
        "name" : "ML-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1718,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1708",
        "source" : "236",
        "target" : "185",
        "Description" : "Substituted lard for vegetable oil",
        "shared_interaction" : "Update",
        "shared_name" : "WL-010 (Update) CH-010",
        "name" : "WL-010 (Update) CH-010",
        "interaction" : "Update",
        "SUID" : 1708,
        "Ingredient_Affected" : "Lard",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1705",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-010 (Delete) CH-010",
        "name" : "WL-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1705,
        "Ingredient_Affected" : "Primary_Soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1702",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-010 (Delete) CH-010",
        "name" : "WL-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1702,
        "Ingredient_Affected" : "Cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1699",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-010 (Delete) CH-010",
        "name" : "WL-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1699,
        "Ingredient_Affected" : "Egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1696",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-010 (Delete) CH-010",
        "name" : "WL-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1696,
        "Ingredient_Affected" : "Roast_Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1693",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-010 (Delete) CH-010",
        "name" : "WL-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1693,
        "Ingredient_Affected" : "Raw_Pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1690",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Delete",
        "shared_name" : "WL-010 (Delete) CH-010",
        "name" : "WL-010 (Delete) CH-010",
        "interaction" : "Delete",
        "SUID" : 1690,
        "Ingredient_Affected" : "Onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1687",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-010 (Insert) CH-010",
        "name" : "WL-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1687,
        "Ingredient_Affected" : "Shaoxing_Wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1684",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-010 (Insert) CH-010",
        "name" : "WL-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1684,
        "Ingredient_Affected" : "Sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1681",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-010 (Insert) CH-010",
        "name" : "WL-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1681,
        "Ingredient_Affected" : "Sesame_Oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1678",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-010 (Insert) CH-010",
        "name" : "WL-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1678,
        "Ingredient_Affected" : "Scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1669",
        "source" : "236",
        "target" : "185",
        "shared_interaction" : "Insert",
        "shared_name" : "WL-010 (Insert) CH-010",
        "name" : "WL-010 (Insert) CH-010",
        "interaction" : "Insert",
        "SUID" : 1669,
        "Ingredient_Affected" : "Broccoli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1666",
        "source" : "183",
        "target" : "902",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-142",
        "name" : "The Chinese Cook Book (Source) CH-142",
        "interaction" : "Source",
        "SUID" : 1666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1663",
        "source" : "183",
        "target" : "872",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-141",
        "name" : "The Chinese Cook Book (Source) CH-141",
        "interaction" : "Source",
        "SUID" : 1663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1660",
        "source" : "183",
        "target" : "842",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-138",
        "name" : "The Chinese Cook Book (Source) CH-138",
        "interaction" : "Source",
        "SUID" : 1660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1657",
        "source" : "183",
        "target" : "812",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-137",
        "name" : "The Chinese Cook Book (Source) CH-137",
        "interaction" : "Source",
        "SUID" : 1657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1654",
        "source" : "183",
        "target" : "788",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-136",
        "name" : "The Chinese Cook Book (Source) CH-136",
        "interaction" : "Source",
        "SUID" : 1654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1651",
        "source" : "183",
        "target" : "752",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-135",
        "name" : "The Chinese Cook Book (Source) CH-135",
        "interaction" : "Source",
        "SUID" : 1651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1648",
        "source" : "183",
        "target" : "716",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-133",
        "name" : "The Chinese Cook Book (Source) CH-133",
        "interaction" : "Source",
        "SUID" : 1648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1645",
        "source" : "183",
        "target" : "686",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-115",
        "name" : "The Chinese Cook Book (Source) CH-115",
        "interaction" : "Source",
        "SUID" : 1645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1642",
        "source" : "183",
        "target" : "662",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-112",
        "name" : "The Chinese Cook Book (Source) CH-112",
        "interaction" : "Source",
        "SUID" : 1642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1639",
        "source" : "183",
        "target" : "638",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-110",
        "name" : "The Chinese Cook Book (Source) CH-110",
        "interaction" : "Source",
        "SUID" : 1639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1636",
        "source" : "183",
        "target" : "608",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-092",
        "name" : "The Chinese Cook Book (Source) CH-092",
        "interaction" : "Source",
        "SUID" : 1636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1633",
        "source" : "183",
        "target" : "578",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-089",
        "name" : "The Chinese Cook Book (Source) CH-089",
        "interaction" : "Source",
        "SUID" : 1633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1630",
        "source" : "183",
        "target" : "548",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-067",
        "name" : "The Chinese Cook Book (Source) CH-067",
        "interaction" : "Source",
        "SUID" : 1630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1627",
        "source" : "183",
        "target" : "524",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-066",
        "name" : "The Chinese Cook Book (Source) CH-066",
        "interaction" : "Source",
        "SUID" : 1627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1624",
        "source" : "183",
        "target" : "488",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-060",
        "name" : "The Chinese Cook Book (Source) CH-060",
        "interaction" : "Source",
        "SUID" : 1624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1621",
        "source" : "183",
        "target" : "458",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-053",
        "name" : "The Chinese Cook Book (Source) CH-053",
        "interaction" : "Source",
        "SUID" : 1621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1618",
        "source" : "183",
        "target" : "434",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-051",
        "name" : "The Chinese Cook Book (Source) CH-051",
        "interaction" : "Source",
        "SUID" : 1618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1615",
        "source" : "183",
        "target" : "410",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-025",
        "name" : "The Chinese Cook Book (Source) CH-025",
        "interaction" : "Source",
        "SUID" : 1615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1612",
        "source" : "183",
        "target" : "380",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-024",
        "name" : "The Chinese Cook Book (Source) CH-024",
        "interaction" : "Source",
        "SUID" : 1612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1609",
        "source" : "183",
        "target" : "344",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-023",
        "name" : "The Chinese Cook Book (Source) CH-023",
        "interaction" : "Source",
        "SUID" : 1609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1606",
        "source" : "183",
        "target" : "320",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-020",
        "name" : "The Chinese Cook Book (Source) CH-020",
        "interaction" : "Source",
        "SUID" : 1606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1603",
        "source" : "183",
        "target" : "296",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-014",
        "name" : "The Chinese Cook Book (Source) CH-014",
        "interaction" : "Source",
        "SUID" : 1603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1600",
        "source" : "183",
        "target" : "266",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-011",
        "name" : "The Chinese Cook Book (Source) CH-011",
        "interaction" : "Source",
        "SUID" : 1600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1597",
        "source" : "183",
        "target" : "185",
        "shared_interaction" : "Source",
        "shared_name" : "The Chinese Cook Book (Source) CH-010",
        "name" : "The Chinese Cook Book (Source) CH-010",
        "interaction" : "Source",
        "SUID" : 1597,
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"CCC_nodes.csv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "NULab_ Project Entities - nodes (1).csv",
    "name" : "CCC_nodes.csv",
    "SUID" : 155,
    "__Annotations" : [ ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "926",
        "shared_name" : "RM-142",
        "name" : "RM-142",
        "SUID" : 926,
        "Recipe_Name" : "Peanut Brittle",
        "selected" : false
      },
      "position" : {
        "x" : 104.47848267676466,
        "y" : 339.90371091487043
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "920",
        "shared_name" : "WC-142",
        "name" : "WC-142",
        "SUID" : 920,
        "Recipe_Name" : "Sesame Peanut Brittle (Fah Sung Thong)",
        "selected" : false
      },
      "position" : {
        "x" : 233.1742910874092,
        "y" : 256.19973142268293
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "914",
        "shared_name" : "OC-142",
        "name" : "OC-142",
        "SUID" : 914,
        "Recipe_Name" : "Chinese Peanut Brittle (花生糖)",
        "selected" : false
      },
      "position" : {
        "x" : 197.5212454331123,
        "y" : 314.97014768244856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "908",
        "shared_name" : "WL-142",
        "name" : "WL-142",
        "SUID" : 908,
        "Recipe_Name" : "Homemade Chinese Sesame Peanut Brittle",
        "selected" : false
      },
      "position" : {
        "x" : 66.91013093115919,
        "y" : 289.2502074969017
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "902",
        "shared_name" : "CH-142",
        "name" : "CH-142",
        "SUID" : 902,
        "Recipe_Name" : "Peanut Candy",
        "selected" : false
      },
      "position" : {
        "x" : 108.88643403174513,
        "y" : 196.07988889338606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "896",
        "shared_name" : "RM-141",
        "name" : "RM-141",
        "SUID" : 896,
        "Recipe_Name" : "Yam Cake",
        "selected" : false
      },
      "position" : {
        "x" : 295.6485647690498,
        "y" : -332.35744325993426
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "890",
        "shared_name" : "WC-141",
        "name" : "WC-141",
        "SUID" : 890,
        "Recipe_Name" : "Steamed Yam/Taro Cake (Orh Kueh/Wu Tau Koh)",
        "selected" : false
      },
      "position" : {
        "x" : 297.91754670264356,
        "y" : -393.0208801495827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "884",
        "shared_name" : "ML-141",
        "name" : "ML-141",
        "SUID" : 884,
        "Recipe_Name" : "Taro Cake",
        "selected" : false
      },
      "position" : {
        "x" : 364.8084463608467,
        "y" : -333.7499298321999
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "878",
        "shared_name" : "WL-141",
        "name" : "WL-141",
        "SUID" : 878,
        "Recipe_Name" : "Taro Cake (Chinese Wu Tao Gou)",
        "selected" : false
      },
      "position" : {
        "x" : 354.33551545264356,
        "y" : -265.83703462956316
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "872",
        "shared_name" : "CH-141",
        "name" : "CH-141",
        "SUID" : 872,
        "Recipe_Name" : "Gray Potato Pudding",
        "selected" : false
      },
      "position" : {
        "x" : 227.2563986313545,
        "y" : -234.65326158879168
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "866",
        "shared_name" : "RM-138",
        "name" : "RM-138",
        "SUID" : 866,
        "Recipe_Name" : "Paper Wrapped Sponge Cake",
        "selected" : false
      },
      "position" : {
        "x" : 500.2923635971748,
        "y" : -149.27847902653582
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "860",
        "shared_name" : "WC-138",
        "name" : "WC-138",
        "SUID" : 860,
        "Recipe_Name" : "Paper-Wrapped Sponge Cake (紙包蛋糕)",
        "selected" : false
      },
      "position" : {
        "x" : 436.6719717514717,
        "y" : -222.22032396672137
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "854",
        "shared_name" : "OC-138",
        "name" : "OC-138",
        "SUID" : 854,
        "Recipe_Name" : "Chinese Egg Cake (鸡蛋糕)",
        "selected" : false
      },
      "position" : {
        "x" : 439.44498200537794,
        "y" : -157.8783020245827
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "848",
        "shared_name" : "WL-138",
        "name" : "WL-138",
        "SUID" : 848,
        "Recipe_Name" : "Chinese Egg Cake",
        "selected" : false
      },
      "position" : {
        "x" : 475.22818513037794,
        "y" : -80.71709291813738
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "842",
        "shared_name" : "CH-138",
        "name" : "CH-138",
        "SUID" : 842,
        "Recipe_Name" : "Chinese Sponge Cake",
        "selected" : false
      },
      "position" : {
        "x" : 329.5375723374092,
        "y" : -106.48993532536394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "836",
        "shared_name" : "RM-137",
        "name" : "RM-137",
        "SUID" : 836,
        "Recipe_Name" : "Almond Cookies",
        "selected" : false
      },
      "position" : {
        "x" : 441.6562551987373,
        "y" : 231.10222776057356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "830",
        "shared_name" : "WC-137",
        "name" : "WC-137",
        "SUID" : 830,
        "Recipe_Name" : "Chinese Almond Cookies",
        "selected" : false
      },
      "position" : {
        "x" : 377.6218008530342,
        "y" : 263.8803649676048
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "824",
        "shared_name" : "OC-137",
        "name" : "OC-137",
        "SUID" : 824,
        "Recipe_Name" : "Chinese Almond Cookies",
        "selected" : false
      },
      "position" : {
        "x" : 424.5038809311592,
        "y" : 306.42531736018293
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "818",
        "shared_name" : "WL-137",
        "name" : "WL-137",
        "SUID" : 818,
        "Recipe_Name" : "Chinese Almond Cookies",
        "selected" : false
      },
      "position" : {
        "x" : 353.5523733627998,
        "y" : 334.07082517268293
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "812",
        "shared_name" : "CH-137",
        "name" : "CH-137",
        "SUID" : 812,
        "Recipe_Name" : "Almond Cake",
        "selected" : false
      },
      "position" : {
        "x" : 284.30435700537794,
        "y" : 197.05498654963606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "806",
        "shared_name" : "WC-136",
        "name" : "WC-136",
        "SUID" : 806,
        "Recipe_Name" : "Chinese Steamed Pork Buns (Bak Pao)",
        "selected" : false
      },
      "position" : {
        "x" : -21.040413426140617,
        "y" : -72.78549044011004
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "800",
        "shared_name" : "OC-136",
        "name" : "OC-136",
        "SUID" : 800,
        "Recipe_Name" : "Steamed Pork Buns with Chive (猪肉韭菜包子)",
        "selected" : false
      },
      "position" : {
        "x" : 72.07140107276075,
        "y" : 26.743463112136055
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "794",
        "shared_name" : "WL-136",
        "name" : "WL-136",
        "SUID" : 794,
        "Recipe_Name" : "Steamed Pork Buns (Baozi)",
        "selected" : false
      },
      "position" : {
        "x" : 149.81586213233106,
        "y" : -167.38201706288226
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "788",
        "shared_name" : "CH-136",
        "name" : "CH-136",
        "SUID" : 788,
        "Recipe_Name" : "Chinese Meat Buscuit",
        "selected" : false
      },
      "position" : {
        "x" : 79.99585480811231,
        "y" : -74.87904970524676
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "782",
        "shared_name" : "RM-135",
        "name" : "RM-135",
        "SUID" : 782,
        "Recipe_Name" : "Chinese Fried Rice",
        "selected" : false
      },
      "position" : {
        "x" : 51.58714051367872,
        "y" : -485.00583498356707
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "776",
        "shared_name" : "WC-135",
        "name" : "WC-135",
        "SUID" : 776,
        "Recipe_Name" : "Golden Egg Fried Rice",
        "selected" : false
      },
      "position" : {
        "x" : -101.59806303856737,
        "y" : -514.0380615460671
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "shared_name" : "OC-135",
        "name" : "OC-135",
        "SUID" : 770,
        "Recipe_Name" : "Easy Egg Fried Rice (蛋炒饭)",
        "selected" : false
      },
      "position" : {
        "x" : -17.98351721642382,
        "y" : -533.4362854230202
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "shared_name" : "ML-135",
        "name" : "ML-135",
        "SUID" : 764,
        "Recipe_Name" : "Fried Rice",
        "selected" : false
      },
      "position" : {
        "x" : -26.220581577996086,
        "y" : -474.7726196515358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "758",
        "shared_name" : "WL-135",
        "name" : "WL-135",
        "SUID" : 758,
        "Recipe_Name" : "Egg Fried Rice",
        "selected" : false
      },
      "position" : {
        "x" : -111.22715239403612,
        "y" : -449.19415895817644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "shared_name" : "CH-135",
        "name" : "CH-135",
        "SUID" : 752,
        "Recipe_Name" : "Fried Rice",
        "selected" : false
      },
      "position" : {
        "x" : -31.75017409203417,
        "y" : -357.5648712384499
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "746",
        "shared_name" : "RM-133",
        "name" : "RM-133",
        "SUID" : 746,
        "Recipe_Name" : "Chinese Hot Pot",
        "selected" : false
      },
      "position" : {
        "x" : -418.0801034438408,
        "y" : -236.68128816960223
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "740",
        "shared_name" : "WC-133",
        "name" : "WC-133",
        "SUID" : 740,
        "Recipe_Name" : "Chinese Steamboat/Hot Pot At Home",
        "selected" : false
      },
      "position" : {
        "x" : -456.8788094985283,
        "y" : -150.49700205204851
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "shared_name" : "OC-133",
        "name" : "OC-133",
        "SUID" : 734,
        "Recipe_Name" : "Hot Pot Guide (火锅)",
        "selected" : false
      },
      "position" : {
        "x" : -484.2368112075127,
        "y" : -206.49048273442156
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "shared_name" : "ML-133",
        "name" : "ML-133",
        "SUID" : 728,
        "Recipe_Name" : "Hot Pot at Home",
        "selected" : false
      },
      "position" : {
        "x" : -513.1193185317314,
        "y" : -116.04594652531512
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "722",
        "shared_name" : "WL-133",
        "name" : "WL-133",
        "SUID" : 722,
        "Recipe_Name" : "Sichuan Hot Pot",
        "selected" : false
      },
      "position" : {
        "x" : -483.0085397231377,
        "y" : -55.5605301129616
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "shared_name" : "CH-133",
        "name" : "CH-133",
        "SUID" : 716,
        "Recipe_Name" : "Stove Party",
        "selected" : false
      },
      "position" : {
        "x" : -344.6054940688408,
        "y" : -110.35931246159441
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "710",
        "shared_name" : "WC-115",
        "name" : "WC-115",
        "SUID" : 710,
        "Recipe_Name" : "Buddha’s Delight (Lo Han Jai)",
        "selected" : false
      },
      "position" : {
        "x" : -458.32439665673144,
        "y" : 182.2918639910423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "704",
        "shared_name" : "OC-115",
        "name" : "OC-115",
        "SUID" : 704,
        "Recipe_Name" : "Buddha’s Delight (Jai Chinese Vegetarian Stew)",
        "selected" : false
      },
      "position" : {
        "x" : -403.8629098403252,
        "y" : 162.9302917254173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "shared_name" : "ML-115",
        "name" : "ML-115",
        "SUID" : 698,
        "Recipe_Name" : "Buddha's Delight",
        "selected" : false
      },
      "position" : {
        "x" : -451.1498055922783,
        "y" : 97.91494138362043
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "shared_name" : "WL-115",
        "name" : "WL-115",
        "SUID" : 692,
        "Recipe_Name" : "Buddha’s Delight (Vegetarian Lo Han Jai)",
        "selected" : false
      },
      "position" : {
        "x" : -383.6695504653252,
        "y" : 228.16201169612043
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "686",
        "shared_name" : "CH-115",
        "name" : "CH-115",
        "SUID" : 686,
        "Recipe_Name" : "Food of the Immortal God of Lawn Horn",
        "selected" : false
      },
      "position" : {
        "x" : -290.7426705825127,
        "y" : 115.92485959651106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "680",
        "shared_name" : "WC-112",
        "name" : "WC-112",
        "SUID" : 680,
        "Recipe_Name" : "Dou Sha Bao (Red Bean Paste Steamed Buns)",
        "selected" : false
      },
      "position" : {
        "x" : 13.199814273139168,
        "y" : 479.26711423518293
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "674",
        "shared_name" : "OC-112",
        "name" : "OC-112",
        "SUID" : 674,
        "Recipe_Name" : "Red Bean Bread (豆沙包)",
        "selected" : false
      },
      "position" : {
        "x" : 54.148553324958016,
        "y" : 429.28725583674543
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "668",
        "shared_name" : "WL-112",
        "name" : "WL-112",
        "SUID" : 668,
        "Recipe_Name" : "Steamed Red Bean Buns",
        "selected" : false
      },
      "position" : {
        "x" : -32.33153777001269,
        "y" : 440.06020505549543
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "662",
        "shared_name" : "CH-112",
        "name" : "CH-112",
        "SUID" : 662,
        "Recipe_Name" : "Bean Buscuit",
        "selected" : false
      },
      "position" : {
        "x" : 3.9929205906593097,
        "y" : 297.39956052424543
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "shared_name" : "OC-110",
        "name" : "OC-110",
        "SUID" : 656,
        "Recipe_Name" : "Stuffed Tofu",
        "selected" : false
      },
      "position" : {
        "x" : -175.57073454735644,
        "y" : 79.96814878108137
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "650",
        "shared_name" : "ML-110",
        "name" : "ML-110",
        "SUID" : 650,
        "Recipe_Name" : "Fried Stuffed Tofu",
        "selected" : false
      },
      "position" : {
        "x" : 10.882941676398445,
        "y" : 156.9274841082298
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "644",
        "shared_name" : "WL-110",
        "name" : "WL-110",
        "SUID" : 644,
        "Recipe_Name" : "Crispy Skin Stuffed Tofu",
        "selected" : false
      },
      "position" : {
        "x" : -67.19189696190722,
        "y" : 185.28371579768293
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "shared_name" : "CH-110",
        "name" : "CH-110",
        "SUID" : 638,
        "Recipe_Name" : "Stuffed Triangle Bean Cake",
        "selected" : false
      },
      "position" : {
        "x" : -65.75641112206347,
        "y" : 82.24773557307356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "632",
        "shared_name" : "RM-092",
        "name" : "RM-092",
        "SUID" : 632,
        "Recipe_Name" : "Shrimp Omelette",
        "selected" : false
      },
      "position" : {
        "x" : 17.94578309180372,
        "y" : -318.451376365403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "626",
        "shared_name" : "OC-092",
        "name" : "OC-092",
        "SUID" : 626,
        "Recipe_Name" : "Shrimp Egg Foo Young (鲜虾芙蓉蛋)",
        "selected" : false
      },
      "position" : {
        "x" : -57.46268324730761,
        "y" : -284.05741731999285
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "620",
        "shared_name" : "ML-092",
        "name" : "ML-092",
        "SUID" : 620,
        "Recipe_Name" : "Cantonese Scrambled Eggs & Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 78.60593171240919,
        "y" : -328.36334841130144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "614",
        "shared_name" : "WL-092",
        "name" : "WL-092",
        "SUID" : 614,
        "Recipe_Name" : "Shrimp Egg Foo Young",
        "selected" : false
      },
      "position" : {
        "x" : 142.62019868018263,
        "y" : -288.3463882672585
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "608",
        "shared_name" : "CH-092",
        "name" : "CH-092",
        "SUID" : 608,
        "Recipe_Name" : "Shrimp Omelet",
        "selected" : false
      },
      "position" : {
        "x" : 31.122836543341805,
        "y" : -201.44339220402605
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "shared_name" : "RM-089",
        "name" : "RM-089",
        "SUID" : 602,
        "Recipe_Name" : "Egg Foo Young",
        "selected" : false
      },
      "position" : {
        "x" : -359.09173064110644,
        "y" : 86.9653259051048
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "shared_name" : "OC-089",
        "name" : "OC-089",
        "SUID" : 596,
        "Recipe_Name" : "Egg Foo Young",
        "selected" : false
      },
      "position" : {
        "x" : -338.98369841454394,
        "y" : 31.03170163752668
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "shared_name" : "ML-089",
        "name" : "ML-089",
        "SUID" : 590,
        "Recipe_Name" : "Egg Foo Young",
        "selected" : false
      },
      "position" : {
        "x" : -393.6819100844658,
        "y" : 0.3358245623313678
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "shared_name" : "WL-089",
        "name" : "WL-089",
        "SUID" : 584,
        "Recipe_Name" : "Egg Foo Young",
        "selected" : false
      },
      "position" : {
        "x" : -332.1414742934502,
        "y" : -38.37975160954363
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "shared_name" : "CH-089",
        "name" : "CH-089",
        "SUID" : 578,
        "Recipe_Name" : "Plain Omelet",
        "selected" : false
      },
      "position" : {
        "x" : -231.68192534325487,
        "y" : 20.305520607253243
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "shared_name" : "RM-067",
        "name" : "RM-067",
        "SUID" : 572,
        "Recipe_Name" : "Salt and Pepper Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 188.79730744483106,
        "y" : 454.1515746844017
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "shared_name" : "OC-067",
        "name" : "OC-067",
        "SUID" : 566,
        "Recipe_Name" : "3-Ingredient Fried Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 239.09898896338575,
        "y" : 420.5954223406517
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "shared_name" : "ML-067",
        "name" : "ML-067",
        "SUID" : 560,
        "Recipe_Name" : "Salt & Pepper Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 268.4556631577217,
        "y" : 371.59755857112043
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "554",
        "shared_name" : "WL-067",
        "name" : "WL-067",
        "SUID" : 554,
        "Recipe_Name" : "Fantail Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 136.8869375717842,
        "y" : 428.5871215594017
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "shared_name" : "CH-067",
        "name" : "CH-067",
        "SUID" : 548,
        "Recipe_Name" : "Fried Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : 146.93204255225294,
        "y" : 286.7340942156517
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "shared_name" : "WC-066",
        "name" : "WC-066",
        "SUID" : 542,
        "Recipe_Name" : "Chinese Steamed Garlic Prawns with Vermicelli Noodles",
        "selected" : false
      },
      "position" : {
        "x" : -150.47735075829394,
        "y" : 359.5601440203392
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "shared_name" : "ML-066",
        "name" : "ML-066",
        "SUID" : 536,
        "Recipe_Name" : "Steamed Garlic Shrimp on Vermicelli",
        "selected" : false
      },
      "position" : {
        "x" : -57.91647200463183,
        "y" : 369.24587400080793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "shared_name" : "WL-066",
        "name" : "WL-066",
        "SUID" : 530,
        "Recipe_Name" : "Steamed Shrimp with Glass Noodles",
        "selected" : false
      },
      "position" : {
        "x" : -111.46116118309862,
        "y" : 412.2567992937767
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "shared_name" : "CH-066",
        "name" : "CH-066",
        "SUID" : 524,
        "Recipe_Name" : "Steamed Shrimp",
        "selected" : false
      },
      "position" : {
        "x" : -63.74275450585253,
        "y" : 249.66689450862043
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "shared_name" : "RM-060",
        "name" : "RM-060",
        "SUID" : 518,
        "Recipe_Name" : "Steamed Fish",
        "selected" : false
      },
      "position" : {
        "x" : -232.53255705712206,
        "y" : -203.30607073185809
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "512",
        "shared_name" : "WC-060",
        "name" : "WC-060",
        "SUID" : 512,
        "Recipe_Name" : "Cantonese Steamed Fish",
        "selected" : false
      },
      "position" : {
        "x" : -278.8864999282158,
        "y" : -131.49044268010027
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "shared_name" : "OC-060",
        "name" : "OC-060",
        "SUID" : 506,
        "Recipe_Name" : "Steamed Fish",
        "selected" : false
      },
      "position" : {
        "x" : -141.5130563247002,
        "y" : -23.271139548996757
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "shared_name" : "ML-060",
        "name" : "ML-060",
        "SUID" : 500,
        "Recipe_Name" : "Steamed Fish",
        "selected" : false
      },
      "position" : {
        "x" : -258.50045256493456,
        "y" : -254.6125549542702
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "shared_name" : "WL-060",
        "name" : "WL-060",
        "SUID" : 494,
        "Recipe_Name" : "Cantonese Steamed Fish",
        "selected" : false
      },
      "position" : {
        "x" : -305.10772185204394,
        "y" : -197.92766420719988
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "shared_name" : "CH-060",
        "name" : "CH-060",
        "SUID" : 488,
        "Recipe_Name" : "Steamed Pike",
        "selected" : false
      },
      "position" : {
        "x" : -166.90781645653612,
        "y" : -129.0965408551491
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "shared_name" : "RM-053",
        "name" : "RM-053",
        "SUID" : 482,
        "Recipe_Name" : "Black Pepper Beef",
        "selected" : false
      },
      "position" : {
        "x" : 471.3843740952217,
        "y" : 125.6323180926048
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "shared_name" : "OC-053",
        "name" : "OC-053",
        "SUID" : 476,
        "Recipe_Name" : "Shredded Beef and Pepper Stir Fry (青椒肉丝)",
        "selected" : false
      },
      "position" : {
        "x" : 450.9955801499092,
        "y" : 15.729379249831368
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "shared_name" : "ML-053",
        "name" : "ML-053",
        "SUID" : 470,
        "Recipe_Name" : "Black Pepper Beef Stir Fry",
        "selected" : false
      },
      "position" : {
        "x" : 487.57352204444044,
        "y" : 64.62786252619856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "shared_name" : "WL-053",
        "name" : "WL-053",
        "SUID" : 464,
        "Recipe_Name" : "Beef and Pepper Stir-fry",
        "selected" : false
      },
      "position" : {
        "x" : 410.77301545264356,
        "y" : 147.74282224299543
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "shared_name" : "CH-053",
        "name" : "CH-053",
        "SUID" : 458,
        "Recipe_Name" : "Green Pepper Beef",
        "selected" : false
      },
      "position" : {
        "x" : 316.7168936264717,
        "y" : 62.35373838069074
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "shared_name" : "WC-051",
        "name" : "WC-051",
        "SUID" : 452,
        "Recipe_Name" : "Fried Stewed Country Spareribs/Zha Li Rou",
        "selected" : false
      },
      "position" : {
        "x" : 362.13788361670606,
        "y" : 25.151589943190743
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "shared_name" : "OC-051",
        "name" : "OC-051",
        "SUID" : 446,
        "Recipe_Name" : "Air Fryer Garlic Ribs (蒜香排骨)",
        "selected" : false
      },
      "position" : {
        "x" : 353.22672028662794,
        "y" : -36.23549501774676
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "shared_name" : "WL-051",
        "name" : "WL-051",
        "SUID" : 440,
        "Recipe_Name" : "Fried Ribs with Fermented Red Bean Curd",
        "selected" : false
      },
      "position" : {
        "x" : 293.40900178076856,
        "y" : 123.11818845393293
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "shared_name" : "CH-051",
        "name" : "CH-051",
        "SUID" : 434,
        "Recipe_Name" : "Fried Pigs' Ribs",
        "selected" : false
      },
      "position" : {
        "x" : 221.9150442612373,
        "y" : 20.956109596511055
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "shared_name" : "WC-025",
        "name" : "WC-025",
        "SUID" : 428,
        "Recipe_Name" : "Peking Duck",
        "selected" : false
      },
      "position" : {
        "x" : 200.04752106787794,
        "y" : -347.0566467511452
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "shared_name" : "OC-025",
        "name" : "OC-025",
        "SUID" : 422,
        "Recipe_Name" : "Chinese Roast Duck (烤鸭)",
        "selected" : false
      },
      "position" : {
        "x" : 101.25301118018263,
        "y" : -399.8039917218483
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "shared_name" : "WL-025",
        "name" : "WL-025",
        "SUID" : 416,
        "Recipe_Name" : "Roast Duck",
        "selected" : false
      },
      "position" : {
        "x" : 167.7280020249092,
        "y" : -405.22182314274676
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "shared_name" : "CH-025",
        "name" : "CH-025",
        "SUID" : 410,
        "Recipe_Name" : "Roast Duck",
        "selected" : false
      },
      "position" : {
        "x" : 99.45885224463575,
        "y" : -245.50542299626238
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "shared_name" : "RM-024",
        "name" : "RM-024",
        "SUID" : 404,
        "Recipe_Name" : "Chinese Roast Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 266.20963044287794,
        "y" : -53.92398683903582
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "shared_name" : "WC-024",
        "name" : "WC-024",
        "SUID" : 398,
        "Recipe_Name" : "Soy Sauce Brined Five-Spice Oven-Roasted Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 275.89847321631544,
        "y" : -136.8206276166237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "shared_name" : "OC-024",
        "name" : "OC-024",
        "SUID" : 392,
        "Recipe_Name" : "Cantonese Roast Chicken (广式烧鸡)",
        "selected" : false
      },
      "position" : {
        "x" : 230.21256013037794,
        "y" : -171.67025844929583
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "shared_name" : "ML-024",
        "name" : "ML-024",
        "SUID" : 386,
        "Recipe_Name" : "Whole Roasted Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 72.21044678809278,
        "y" : -144.52482645390398
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "shared_name" : "CH-024",
        "name" : "CH-024",
        "SUID" : 380,
        "Recipe_Name" : "Roast Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 157.139089061042,
        "y" : -78.65371553776629
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "shared_name" : "RM-023",
        "name" : "RM-023",
        "SUID" : 374,
        "Recipe_Name" : "Chinese Steamed Chicken",
        "selected" : false
      },
      "position" : {
        "x" : -294.1239266860283,
        "y" : 453.0545287859642
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "shared_name" : "WC-023",
        "name" : "WC-023",
        "SUID" : 368,
        "Recipe_Name" : "Steamed Chicken with Ginger and Scallion",
        "selected" : false
      },
      "position" : {
        "x" : -367.59343962548144,
        "y" : 323.78933103205793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "shared_name" : "OC-023",
        "name" : "OC-023",
        "SUID" : 362,
        "Recipe_Name" : "Chinese Steamed Chicken",
        "selected" : false
      },
      "position" : {
        "x" : -224.1430917250908,
        "y" : 447.49855954768293
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "shared_name" : "ML-023",
        "name" : "ML-023",
        "SUID" : 356,
        "Recipe_Name" : "Steamed Chicken with Mushroom and Chinese Sausage",
        "selected" : false
      },
      "position" : {
        "x" : -302.96444182274706,
        "y" : 387.9750610125267
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "shared_name" : "WL-023",
        "name" : "WL-023",
        "SUID" : 350,
        "Recipe_Name" : "Steamed Chicken with Mushrooms & Dried Lily Flowers",
        "selected" : false
      },
      "position" : {
        "x" : -366.5012155043877,
        "y" : 396.8713012469017
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "shared_name" : "CH-023",
        "name" : "CH-023",
        "SUID" : 344,
        "Recipe_Name" : "Steamed Chicken",
        "selected" : false
      },
      "position" : {
        "x" : -227.06034331200487,
        "y" : 299.2400756609642
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "shared_name" : "OC-020",
        "name" : "OC-020",
        "SUID" : 338,
        "Recipe_Name" : "Salt Baked Chicken (简易盐焗鸡)",
        "selected" : false
      },
      "position" : {
        "x" : 181.2469534409248,
        "y" : 188.2235046160423
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "shared_name" : "ML-020",
        "name" : "ML-020",
        "SUID" : 332,
        "Recipe_Name" : "Salt Baked Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 205.43526215674513,
        "y" : 119.9572692644798
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "shared_name" : "WL-020",
        "name" : "WL-020",
        "SUID" : 326,
        "Recipe_Name" : "Salt Baked Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 154.03954072119825,
        "y" : 13.89736325862043
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "shared_name" : "CH-020",
        "name" : "CH-020",
        "SUID" : 320,
        "Recipe_Name" : "Salt Chicken",
        "selected" : false
      },
      "position" : {
        "x" : 101.95252747656934,
        "y" : 99.54085691096418
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "shared_name" : "RM-014",
        "name" : "RM-014",
        "SUID" : 314,
        "Recipe_Name" : "Chestnut Chicken",
        "selected" : false
      },
      "position" : {
        "x" : -207.96517424462206,
        "y" : -71.33124391911394
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "shared_name" : "OC-014",
        "name" : "OC-014",
        "SUID" : 308,
        "Recipe_Name" : "Braised Chestnut Chicken (板栗炖鸡)",
        "selected" : false
      },
      "position" : {
        "x" : -73.61867003319628,
        "y" : -203.32335321782
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "shared_name" : "WL-014",
        "name" : "WL-014",
        "SUID" : 302,
        "Recipe_Name" : "Braised Chicken with Chestnuts – 栗子焖鸡",
        "selected" : false
      },
      "position" : {
        "x" : -140.7877145278252,
        "y" : -214.2092231976784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "shared_name" : "CH-014",
        "name" : "CH-014",
        "SUID" : 296,
        "Recipe_Name" : "Chestnut Chicken",
        "selected" : false
      },
      "position" : {
        "x" : -92.10383849022753,
        "y" : -97.32504122136004
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "shared_name" : "RM-011",
        "name" : "RM-011",
        "SUID" : 290,
        "Recipe_Name" : "Chicken Chow Mein",
        "selected" : false
      },
      "position" : {
        "x" : -188.1321969497002,
        "y" : 238.5757995379173
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "shared_name" : "OC-011",
        "name" : "OC-011",
        "SUID" : 284,
        "Recipe_Name" : "Chicken Chow Mein (鸡肉炒面)",
        "selected" : false
      },
      "position" : {
        "x" : -236.35369353173144,
        "y" : 161.81902463557356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "shared_name" : "ML-011",
        "name" : "ML-011",
        "SUID" : 278,
        "Recipe_Name" : "Chow Mein",
        "selected" : false
      },
      "position" : {
        "x" : -253.47298674462206,
        "y" : 222.64226682307356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "shared_name" : "WL-011",
        "name" : "WL-011",
        "SUID" : 272,
        "Recipe_Name" : "Chicken Chow Mein",
        "selected" : false
      },
      "position" : {
        "x" : -134.04757170555956,
        "y" : 274.1272826922142
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "shared_name" : "CH-011",
        "name" : "CH-011",
        "SUID" : 266,
        "Recipe_Name" : "Chicken Fried Noodles",
        "selected" : false
      },
      "position" : {
        "x" : -128.7012887465752,
        "y" : 144.93081052424543
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "shared_name" : "RM-010",
        "name" : "RM-010",
        "SUID" : 260,
        "Recipe_Name" : "Chow Mein",
        "selected" : false
      },
      "position" : {
        "x" : -196.110910938958,
        "y" : -441.49786989567644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "shared_name" : "WC-010",
        "name" : "WC-010",
        "SUID" : 254,
        "Recipe_Name" : "Cantonese Supreme Soy Sauce Pan-Fried Noodles",
        "selected" : false
      },
      "position" : {
        "x" : -312.79046110985644,
        "y" : -383.31972353337176
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "shared_name" : "OC-010",
        "name" : "OC-010",
        "SUID" : 248,
        "Recipe_Name" : "Vegetarian Chow Mein (素菜炒面)",
        "selected" : false
      },
      "position" : {
        "x" : -274.9688668715752,
        "y" : -437.91705934880144
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "shared_name" : "ML-010",
        "name" : "ML-010",
        "SUID" : 242,
        "Recipe_Name" : "Cantonese Chow Mein",
        "selected" : false
      },
      "position" : {
        "x" : -232.6926522719658,
        "y" : -389.4084533917702
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "shared_name" : "WL-010",
        "name" : "WL-010",
        "SUID" : 236,
        "Recipe_Name" : "Cantonese Soy Sauce Pan-Fried Noodles",
        "selected" : false
      },
      "position" : {
        "x" : -329.44414763329394,
        "y" : -321.91795961735613
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "shared_name" : "CH-010",
        "name" : "CH-010",
        "SUID" : 185,
        "Recipe_Name" : "Fried Noodles",
        "selected" : false
      },
      "position" : {
        "x" : -187.05137114403612,
        "y" : -287.74925844548113
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "shared_name" : "The Chinese Cook Book",
        "name" : "The Chinese Cook Book",
        "SUID" : 183,
        "Recipe_Name" : "The Chinese Cook Book",
        "selected" : false
      },
      "position" : {
        "x" : 8.191278411170174,
        "y" : 5.22274167658918
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "929",
        "source" : "902",
        "target" : "926",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"sugar",
        "Deletes" : "water",
        "Source" : "https://rasamalaysia.com/peanut-brittle-recipe/#wprm-recipe-container-761764",
        "shared_name" : "CH-142 (interacts with) RM-142",
        "Year" : 2011,
        "Updates" : "peanut",
        "Era" : "Modern",
        "name" : "CH-142 (interacts with) RM-142",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 929,
        "Inserts" : "corn syrup",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "source" : "902",
        "target" : "920",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"sugar",
        "Deletes" : "salt",
        "Source" : "https://whattocooktoday.com/easy-sesame-peanut-brittle.html",
        "shared_name" : "CH-142 (interacts with) WC-142",
        "Year" : 2021,
        "Updates" : "vinegar",
        "Era" : "Modern",
        "name" : "CH-142 (interacts with) WC-142",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 923,
        "Inserts" : "water",
        "Notes" : "peanut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "source" : "902",
        "target" : "914",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"peanut",
        "Deletes" : "sesame seed",
        "Source" : "https://omnivorescookbook.com/chinese-peanut-brittle/",
        "shared_name" : "CH-142 (interacts with) OC-142",
        "Year" : 2024,
        "Updates" : "sugar",
        "Era" : "Modern",
        "name" : "CH-142 (interacts with) OC-142",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 917,
        "Inserts" : "quinoa",
        "Notes" : "butter",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "911",
        "source" : "902",
        "target" : "908",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"peanut",
        "Deletes" : "oil",
        "Source" : "https://thewoksoflife.com/chinese-sesame-peanut-brittle/",
        "shared_name" : "CH-142 (interacts with) WL-142",
        "Year" : 2021,
        "Updates" : "sesame seed\"",
        "Era" : "Modern",
        "name" : "CH-142 (interacts with) WL-142",
        "interaction" : "interacts with",
        "Author" : "Judy Leung",
        "SUID" : 911,
        "Inserts" : "sugar",
        "Notes" : "sesame seed",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "source" : "872",
        "target" : "896",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"oil",
        "Deletes" : "dried shrimp",
        "Source" : "https://rasamalaysia.com/yam-cake-recipe-or-kuih/",
        "shared_name" : "CH-141 (interacts with) RM-141",
        "Year" : 2024,
        "Updates" : "taro",
        "Era" : "Modern",
        "name" : "CH-141 (interacts with) RM-141",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 899,
        "Inserts" : "shallot",
        "Notes" : "rice flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "source" : "872",
        "target" : "890",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"rice flour",
        "Deletes" : "salt",
        "Source" : "https://whattocooktoday.com/easy-steamed-taro-cake-with-dried-shrimp-toppings-o-kue.html",
        "shared_name" : "CH-141 (interacts with) WC-141",
        "Year" : 2024,
        "Updates" : "five-spice powder",
        "Era" : "Modern",
        "name" : "CH-141 (interacts with) WC-141",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 893,
        "Inserts" : "water",
        "Notes" : "taro",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "887",
        "source" : "872",
        "target" : "884",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"taro",
        "Deletes" : "water",
        "Source" : "https://www.madewithlau.com/recipes/taro-cake",
        "shared_name" : "CH-141 (interacts with) ML-141",
        "Year" : 2020,
        "Updates" : "dried shrimp",
        "Era" : "Modern",
        "name" : "CH-141 (interacts with) ML-141",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 887,
        "Inserts" : "rice flour",
        "Notes" : "Chinese sausage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "source" : "872",
        "target" : "878",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"oil",
        "Deletes" : "scallion",
        "Source" : "https://thewoksoflife.com/taro-cake-wu-tao-gou/",
        "shared_name" : "CH-141 (interacts with) WL-141",
        "Year" : 2022,
        "Updates" : "taro",
        "Era" : "Modern",
        "name" : "CH-141 (interacts with) WL-141",
        "interaction" : "interacts with",
        "Author" : "Kaitlin Leung",
        "SUID" : 881,
        "Inserts" : "Chinese sausage",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "source" : "842",
        "target" : "866",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"cake flour",
        "Deletes" : "egg",
        "Source" : "https://rasamalaysia.com/sponge-cake/",
        "shared_name" : "CH-138 (interacts with) RM-138",
        "Year" : 2021,
        "Updates" : "sugar",
        "Era" : "Modern",
        "name" : "CH-138 (interacts with) RM-138",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 869,
        "Inserts" : "cornstarch",
        "Notes" : "unsalted butter\"",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "source" : "842",
        "target" : "860",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"egg",
        "Deletes" : "milk",
        "Source" : "https://whattocooktoday.com/paper-wrapped-cake.html",
        "shared_name" : "CH-138 (interacts with) WC-138",
        "Year" : 2023,
        "Updates" : "sugar",
        "Era" : "Modern",
        "name" : "CH-138 (interacts with) WC-138",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 863,
        "Inserts" : "cake flour",
        "Notes" : "neutral oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "source" : "842",
        "target" : "854",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"egg",
        "Deletes" : "milk",
        "Source" : "https://omnivorescookbook.com/chinese-egg-cake/",
        "shared_name" : "CH-138 (interacts with) OC-138",
        "Year" : 2021,
        "Updates" : "neutral oil",
        "Era" : "Modern",
        "name" : "CH-138 (interacts with) OC-138",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 857,
        "Inserts" : "sugar",
        "Notes" : "vanilla",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "851",
        "source" : "842",
        "target" : "848",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"neutral oil",
        "Deletes" : "egg",
        "Source" : "https://thewoksoflife.com/chinese-egg-cake/",
        "shared_name" : "CH-138 (interacts with) WL-138",
        "Year" : 2024,
        "Updates" : "sugar",
        "Era" : "Modern",
        "name" : "CH-138 (interacts with) WL-138",
        "interaction" : "interacts with",
        "Author" : "Judy Leung",
        "SUID" : 851,
        "Inserts" : "cake flour",
        "Notes" : "honey\"",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "839",
        "source" : "812",
        "target" : "836",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"shortening",
        "Deletes" : "salt",
        "Source" : "https://rasamalaysia.com/almond-cookies/",
        "shared_name" : "CH-137 (interacts with) RM-137",
        "Year" : 2018,
        "Updates" : "cornstarch",
        "Era" : "Modern",
        "name" : "CH-137 (interacts with) RM-137",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 839,
        "Inserts" : "icing sugar",
        "Notes" : "all-purpose flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "source" : "812",
        "target" : "830",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"almond flour",
        "Deletes" : "all-purpose flour",
        "Source" : "https://whattocooktoday.com/chinese-almond-cookies.html",
        "shared_name" : "CH-137 (interacts with) WC-137",
        "Year" : 2021,
        "Updates" : "salt",
        "Era" : "Modern",
        "name" : "CH-137 (interacts with) WC-137",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 833,
        "Inserts" : "almond",
        "Notes" : "baking powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "827",
        "source" : "812",
        "target" : "824",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"all-purpose flour",
        "Deletes" : "almond flour",
        "Source" : "https://omnivorescookbook.com/chinese-almond-cookies/",
        "shared_name" : "CH-137 (interacts with) OC-137",
        "Year" : 2019,
        "Updates" : "baking soda",
        "Era" : "Modern",
        "name" : "CH-137 (interacts with) OC-137",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 827,
        "Inserts" : "sugar",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "812",
        "target" : "818",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"almond flour",
        "Deletes" : "all-purpose flour",
        "Source" : "https://thewoksoflife.com/almond-cookies-chinese/",
        "shared_name" : "CH-137 (interacts with) WL-137",
        "Year" : 2025,
        "Updates" : "baking soda",
        "Era" : "Modern",
        "name" : "CH-137 (interacts with) WL-137",
        "interaction" : "interacts with",
        "Author" : "Sarah Leung",
        "SUID" : 821,
        "Inserts" : "sugar",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "source" : "788",
        "target" : "806",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"all-purpose flour",
        "Deletes" : "instant yeast",
        "Source" : "https://whattocooktoday.com/steamed-pork-scallion-buns.html",
        "shared_name" : "CH-136 (interacts with) WC-136",
        "Year" : 2020,
        "Updates" : "sugar",
        "Era" : "Modern",
        "name" : "CH-136 (interacts with) WC-136",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 809,
        "Inserts" : "wheat starch",
        "Notes" : "cooking oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "source" : "788",
        "target" : "800",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"water",
        "Deletes" : "sugar",
        "Source" : "https://omnivorescookbook.com/steamed-pork-buns/",
        "shared_name" : "CH-136 (interacts with) OC-136",
        "Year" : 2021,
        "Updates" : "dry yeast",
        "Era" : "Modern",
        "name" : "CH-136 (interacts with) OC-136",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 803,
        "Inserts" : "ginger",
        "Notes" : "all-purpose flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "797",
        "source" : "788",
        "target" : "794",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"dry yeast",
        "Deletes" : "all-purpose flour",
        "Source" : "https://thewoksoflife.com/steamed-pork-buns-baozi/",
        "shared_name" : "CH-136 (interacts with) WL-136",
        "Year" : 2023,
        "Updates" : "pork",
        "Era" : "Modern",
        "name" : "CH-136 (interacts with) WL-136",
        "interaction" : "interacts with",
        "Author" : "Judy Leung",
        "SUID" : 797,
        "Inserts" : "sugar",
        "Notes" : "water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "source" : "752",
        "target" : "782",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"oil",
        "Deletes" : "Chinese sausage",
        "Source" : "https://rasamalaysia.com/chinese-fried-rice/",
        "shared_name" : "CH-135 (interacts with) RM-135",
        "Year" : 2021,
        "Updates" : "egg",
        "Era" : "Modern",
        "name" : "CH-135 (interacts with) RM-135",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 785,
        "Inserts" : "garlic",
        "Notes" : "mixed vegetable",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "source" : "752",
        "target" : "776",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"rice",
        "Deletes" : "egg",
        "Source" : "https://whattocooktoday.com/chinese-egg-fried-rice.html",
        "shared_name" : "CH-135 (interacts with) WC-135",
        "Year" : 2023,
        "Updates" : "butter",
        "Era" : "Modern",
        "name" : "CH-135 (interacts with) WC-135",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 779,
        "Inserts" : "mixed vegetable",
        "Notes" : "onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "source" : "752",
        "target" : "770",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"peanut oil",
        "Deletes" : "rice",
        "Source" : "https://omnivorescookbook.com/egg-fried-rice/",
        "shared_name" : "CH-135 (interacts with) OC-135",
        "Year" : 2023,
        "Updates" : "salt",
        "Era" : "Modern",
        "name" : "CH-135 (interacts with) OC-135",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 773,
        "Inserts" : "egg",
        "Notes" : "scallion\"",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "752",
        "target" : "764",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"rice",
        "Deletes" : "scallion",
        "Source" : "https://www.madewithlau.com/recipes/egg-fried-rice",
        "shared_name" : "CH-135 (interacts with) ML-135",
        "Year" : 2023,
        "Updates" : "carrot",
        "Era" : "Modern",
        "name" : "CH-135 (interacts with) ML-135",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 767,
        "Inserts" : "water",
        "Notes" : "corn",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "source" : "752",
        "target" : "758",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"rice",
        "Deletes" : "paprika",
        "Source" : "https://thewoksoflife.com/egg-fried-rice/",
        "shared_name" : "CH-135 (interacts with) WL-135",
        "Year" : 2025,
        "Updates" : "turmeric",
        "Era" : "Modern",
        "name" : "CH-135 (interacts with) WL-135",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 761,
        "Inserts" : "egg",
        "Notes" : "oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "source" : "716",
        "target" : "746",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"napa cabbage",
        "Deletes" : "chicken",
        "Source" : "https://rasamalaysia.com/chinese-hot-pot/",
        "shared_name" : "CH-133 (interacts with) RM-133",
        "Year" : 2024,
        "Updates" : "tofu",
        "Era" : "Modern",
        "name" : "CH-133 (interacts with) RM-133",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 749,
        "Inserts" : "fish ball",
        "Notes" : "shiitake mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "source" : "716",
        "target" : "740",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"pork neck bone",
        "Deletes" : "daikon",
        "Source" : "https://whattocooktoday.com/szechuan-hot-pot-for-chinese-new-year-eve.html",
        "shared_name" : "CH-133 (interacts with) WC-133",
        "Year" : 2021,
        "Updates" : "red date",
        "Era" : "Modern",
        "name" : "CH-133 (interacts with) WC-133",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 743,
        "Inserts" : "chicken broth",
        "Notes" : "scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "source" : "716",
        "target" : "734",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"hot pot base",
        "Deletes" : "scallion",
        "Source" : "https://omnivorescookbook.com/chinese-hot-pot-guide/",
        "shared_name" : "CH-133 (interacts with) OC-133",
        "Year" : 2018,
        "Updates" : "lamb",
        "Era" : "Modern",
        "name" : "CH-133 (interacts with) OC-133",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 737,
        "Inserts" : "ginger",
        "Notes" : "beef",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "source" : "716",
        "target" : "728",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"primary soup",
        "Deletes" : "chicken",
        "Source" : "https://www.madewithlau.com/recipes/ultimate-guide-to-hot-pot",
        "shared_name" : "CH-133 (interacts with) ML-133",
        "Year" : 2021,
        "Updates" : "pork",
        "Era" : "Modern",
        "name" : "CH-133 (interacts with) ML-133",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 731,
        "Inserts" : "beef",
        "Notes" : "fish",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "source" : "716",
        "target" : "722",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"oil",
        "Deletes" : "bay leaf",
        "Source" : "https://thewoksoflife.com/hot-pot/",
        "shared_name" : "CH-133 (interacts with) WL-133",
        "Year" : 2020,
        "Updates" : "garlic",
        "Era" : "Modern",
        "name" : "CH-133 (interacts with) WL-133",
        "interaction" : "interacts with",
        "Author" : "Sarah Leung",
        "SUID" : 725,
        "Inserts" : "ginger",
        "Notes" : "cinammon",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "source" : "686",
        "target" : "710",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"vermicelli",
        "Deletes" : "vegetable stock",
        "Source" : "https://whattocooktoday.com/lo-han-jai.html",
        "shared_name" : "CH-115 (interacts with) WC-115",
        "Year" : 2020,
        "Updates" : "bamboo shoot",
        "Era" : "Modern",
        "name" : "CH-115 (interacts with) WC-115",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 713,
        "Inserts" : "cooking oil",
        "Notes" : "dried lily flower",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "source" : "686",
        "target" : "704",
        "shared_interaction" : "interacts with",
        "Source_Type" : "https://omnivorescookbook.com/buddhas-delight/",
        "Ingredients" : "Blog",
        "Deletes" : "dried shiitake mushroom",
        "Source" : "Modern",
        "shared_name" : "CH-115 (interacts with) OC-115",
        "Updates" : "dried wood ear mushroom",
        "Era" : "2022",
        "name" : "CH-115 (interacts with) OC-115",
        "interaction" : "interacts with",
        "Author" : "Chinese Vegetarian Stew)\"",
        "SUID" : 707,
        "Inserts" : "\"dried lily flower",
        "Notes" : "vermicelli",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "source" : "686",
        "target" : "698",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"bamboo fungus",
        "Deletes" : "dried shiitake mushroom",
        "Source" : "https://www.madewithlau.com/recipes/buddhas-delight",
        "shared_name" : "CH-115 (interacts with) ML-115",
        "Year" : 2022,
        "Updates" : "wood ear mushroom",
        "Era" : "Modern",
        "name" : "CH-115 (interacts with) ML-115",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 701,
        "Inserts" : "vermicelli",
        "Notes" : "seafood mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "source" : "686",
        "target" : "692",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"canola oil",
        "Deletes" : "red fermented bean curd",
        "Source" : "https://thewoksoflife.com/buddhas-delight-lo-han-jai/",
        "shared_name" : "CH-115 (interacts with) WL-115",
        "Year" : 2020,
        "Updates" : "garlic",
        "Era" : "Modern",
        "name" : "CH-115 (interacts with) WL-115",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 695,
        "Inserts" : "ginger",
        "Notes" : "leek",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "source" : "662",
        "target" : "680",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"all-purpose flour",
        "Deletes" : "salt",
        "Source" : "https://whattocooktoday.com/dou-sha-bao.html",
        "shared_name" : "CH-112 (interacts with) WC-112",
        "Year" : 2023,
        "Updates" : "instant yeast",
        "Era" : "Modern",
        "name" : "CH-112 (interacts with) WC-112",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 683,
        "Inserts" : "wheat starch",
        "Notes" : "sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "source" : "662",
        "target" : "674",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"bread flour",
        "Deletes" : "active dry yeast",
        "Source" : "https://omnivorescookbook.com/red-bean-bread/",
        "shared_name" : "CH-112 (interacts with) OC-112",
        "Year" : 2023,
        "Updates" : "sugar",
        "Era" : "Modern",
        "name" : "CH-112 (interacts with) OC-112",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 677,
        "Inserts" : "whole milk",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "source" : "662",
        "target" : "668",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"red bean paste",
        "Deletes" : "water",
        "Source" : "https://thewoksoflife.com/steamed-red-bean-buns/",
        "shared_name" : "CH-112 (interacts with) WL-112",
        "Year" : 2023,
        "Updates" : "active dry yeast",
        "Era" : "Modern",
        "name" : "CH-112 (interacts with) WL-112",
        "interaction" : "interacts with",
        "Author" : "Judy Leung",
        "SUID" : 671,
        "Inserts" : "sugar",
        "Notes" : "all-purpose flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "source" : "638",
        "target" : "656",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"tofu",
        "Deletes" : "pork",
        "Source" : "https://omnivorescookbook.com/stuffed-tofu/",
        "shared_name" : "CH-110 (interacts with) OC-110",
        "Year" : 2025,
        "Updates" : "ginger",
        "Era" : "Modern",
        "name" : "CH-110 (interacts with) OC-110",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 659,
        "Inserts" : "dried shiitake mushroom",
        "Notes" : "scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "source" : "638",
        "target" : "650",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"salt",
        "Deletes" : "cilantro",
        "Source" : "https://www.madewithlau.com/recipes/fried-stuffed-tofu",
        "shared_name" : "CH-110 (interacts with) ML-110",
        "Year" : 2023,
        "Updates" : "scallion",
        "Era" : "Modern",
        "name" : "CH-110 (interacts with) ML-110",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 653,
        "Inserts" : "tofu",
        "Notes" : "fish",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "source" : "638",
        "target" : "644",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"shrimp",
        "Deletes" : "oil",
        "Source" : "https://thewoksoflife.com/crispy-skin-stuffed-tofu/",
        "shared_name" : "CH-110 (interacts with) WL-110",
        "Year" : 2020,
        "Updates" : "sesame oil",
        "Era" : "Modern",
        "name" : "CH-110 (interacts with) WL-110",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 647,
        "Inserts" : "salt",
        "Notes" : "Shaoxing wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "source" : "608",
        "target" : "632",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"egg",
        "Deletes" : "fish sauce",
        "Source" : "https://rasamalaysia.com/shrimp-omelette/",
        "shared_name" : "CH-092 (interacts with) RM-092",
        "Year" : 2021,
        "Updates" : "white pepper",
        "Era" : "Modern",
        "name" : "CH-092 (interacts with) RM-092",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 635,
        "Inserts" : "oyster sauce",
        "Notes" : "sesame oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "source" : "608",
        "target" : "626",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken broth",
        "Deletes" : "soy sauce",
        "Source" : "https://omnivorescookbook.com/shrimp-egg-foo-young/",
        "shared_name" : "CH-092 (interacts with) OC-092",
        "Year" : 2016,
        "Updates" : "rice vinegar",
        "Era" : "Modern",
        "name" : "CH-092 (interacts with) OC-092",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 629,
        "Inserts" : "ketchup",
        "Notes" : "sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "source" : "608",
        "target" : "620",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"shrimp",
        "Deletes" : "scallion",
        "Source" : "https://www.madewithlau.com/recipes/cantonese-scrambled-egg",
        "shared_name" : "CH-092 (interacts with) ML-092",
        "Year" : 2022,
        "Updates" : "oil",
        "Era" : "Modern",
        "name" : "CH-092 (interacts with) ML-092",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 623,
        "Inserts" : "egg",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "source" : "608",
        "target" : "614",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"shrimp",
        "Deletes" : "sugar",
        "Source" : "https://thewoksoflife.com/shrimp-egg-foo-young/",
        "shared_name" : "CH-092 (interacts with) WL-092",
        "Year" : 2023,
        "Updates" : "cornstarch",
        "Era" : "Modern",
        "name" : "CH-092 (interacts with) WL-092",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 617,
        "Inserts" : "salt",
        "Notes" : "neutral oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "source" : "578",
        "target" : "602",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"egg",
        "Deletes" : "pork",
        "Source" : "https://rasamalaysia.com/egg-foo-young/",
        "shared_name" : "CH-089 (interacts with) RM-089",
        "Year" : 2019,
        "Updates" : "shrimp",
        "Era" : "Modern",
        "name" : "CH-089 (interacts with) RM-089",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 605,
        "Inserts" : "bean sprout",
        "Notes" : "scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "source" : "578",
        "target" : "596",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"egg",
        "Deletes" : "scallion",
        "Source" : "https://omnivorescookbook.com/easy-egg-foo-young/#recipe",
        "shared_name" : "CH-089 (interacts with) OC-089",
        "Year" : 2019,
        "Updates" : "sea salt",
        "Era" : "Modern",
        "name" : "CH-089 (interacts with) OC-089",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 599,
        "Inserts" : "bell pepper",
        "Notes" : "white pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "source" : "578",
        "target" : "590",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"shrimp",
        "Deletes" : "bean sprout",
        "Source" : "https://www.madewithlau.com/recipes/egg-foo-young",
        "shared_name" : "CH-089 (interacts with) ML-089",
        "Year" : 2022,
        "Updates" : "red onion",
        "Era" : "Modern",
        "name" : "CH-089 (interacts with) ML-089",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 593,
        "Inserts" : "egg",
        "Notes" : "scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "source" : "578",
        "target" : "584",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"protein",
        "Deletes" : "onion",
        "Source" : "https://thewoksoflife.com/egg-foo-young/",
        "shared_name" : "CH-089 (interacts with) WL-089",
        "Year" : 2025,
        "Updates" : "mung bean sprout",
        "Era" : "Modern",
        "name" : "CH-089 (interacts with) WL-089",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 587,
        "Inserts" : "neutral oil",
        "Notes" : "egg",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "source" : "548",
        "target" : "572",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"shrimp",
        "Deletes" : "white pepper",
        "Source" : "https://rasamalaysia.com/salt-and-pepper-shrimp-recipe/",
        "shared_name" : "CH-067 (interacts with) RM-067",
        "Year" : 2019,
        "Updates" : "oil",
        "Era" : "Modern",
        "name" : "CH-067 (interacts with) RM-067",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 575,
        "Inserts" : "salt",
        "Notes" : "all-purpose flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "source" : "548",
        "target" : "566",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"shrimp",
        "Deletes" : "salt",
        "Source" : "https://omnivorescookbook.com/3-ingredient-fried-shrimp/",
        "shared_name" : "CH-067 (interacts with) OC-067",
        "Year" : 2018,
        "Updates" : "black pepper",
        "Era" : "Modern",
        "name" : "CH-067 (interacts with) OC-067",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 569,
        "Inserts" : "Shaoxing wine",
        "Notes" : "all-purpose flour",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "source" : "548",
        "target" : "560",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"shrimp",
        "Deletes" : "red onion",
        "Source" : "https://www.madewithlau.com/recipes/salt-pepper-shrimp",
        "shared_name" : "CH-067 (interacts with) ML-067",
        "Year" : 2023,
        "Updates" : "red bell pepper",
        "Era" : "Modern",
        "name" : "CH-067 (interacts with) ML-067",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 563,
        "Inserts" : "garlic",
        "Notes" : "scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "source" : "548",
        "target" : "554",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"shrimp",
        "Deletes" : "vegetable oil",
        "Source" : "https://thewoksoflife.com/fantail-shrimp/",
        "shared_name" : "CH-067 (interacts with) WL-067",
        "Year" : 2020,
        "Updates" : "all-purpose flour",
        "Era" : "Modern",
        "name" : "CH-067 (interacts with) WL-067",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 557,
        "Inserts" : "salt",
        "Notes" : "cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "source" : "524",
        "target" : "542",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"prawn",
        "Deletes" : "oil",
        "Source" : "https://whattocooktoday.com/chinese-steamed-garlic-prawns.html",
        "shared_name" : "CH-066 (interacts with) WC-066",
        "Year" : 2022,
        "Updates" : "garlic",
        "Era" : "Modern",
        "name" : "CH-066 (interacts with) WC-066",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 545,
        "Inserts" : "vermicelli",
        "Notes" : "ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "source" : "524",
        "target" : "536",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"shrimp",
        "Deletes" : "oyster sauce",
        "Source" : "https://www.madewithlau.com/recipes/steamed-garlic-shrimp",
        "shared_name" : "CH-066 (interacts with) ML-066",
        "Year" : 2024,
        "Updates" : "light soy sauce",
        "Era" : "Modern",
        "name" : "CH-066 (interacts with) ML-066",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 539,
        "Inserts" : "vermicelli",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "source" : "524",
        "target" : "530",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"shrimp",
        "Deletes" : "garlic",
        "Source" : "https://thewoksoflife.com/steamed-shrimp-glass-noodle-two-ways/",
        "shared_name" : "CH-066 (interacts with) WL-066",
        "Year" : 2020,
        "Updates" : "water",
        "Era" : "Modern",
        "name" : "CH-066 (interacts with) WL-066",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 533,
        "Inserts" : "vermicelli",
        "Notes" : "sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "source" : "488",
        "target" : "518",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"fish",
        "Deletes" : "scallion",
        "Source" : "https://rasamalaysia.com/steamed-fish-recipe/",
        "shared_name" : "CH-060 (interacts with) RM-060",
        "Year" : 2024,
        "Updates" : "cooking oil",
        "Era" : "Modern",
        "name" : "CH-060 (interacts with) RM-060",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 521,
        "Inserts" : "ginger",
        "Notes" : "Shaoxing wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "source" : "488",
        "target" : "512",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"fish",
        "Deletes" : "soy sauce",
        "Source" : "https://whattocooktoday.com/hong-kong-style-steamed-fish.html",
        "shared_name" : "CH-060 (interacts with) WC-060",
        "Year" : 2022,
        "Updates" : "sugar",
        "Era" : "Modern",
        "name" : "CH-060 (interacts with) WC-060",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 515,
        "Inserts" : "scallion",
        "Notes" : "water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "source" : "488",
        "target" : "506",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"white fish",
        "Deletes" : "scallion",
        "Source" : "https://omnivorescookbook.com/authentic-chinese-steamed-fish/",
        "shared_name" : "CH-060 (interacts with) OC-060",
        "Year" : 2024,
        "Updates" : "Shaoxing wine",
        "Era" : "Modern",
        "name" : "CH-060 (interacts with) OC-060",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 509,
        "Inserts" : "ginger",
        "Notes" : "peanut oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "source" : "488",
        "target" : "500",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"tilapia",
        "Deletes" : "scallion",
        "Source" : "https://www.madewithlau.com/recipes/steamed-fish",
        "shared_name" : "CH-060 (interacts with) ML-060",
        "Year" : 2021,
        "Updates" : "cilantro",
        "Era" : "Modern",
        "name" : "CH-060 (interacts with) ML-060",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 503,
        "Inserts" : "ginger",
        "Notes" : "corn oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "source" : "488",
        "target" : "494",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"scallion",
        "Deletes" : "cilantro",
        "Source" : "https://thewoksoflife.com/cantonese-steamed-fish/",
        "shared_name" : "CH-060 (interacts with) WL-060",
        "Year" : 2025,
        "Updates" : "light soy sauce",
        "Era" : "Modern",
        "name" : "CH-060 (interacts with) WL-060",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 497,
        "Inserts" : "ginger",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "source" : "458",
        "target" : "482",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"beef",
        "Deletes" : "garlic",
        "Source" : "https://rasamalaysia.com/black-pepper-beef/",
        "shared_name" : "CH-053 (interacts with) RM-053",
        "Year" : 2019,
        "Updates" : "ginger",
        "Era" : "Modern",
        "name" : "CH-053 (interacts with) RM-053",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 485,
        "Inserts" : "cooking oil",
        "Notes" : "green bell pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "source" : "458",
        "target" : "476",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"beef",
        "Deletes" : "Shaoxing wine",
        "Source" : "https://omnivorescookbook.com/shredded-beef-and-pepper-stir-fry/",
        "shared_name" : "CH-053 (interacts with) OC-053",
        "Year" : 2022,
        "Updates" : "dark soy sauce",
        "Era" : "Modern",
        "name" : "CH-053 (interacts with) OC-053",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 479,
        "Inserts" : "doubanjiang",
        "Notes" : "white pepper",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "source" : "458",
        "target" : "470",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"beef",
        "Deletes" : "red onion",
        "Source" : "https://www.madewithlau.com/recipes/black-pepper-beef-stir-fry",
        "shared_name" : "CH-053 (interacts with) ML-053",
        "Year" : 2021,
        "Updates" : "garlic",
        "Era" : "Modern",
        "name" : "CH-053 (interacts with) ML-053",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 473,
        "Inserts" : "bell pepper",
        "Notes" : "corn oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "source" : "458",
        "target" : "464",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"beef",
        "Deletes" : "sesame oil",
        "Source" : "https://thewoksoflife.com/beef-and-pepper-stir-fry/",
        "shared_name" : "CH-053 (interacts with) WL-053",
        "Year" : 2022,
        "Updates" : "cornstarch",
        "Era" : "Modern",
        "name" : "CH-053 (interacts with) WL-053",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 467,
        "Inserts" : "soy sauce",
        "Notes" : "vegetable oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "source" : "434",
        "target" : "452",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"pork rib",
        "Deletes" : "peanut oil",
        "Source" : "https://whattocooktoday.com/fried-stewed-country-spareribs-zha-li-rou.html",
        "shared_name" : "CH-051 (interacts with) WC-051",
        "Year" : 2019,
        "Updates" : "bird's eye chili",
        "Era" : "Modern",
        "name" : "CH-051 (interacts with) WC-051",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 455,
        "Inserts" : "chicken stock",
        "Notes" : "honey",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "source" : "434",
        "target" : "446",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"pork rib",
        "Deletes" : "soy sauce",
        "Source" : "https://omnivorescookbook.com/air-fryer-garlic-ribs/",
        "shared_name" : "CH-051 (interacts with) OC-051",
        "Year" : 2022,
        "Updates" : "Shaoxing wine",
        "Era" : "Modern",
        "name" : "CH-051 (interacts with) OC-051",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 449,
        "Inserts" : "oyster sauce",
        "Notes" : "ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "source" : "434",
        "target" : "440",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"pork rib",
        "Deletes" : "white pepper",
        "Source" : "https://thewoksoflife.com/fried-chinese-spareribs/",
        "shared_name" : "CH-051 (interacts with) WL-051",
        "Year" : 2022,
        "Updates" : "sesame oil",
        "Era" : "Modern",
        "name" : "CH-051 (interacts with) WL-051",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 443,
        "Inserts" : "red fermented bean curd",
        "Notes" : "five-spice powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "source" : "410",
        "target" : "428",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"duck",
        "Deletes" : "maltose",
        "Source" : "https://whattocooktoday.com/peking-duck-with-chinese-pancakes.html",
        "shared_name" : "CH-025 (interacts with) WC-025",
        "Year" : 2024,
        "Updates" : "apple cider vinegar",
        "Era" : "Modern",
        "name" : "CH-025 (interacts with) WC-025",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 431,
        "Inserts" : "water",
        "Notes" : "rice wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "source" : "410",
        "target" : "422",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"duck",
        "Deletes" : "five-spice powder",
        "Source" : "https://omnivorescookbook.com/chinese-roast-duck/",
        "shared_name" : "CH-025 (interacts with) OC-025",
        "Year" : 2025,
        "Updates" : "sugar",
        "Era" : "Modern",
        "name" : "CH-025 (interacts with) OC-025",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 425,
        "Inserts" : "sea salt",
        "Notes" : "red fermented bean curd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "source" : "410",
        "target" : "416",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"duck",
        "Deletes" : "sea salt",
        "Source" : "https://thewoksoflife.com/chinese-roast-duck/",
        "shared_name" : "CH-025 (interacts with) WL-025",
        "Year" : 2024,
        "Updates" : "five-spice powder",
        "Era" : "Modern",
        "name" : "CH-025 (interacts with) WL-025",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 419,
        "Inserts" : "water",
        "Notes" : "sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "source" : "380",
        "target" : "404",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken",
        "Deletes" : "ginger",
        "Source" : "https://rasamalaysia.com/chinese-roast-chicken/",
        "shared_name" : "CH-024 (interacts with) RM-024",
        "Year" : 2019,
        "Updates" : "soy sauce",
        "Era" : "Modern",
        "name" : "CH-024 (interacts with) RM-024",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 407,
        "Inserts" : "garlic",
        "Notes" : "honey",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "source" : "380",
        "target" : "398",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken",
        "Deletes" : "salt",
        "Source" : "https://whattocooktoday.com/five-spice-oven-roasted-chicken.html",
        "shared_name" : "CH-024 (interacts with) WC-024",
        "Year" : 2024,
        "Updates" : "light soy sauce",
        "Era" : "Modern",
        "name" : "CH-024 (interacts with) WC-024",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 401,
        "Inserts" : "ginger",
        "Notes" : "dark soy sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "source" : "380",
        "target" : "392",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken",
        "Deletes" : "ginger",
        "Source" : "https://omnivorescookbook.com/cantonese-roast-chicken/",
        "shared_name" : "CH-024 (interacts with) OC-024",
        "Year" : 2022,
        "Updates" : "soy sauce",
        "Era" : "Modern",
        "name" : "CH-024 (interacts with) OC-024",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 395,
        "Inserts" : "garlic",
        "Notes" : "oyster sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "source" : "380",
        "target" : "386",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"chicken",
        "Deletes" : "ginger",
        "Source" : "https://www.madewithlau.com/recipes/whole-roasted-chicken",
        "shared_name" : "CH-024 (interacts with) ML-024",
        "Year" : 2024,
        "Updates" : "scallion",
        "Era" : "Modern",
        "name" : "CH-024 (interacts with) ML-024",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 389,
        "Inserts" : "salt",
        "Notes" : "red fermented bean curd",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "source" : "344",
        "target" : "374",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken",
        "Deletes" : "white pepper",
        "Source" : "https://rasamalaysia.com/chinese-steamed-chicken/",
        "shared_name" : "CH-023 (interacts with) RM-023",
        "Year" : 2025,
        "Updates" : "oyster sauce",
        "Era" : "Modern",
        "name" : "CH-023 (interacts with) RM-023",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 377,
        "Inserts" : "Shaoxing wine",
        "Notes" : "cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "source" : "344",
        "target" : "368",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken",
        "Deletes" : "scallion",
        "Source" : "https://whattocooktoday.com/bai-qie-ji.html",
        "shared_name" : "CH-023 (interacts with) WC-023",
        "Year" : 2024,
        "Updates" : "ginger",
        "Era" : "Modern",
        "name" : "CH-023 (interacts with) WC-023",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 371,
        "Inserts" : "salt",
        "Notes" : "cooking oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "source" : "344",
        "target" : "362",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken",
        "Deletes" : "Shaoxing wine",
        "Source" : "https://omnivorescookbook.com/steamed-chicken/",
        "shared_name" : "CH-023 (interacts with) OC-023",
        "Year" : 2024,
        "Updates" : "light soy sauce",
        "Era" : "Modern",
        "name" : "CH-023 (interacts with) OC-023",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 365,
        "Inserts" : "oyster sauce",
        "Notes" : "ginger",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "source" : "344",
        "target" : "356",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"dried shiitake mushroom",
        "Deletes" : "goji berry",
        "Source" : "https://www.madewithlau.com/recipes/steamed-chicken-with-mushroom",
        "shared_name" : "CH-023 (interacts with) ML-023",
        "Year" : 2024,
        "Updates" : "Chinese sausage",
        "Era" : "Modern",
        "name" : "CH-023 (interacts with) ML-023",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 359,
        "Inserts" : "wood ear mushroom",
        "Notes" : "chicken",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "source" : "344",
        "target" : "350",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"dried wood ear mushroom",
        "Deletes" : "dried shiitake mushroom",
        "Source" : "https://thewoksoflife.com/steamed-chicken-mushroom-dried-lily-fBee Yinn Lowers/",
        "shared_name" : "CH-023 (interacts with) WL-023",
        "Year" : 2025,
        "Updates" : "chicken",
        "Era" : "Modern",
        "name" : "CH-023 (interacts with) WL-023",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 353,
        "Inserts" : "dried lily flower",
        "Notes" : "water",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "source" : "320",
        "target" : "338",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"salt",
        "Deletes" : "sand ginger powder",
        "Source" : "https://omnivorescookbook.com/easy-salt-baked-chicken/",
        "shared_name" : "CH-020 (interacts with) OC-020",
        "Year" : 2022,
        "Updates" : "five-spice powder",
        "Era" : "Modern",
        "name" : "CH-020 (interacts with) OC-020",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 341,
        "Inserts" : "sugar",
        "Notes" : "Shaoxing wine\"",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "source" : "320",
        "target" : "332",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"chicken",
        "Deletes" : "sand ginger powder",
        "Source" : "https://www.madewithlau.com/recipes/salt-baked-chicken",
        "shared_name" : "CH-020 (interacts with) ML-020",
        "Year" : 2021,
        "Updates" : "sesame oil",
        "Era" : "Modern",
        "name" : "CH-020 (interacts with) ML-020",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 335,
        "Inserts" : "salt",
        "Notes" : "lard\"",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "source" : "320",
        "target" : "326",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken",
        "Deletes" : "sand ginger powder",
        "Source" : "https://thewoksoflife.com/salt-baked-chicken/",
        "shared_name" : "CH-020 (interacts with) WL-020",
        "Year" : 2021,
        "Updates" : "white pepper",
        "Era" : "Modern",
        "name" : "CH-020 (interacts with) WL-020",
        "interaction" : "interacts with",
        "Author" : "Judy Leung",
        "SUID" : 329,
        "Inserts" : "Shaoxing wine",
        "Notes" : "sea salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "source" : "296",
        "target" : "314",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken",
        "Deletes" : "oil",
        "Source" : "https://rasamalaysia.com/chestnut-chicken/",
        "shared_name" : "CH-014 (interacts with) RM-014",
        "Year" : 2025,
        "Updates" : "ginger",
        "Era" : "Modern",
        "name" : "CH-014 (interacts with) RM-014",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 317,
        "Inserts" : "cornstarch",
        "Notes" : "chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "source" : "296",
        "target" : "308",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"dried shiitake mushroom",
        "Deletes" : "light soy sauce",
        "Source" : "https://omnivorescookbook.com/braised-chestnut-chicken/",
        "shared_name" : "CH-014 (interacts with) OC-014",
        "Year" : 2021,
        "Updates" : "chestnut",
        "Era" : "Modern",
        "name" : "CH-014 (interacts with) OC-014",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 311,
        "Inserts" : "chicken",
        "Notes" : "peanut oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "source" : "296",
        "target" : "302",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken",
        "Deletes" : "salt",
        "Source" : "https://thewoksoflife.com/chinese-chicken-chestnut/",
        "shared_name" : "CH-014 (interacts with) WL-014",
        "Year" : 2025,
        "Updates" : "white pepper",
        "Era" : "Modern",
        "name" : "CH-014 (interacts with) WL-014",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 305,
        "Inserts" : "Shaoxing wine",
        "Notes" : "light soy sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "source" : "266",
        "target" : "290",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"noodle",
        "Deletes" : "oil",
        "Source" : "https://rasamalaysia.com/chicken-chow-mein/",
        "shared_name" : "CH-011 (interacts with) RM-011",
        "Year" : 2025,
        "Updates" : "garlic",
        "Era" : "Modern",
        "name" : "CH-011 (interacts with) RM-011",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 293,
        "Inserts" : "chicken",
        "Notes" : "cabbage",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "source" : "266",
        "target" : "284",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"noodle",
        "Deletes" : "Shaoxing wine",
        "Source" : "https://omnivorescookbook.com/chicken-chow-mein/",
        "shared_name" : "CH-011 (interacts with) OC-011",
        "Year" : 2022,
        "Updates" : "cornstarch",
        "Era" : "Modern",
        "name" : "CH-011 (interacts with) OC-011",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 287,
        "Inserts" : "chicken",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "source" : "266",
        "target" : "278",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"noodle",
        "Deletes" : "carrot",
        "Source" : "https://www.madewithlau.com/recipes/chow-mein",
        "shared_name" : "CH-011 (interacts with) ML-011",
        "Year" : 2023,
        "Updates" : "cabbage",
        "Era" : "Modern",
        "name" : "CH-011 (interacts with) ML-011",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 281,
        "Inserts" : "red onion",
        "Notes" : "scallion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "source" : "266",
        "target" : "272",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"chicken",
        "Deletes" : "oyster sauce",
        "Source" : "https://thewoksoflife.com/chicken-chow-mein-2/",
        "shared_name" : "CH-011 (interacts with) WL-011",
        "Year" : 2023,
        "Updates" : "cornstarch",
        "Era" : "Modern",
        "name" : "CH-011 (interacts with) WL-011",
        "interaction" : "interacts with",
        "Author" : "Bill Leung",
        "SUID" : 275,
        "Inserts" : "water",
        "Notes" : "Shaoxing wine",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "source" : "185",
        "target" : "260",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"noodle",
        "Deletes" : "oyster sauce",
        "Source" : "https://rasamalaysia.com/chow-mein/",
        "shared_name" : "CH-010 (interacts with) RM-010",
        "Year" : 2020,
        "Updates" : "sugar",
        "Era" : "Modern",
        "name" : "CH-010 (interacts with) RM-010",
        "interaction" : "interacts with",
        "Author" : "Bee Yinn Low",
        "SUID" : 263,
        "Inserts" : "soy sauce",
        "Notes" : "dark soy sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "source" : "185",
        "target" : "254",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"noodle",
        "Deletes" : "onion",
        "Source" : "https://whattocooktoday.com/supreme-soy-sauce-noodle.html",
        "shared_name" : "CH-010 (interacts with) WC-010",
        "Year" : 2020,
        "Updates" : "bean sprout",
        "Era" : "Modern",
        "name" : "CH-010 (interacts with) WC-010",
        "interaction" : "interacts with",
        "Author" : "Marvellina Goh",
        "SUID" : 257,
        "Inserts" : "cooking oil",
        "Notes" : "soy sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "source" : "185",
        "target" : "248",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"noodle",
        "Deletes" : "oyster sauce",
        "Source" : "https://omnivorescookbook.com/vegetarian-chow-mein/",
        "shared_name" : "CH-010 (interacts with) OC-010",
        "Year" : 2023,
        "Updates" : "Shaoxing wine",
        "Era" : "Modern",
        "name" : "CH-010 (interacts with) OC-010",
        "interaction" : "interacts with",
        "Author" : "Maggie Zhu",
        "SUID" : 251,
        "Inserts" : "vegetable stock",
        "Notes" : "light soy sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "source" : "185",
        "target" : "242",
        "shared_interaction" : "interacts with",
        "Source_Type" : "YouTube",
        "Ingredients" : "\"noodle",
        "Deletes" : "scallion",
        "Source" : "https://www.madewithlau.com/recipes/cantonese-chow-mein",
        "shared_name" : "CH-010 (interacts with) ML-010",
        "Year" : 2021,
        "Updates" : "bean sprout",
        "Era" : "Modern",
        "name" : "CH-010 (interacts with) ML-010",
        "interaction" : "interacts with",
        "Author" : "Chung Sun Lau",
        "SUID" : 245,
        "Inserts" : "onion",
        "Notes" : "dark soy sauce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "source" : "185",
        "target" : "236",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Blog",
        "Ingredients" : "\"bean sprout",
        "Deletes" : "soy sauce",
        "Source" : "https://thewoksoflife.com/cantonese-soy-sauce-pan-fried-noodle/",
        "shared_name" : "CH-010 (interacts with) WL-010",
        "Year" : 2024,
        "Updates" : "dark soy sauce",
        "Era" : "Modern",
        "name" : "CH-010 (interacts with) WL-010",
        "interaction" : "interacts with",
        "Author" : "Sarah Leung",
        "SUID" : 239,
        "Inserts" : "scallion",
        "Notes" : "sesame oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "905",
        "source" : "183",
        "target" : "902",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"peanut",
        "Deletes" : "water",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-142",
        "Year" : 1917,
        "Updates" : "oil\"",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-142",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 905,
        "Inserts" : "sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "875",
        "source" : "183",
        "target" : "872",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"pork",
        "Deletes" : "Chinese olive",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-141",
        "Year" : 1917,
        "Updates" : "Chinese frankfurter",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-141",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 875,
        "Inserts" : "shrimp",
        "Notes" : "Chinese onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "source" : "183",
        "target" : "842",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"egg",
        "Deletes" : "flour",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-138",
        "Year" : 1917,
        "Updates" : "lemon juice\"",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-138",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 845,
        "Inserts" : "sugar",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "815",
        "source" : "183",
        "target" : "812",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"flour",
        "Deletes" : "lard",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-137",
        "Year" : 1917,
        "Updates" : "egg",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-137",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 815,
        "Inserts" : "sugar",
        "Notes" : "alkaline solution",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "source" : "183",
        "target" : "788",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"flour",
        "Deletes" : "salt",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-136",
        "Year" : 1917,
        "Updates" : "sugar",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-136",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 791,
        "Inserts" : "yeast cake",
        "Notes" : "potato",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "source" : "183",
        "target" : "752",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"rice",
        "Deletes" : "secondary vegetable",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-135",
        "Year" : 1917,
        "Updates" : "egg",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-135",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 755,
        "Inserts" : "chicken",
        "Notes" : "primary soup",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "source" : "183",
        "target" : "716",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"primary soup",
        "Deletes" : "chicken",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-133",
        "Year" : 1917,
        "Updates" : "shrimp",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-133",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 719,
        "Inserts" : "pike",
        "Notes" : "beef",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "183",
        "target" : "686",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"bean cake",
        "Deletes" : "fungus",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-115",
        "Year" : 1917,
        "Updates" : "bean stick",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-115",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 689,
        "Inserts" : "white nut",
        "Notes" : "bamboo shoot",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "183",
        "target" : "662",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"red bean",
        "Deletes" : "lard",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-112",
        "Year" : 1917,
        "Updates" : "salt",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-112",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 665,
        "Inserts" : "flour",
        "Notes" : "baking powder",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "source" : "183",
        "target" : "638",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"bean cake",
        "Deletes" : "Chinese ham",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-110",
        "Year" : 1917,
        "Updates" : "Chinese onion",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-110",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 641,
        "Inserts" : "pike",
        "Notes" : "salted almond",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "source" : "183",
        "target" : "608",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"egg",
        "Deletes" : "onion",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-092",
        "Year" : 1917,
        "Updates" : "bamboo shoot",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-092",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 611,
        "Inserts" : "shrimp",
        "Notes" : "water chestnut",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "source" : "183",
        "target" : "578",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"egg",
        "Deletes" : "salt",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-089",
        "Year" : 1917,
        "Updates" : "Chinese ham",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-089",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 581,
        "Inserts" : "oil",
        "Notes" : "parsley\"",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "source" : "183",
        "target" : "548",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"shrimp",
        "Deletes" : "egg",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-067",
        "Year" : 1917,
        "Updates" : "cornstarch",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-067",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 551,
        "Inserts" : "green pepper",
        "Notes" : "oil\"",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "source" : "183",
        "target" : "524",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"shrimp",
        "Deletes" : "Fun Wine",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-066",
        "Year" : 1917,
        "Updates" : "ginger root juice",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-066",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 527,
        "Inserts" : "bamboo shoot",
        "Notes" : "oil",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "source" : "183",
        "target" : "488",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"pike",
        "Deletes" : "Chinese mushroom",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-060",
        "Year" : 1917,
        "Updates" : "ginger root",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-060",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 491,
        "Inserts" : "Chinese onion",
        "Notes" : "pork",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "source" : "183",
        "target" : "458",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"beef",
        "Deletes" : "celery",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-053",
        "Year" : 1917,
        "Updates" : "bean sprout",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-053",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 461,
        "Inserts" : "green pepper",
        "Notes" : "cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "source" : "183",
        "target" : "434",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"pork rib",
        "Deletes" : "sugar",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-051",
        "Year" : 1917,
        "Updates" : "Fun Wine",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-051",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 437,
        "Inserts" : "vinegar",
        "Notes" : "cornstarch",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "source" : "183",
        "target" : "410",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"duck",
        "Deletes" : "Chinese sauce",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-025",
        "Year" : 1917,
        "Updates" : "sesamum-seed oil",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-025",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 413,
        "Inserts" : "spicery powder",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "source" : "183",
        "target" : "380",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"chicken",
        "Deletes" : "Chinese sauce",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-024",
        "Year" : 1917,
        "Updates" : "sesamum-seed oil",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-024",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 383,
        "Inserts" : "spicery powder",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "source" : "183",
        "target" : "344",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"chicken",
        "Deletes" : "ginger root",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-023",
        "Year" : 1917,
        "Updates" : "red date",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-023",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 347,
        "Inserts" : "mushroom",
        "Notes" : "Chinese onion",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "source" : "183",
        "target" : "320",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"chicken",
        "Deletes" : "spicery powder\"",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-020",
        "Year" : 1917,
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-020",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 323,
        "Inserts" : "rock salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "source" : "183",
        "target" : "296",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"chicken",
        "Deletes" : "water chestnut",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-014",
        "Year" : 1917,
        "Updates" : "mushroom",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-014",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 299,
        "Inserts" : "chestnut",
        "Notes" : "salt",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "source" : "183",
        "target" : "266",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"noodle",
        "Deletes" : "chicken",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-011",
        "Year" : 1917,
        "Updates" : "egg",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-011",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 269,
        "Inserts" : "onion",
        "Notes" : "Chinese mushroom",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "source" : "183",
        "target" : "185",
        "shared_interaction" : "interacts with",
        "Source_Type" : "Book",
        "Ingredients" : "\"noodle",
        "Deletes" : "raw pork",
        "Source" : "The Chinese Cook Book",
        "shared_name" : "The Chinese Cook Book (interacts with) CH-010",
        "Year" : 1917,
        "Updates" : "roast pork",
        "Era" : "Historical",
        "name" : "The Chinese Cook Book (interacts with) CH-010",
        "interaction" : "interacts with",
        "Author" : "Shiu Wong Chan",
        "SUID" : 193,
        "Inserts" : "onion",
        "Notes" : "egg",
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}